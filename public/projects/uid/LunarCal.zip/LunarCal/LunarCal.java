/*
 * Lunar calendar
 * Copyright (C) 2005 Tom Adams
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*
 * TODO
 * - Comment
 * - Doc comments
 */

/*
 * Assumptions made:
 * - This software will be used in the Northern Hemisphere.
 *   - Replace Right with Left and Left with Right in *_COMMENT.
 * - This software will be used by English speakers.
 *   - Replace contents of *_LABEL *_COMMENT.
 *   - Replace super("Lunar Calendar");
 */

// Data structures
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

// GUI things
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

// Date Picker
// Swing doesn't provide one like most high-level toolkits do
// http://microba.sourceforge.net/
import com.michaelbaranov.microba.calendar.CalendarPane;

class LunarCal extends JFrame implements ActionListener {
    final int DARK_MOON = -1; // This shall not be used, probably
    final int NEW_MOON = 0;
    final int WAXING_CRESCENT_MOON = 1;
    final int FIRST_QUARTER_MOON = 2;
    final int WAXING_GIBBOUS_MOON = 3;
    final int FULL_MOON = 4;
    final int WANING_GIBBOUS_MOON = 5;
    final int THIRD_QUARTER_MOON = 6;
    final int WANING_CRESCENT_MOON = 7;

    String DARK_MOON_LABEL = "Dark Moon";
    String NEW_MOON_LABEL = "New Moon";
    String WAXING_CRESCENT_MOON_LABEL = "Waxing Crescent Moon";
    String FIRST_QUARTER_MOON_LABEL = "First Quarter Moon";
    String WAXING_GIBBOUS_MOON_LABEL = "Waxing Gibbous Moon";
    String FULL_MOON_LABEL = "Full Moon";
    String WANING_GIBBOUS_MOON_LABEL = "Waning Gibbous Moon";
    String THIRD_QUARTER_MOON_LABEL = "Third Quarter Moon";
    String WANING_CRESCENT_MOON_LABEL = "Waning Crescent Moon";
    String UNKNOWN_MOON_LABEL = "SOMEBODY SET US UP THE BOMB";

    String DARK_MOON_COMMENT = "Not visible";
    String NEW_MOON_COMMENT = "Not visible, or traditionally: first visible crescent of the Moon";
    String WAXING_CRESCENT_MOON_COMMENT = "Right 1-49% visible";
    String FIRST_QUARTER_MOON_COMMENT = "Right 50% visible";
    String WAXING_GIBBOUS_MOON_COMMENT = "Right 51-99% visible";
    String FULL_MOON_COMMENT = "Fully visible";
    String WANING_GIBBOUS_MOON_COMMENT = "Left 51-99% visible";
    String THIRD_QUARTER_MOON_COMMENT = "Left 50% visible";
    String WANING_CRESCENT_MOON_COMMENT = "Left 1-49% visible";
    String UNKNOWN_MOON_COMMENT = "The algorithm doesn't quite work for two days each year.";

    String DARK_MOON_PATH = "img/DarkMoon.png";
    String NEW_MOON_PATH = "img/NewMoon.png";
    String WAXING_CRESCENT_MOON_PATH = "img/WaxingCrescentMoon.png";
    String FIRST_QUARTER_MOON_PATH = "img/FirstQuarterMoon.png";
    String WAXING_GIBBOUS_MOON_PATH = "img/WaxingGibbousMoon.png";
    String FULL_MOON_PATH = "img/FullMoon.png";
    String WANING_GIBBOUS_MOON_PATH = "img/WaningGibbousMoon.png";
    String THIRD_QUARTER_MOON_PATH = "img/ThirdQuarterMoon.png";
    String WANING_CRESCENT_MOON_PATH = "img/WaningCrescentMoon.png";
    String UNKNOWN_MOON_PATH = "img/UnknownMoon.png";

    ImageIcon DARK_MOON_ICON = new ImageIcon(DARK_MOON_PATH, DARK_MOON_COMMENT);
    ImageIcon NEW_MOON_ICON = new ImageIcon(NEW_MOON_PATH, NEW_MOON_COMMENT);
    ImageIcon WAXING_CRESCENT_MOON_ICON = new ImageIcon(WAXING_CRESCENT_MOON_PATH, WAXING_CRESCENT_MOON_COMMENT);
    ImageIcon FIRST_QUARTER_MOON_ICON = new ImageIcon(FIRST_QUARTER_MOON_PATH, FIRST_QUARTER_MOON_COMMENT);
    ImageIcon WAXING_GIBBOUS_MOON_ICON = new ImageIcon(WAXING_GIBBOUS_MOON_PATH, WAXING_GIBBOUS_MOON_COMMENT);
    ImageIcon FULL_MOON_ICON = new ImageIcon(FULL_MOON_PATH, FULL_MOON_COMMENT);
    ImageIcon WANING_GIBBOUS_MOON_ICON = new ImageIcon(WANING_GIBBOUS_MOON_PATH, WANING_GIBBOUS_MOON_COMMENT);
    ImageIcon THIRD_QUARTER_MOON_ICON = new ImageIcon(THIRD_QUARTER_MOON_PATH, THIRD_QUARTER_MOON_COMMENT);
    ImageIcon WANING_CRESCENT_MOON_ICON = new ImageIcon(WANING_CRESCENT_MOON_PATH, WANING_CRESCENT_MOON_COMMENT);
    ImageIcon UNKNOWN_MOON_ICON = new ImageIcon(UNKNOWN_MOON_PATH, UNKNOWN_MOON_COMMENT);


    JPanel panel;
    Date date;
    JLabel icon;
    CalendarPane datePicker;

    private LunarCal() {
	super("Lunar Calendar");
	panel = new JPanel(new GridLayout(2,1));
	
	this.date = new Date();
	this.icon = new JLabel();
	this.datePicker = new CalendarPane(CalendarPane.STYLE_CLASSIC);

	this.icon.setVerticalTextPosition(JLabel.TOP);
	this.icon.setHorizontalTextPosition(JLabel.CENTER);
	this.datePicker.setShowNoneButton(false);

	setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	panel.add(this.datePicker);
	panel.add(this.icon);
	add(this.panel);

	datePicker.addActionListener(this);

	setPhase();
    }

    void setPhase() {
	int phase = phase();
	switch (phase) {
	case DARK_MOON:
	    this.icon.setText(DARK_MOON_LABEL);
	    this.icon.setIcon(DARK_MOON_ICON);
	    break;
	case NEW_MOON:
	    this.icon.setText(NEW_MOON_LABEL);
	    this.icon.setIcon(NEW_MOON_ICON);
	    break;
	case WAXING_CRESCENT_MOON:
	    this.icon.setText(WAXING_CRESCENT_MOON_LABEL);
	    this.icon.setIcon(WAXING_CRESCENT_MOON_ICON);
	    break;
	case FIRST_QUARTER_MOON:
	    this.icon.setText(FIRST_QUARTER_MOON_LABEL);
	    this.icon.setIcon(FIRST_QUARTER_MOON_ICON);
	    break;
	case WAXING_GIBBOUS_MOON:
	    this.icon.setText(WAXING_GIBBOUS_MOON_LABEL);
	    this.icon.setIcon(WAXING_GIBBOUS_MOON_ICON);
	    break;
	case FULL_MOON:
	    this.icon.setText(FULL_MOON_LABEL);
	    this.icon.setIcon(FULL_MOON_ICON);
	    break;
	case WANING_GIBBOUS_MOON:
	    this.icon.setText(WANING_GIBBOUS_MOON_LABEL);
	    this.icon.setIcon(WANING_GIBBOUS_MOON_ICON);
	    break;
	case THIRD_QUARTER_MOON:
	    this.icon.setText(THIRD_QUARTER_MOON_LABEL);
	    this.icon.setIcon(THIRD_QUARTER_MOON_ICON);
	    break;
	case WANING_CRESCENT_MOON:
	    this.icon.setText(WANING_CRESCENT_MOON_LABEL);
	    this.icon.setIcon(WANING_CRESCENT_MOON_ICON);
	    break;
	default:
	    // From MoonCalculation.java:
	    // Theoretically, this should yield a number in the range 0 .. 7.  However,
	    // two days per year, things don't work out too well.
	    System.err.println("Algorithm broken! Phase returned "+phase);
	    this.icon.setText(UNKNOWN_MOON_LABEL);
	    this.icon.setIcon(UNKNOWN_MOON_ICON);
	    break;
	}
	this.icon.repaint();
    }

    private int phase() {
	int year, month, day, phase;
	MoonCalculation moon;
	Calendar cal;

	this.date = this.datePicker.getDate();

	assert(this.date != null);//TODO

	System.out.println("Happy after setting this.date.");//TODO
	cal = new GregorianCalendar();
	System.out.println("Now:" + cal.getTime());//TODO
	System.out.println("Happy after setting cal.");//TODO
//	cal.setTime(this.date); //TODO
	System.out.println("Happy after cal.setTime.");//TODO
	year = cal.get(Calendar.YEAR);
	month = cal.get(Calendar.MONTH);
	day = cal.get(Calendar.DAY_OF_MONTH);
	System.out.println("Happy after setting year, month, day.");//TODO

	// http://www.raingod.com/raingod/resources/Programming/Java/Software/Moon/javafiles/MoonCalculation.java
	moon = new MoonCalculation();
	assert(moon!=null);//TODO
	phase = moon.moonPhase(year, month, day);
	System.out.println("Happy after setting phase.");//TODO

	return phase;
    }

    // Refactored from: http://java.sun.com/docs/books/tutorial/uiswing/misc/icon.html
    // Refactored from: http://java.sun.com/docs/books/tutorial/uiswing/components/example-1dot4/LabelDemo.java
//     static ImageIcon createImageIcon(String path, String description) {
// 	java.net.URL imgURL = LunarCal.class.getResource(path);
// 	if (imgURL != null) {
// 	    return  new ImageIcon(imgURL, description);
// 	} else {
// 	    System.err.println("Couldn't find file: " + path);
// 	    return null;
// 	}
//     }

    public void actionPerformed(ActionEvent e) {
	if (e.getSource() == this.datePicker) {
	    setPhase();
	}
    }

    public static void main(String []foo) {
	LunarCal gui;
	gui = new LunarCal();
	gui.setVisible(true);
    }
}

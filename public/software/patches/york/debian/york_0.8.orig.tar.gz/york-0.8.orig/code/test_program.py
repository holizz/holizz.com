#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: test_program.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# 
# The test program is not normally executed by York. It carries out
# various types of non-interactive regression test using demo recordings.
# 


import pygame, os, random
from pygame.locals import *


import library, demo_mq, resources, lobby_gui, lobby, lobby_setup
import game_screen, extra, scoresheet

from thread_mgr import Stop_Thread


def Test_Program(clock):
    print 'TEST MODE'

    for i in [ 1, 2 ]:
        print 'DEMO-BASED ENGINE TESTS RUNNING... TEST CASE %u' % i
        Test_Using_Demo(clock, 'test%u.sav' % i, 'tmp1', 'ss1')
        Test_Using_Demo(clock, 'tmp1', 'tmp2', 'ss2')
        Assert_Same('ss1', 'test%u.ss' % i)
        Assert_Same('ss2', 'test%u.ss' % i)
        Assert_Almost_Same('tmp1', 'tmp2')

    print 'Some tests have passed!'


def Assert_Same(f1, f2):
    fd1 = file(Fix_Path(f1))
    fd2 = file(Fix_Path(f2))
    d1 = fd1.read()
    d2 = fd2.read()
    fd1.close()
    fd2.close()
    assert ( d1 == d2 ), "'%s' and '%s' differ!" % (f1, f2)

def Assert_Almost_Same(f1, f2):
    fd1 = file(Fix_Path(f1))
    fd2 = file(Fix_Path(f2))
    d1 = 'foo'
    while ( len(d1) != 0 ):
        d1 = fd1.readline()
        d2 = fd2.readline()
        if ( d1.startswith('#') ):
            continue # ignore comments
        if ( d1.startswith('LOBBY_SLOT') ):
            continue # ignore player ids
        assert ( d1 == d2 ), "'%s' and '%s' differ too much!\n< %s\n> %s" % (
                        f1, f2, d1, d2)
    fd1.close()
    fd2.close()
       

def Fix_Path(x):
    return os.path.join('test', x)

def Test_Using_Demo(clock, demo_in, demo_out, score_sheet_out):
    print 'Test_Using_Demo("%s", "%s", "%s")' % (demo_in, demo_out,
                                                score_sheet_out)

    demo_in = os.path.join('..', Fix_Path(demo_in))
    demo_out = Fix_Path(demo_out)
    score_sheet_out = Fix_Path(score_sheet_out)

    resources.Reset()
    (demo_in_fd, mod_name) = demo_mq.Open_Demo(demo_in)
    print '  mod name: %s' % mod_name
    mod_fname = resources.Get_Mod_File_Name(mod_name)
    print '  mod file name: %s' % mod_fname
    resources.Add_Mod(mod_fname, False)

    screen = extra.Menu_Video_Mode()

    demo_out_fd = file(demo_out, 'wt')
    rules_obj = resources.Get_Rules()
    lobby_ui = lobby_gui.Lobby_Slave_Screen(rules_obj)
    host_object = lobby_setup.TCP_Host_Game(rules_obj,
        mod_name, "TEST PROGRAM", "PASSWORD",
        demo_out_fd, random.randint(26001, 30000))
    assert host_object.Is_Ok()
    lobby_net = host_object.Get_Lobby()

    Wait_For_Client_To_Get_ID(lobby_net.Get_Client_MQ())

    lobby_net.Play_Lobby_Demo(demo_in_fd, True) # resume mode
    assert not lobby_net.Client_Kicked()

    lobby_net.Test_Mode_Start_Game(
            lobby_net.Get_Client_MQ().Get_ID())

    g = game_screen.Game_Screen(screen.get_rect().size)
    g.Enable_Test_Mode()
    g.Run(screen, clock, (rules_obj,
        lobby_net.Get_Game_Information(),
        lobby_net.Get_Client_MQ(), None),
        demo_in_fd, False)

    Wait_For_Queues_To_Empty(lobby_net.Get_Client_MQ())
    Wait_For_Queues_To_Empty(lobby_net.Get_Server_MQ())
    
    pobjs = g.Test_Get_Player_Objects()
    record_list = scoresheet.Get_All_Records(pobjs)

    host_object.Stop()
    Stop_Thread(lobby_net.Get_Client_MQ())
    Stop_Thread(lobby_net.Get_Server_MQ())

    demo_in_fd.close()

    fd = file(score_sheet_out, 'wt')
    fd.write('score sheet verification\n')
    fd.write('%u player objects\n' % len(pobjs))
    for p in pobjs:
        fd.write('player %u score %u records %u\n' %
                (p.number, p.score, len(p.record)))

    fd.write('%u records\n' % len(record_list))
    for r in record_list:
        fd.write('player %u turn %u record %u score %u\n' % (
                r.player_number, r.turn_number, r.record_number, r.score))
    fd.close()


def Wait_For_Client_To_Get_ID(client_mq):
    while ( client_mq.Get_ID() == None ):
        print 'Spinning (client)...'
        if ( not client_mq.Is_Ok() ):
            self.Stop()
            raise lobby_setup.Game_Exception("Client connection error!")

        pygame.time.wait( 100 )

def Wait_For_Queues_To_Empty(mq):
    print 'Wait for queue empty',mq
    while ( True ):
        while ( mq.Receive() != None ):
            assert mq.Is_Ok()
        pygame.time.wait( 1000 )
        if ( mq.Receive() == None ):
            break

    print 'Queue empty'


#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: tile.py,v 1.1 2006/08/09 19:59:05 jack Exp $
# 
# Information about tiles. Note that only one copy of each Tile exists in the
# game at a time. Instances are done from Tile_Instance. Thus these classes
# are containers for global tile-specific functions.

import sys
import library

class Broken_Tile_Exception(Exception):
    pass

class Tile:
    "Toplevel tile"
    def __init__(self, name, rules):
        self._name = name

        # Once, we parsed the schema file here (schemas date from
        # York v0.1). However, we have got rid of schema files and
        # now take the tile data from the rules.

        (self._edge_and_region_info, self._flags, 
            self._additional_region_info) = (
                rules.Get_Tile_DB().Get_Tile_Data(name) )

    def Get_Edge_Info(self):
        return self._edge_and_region_info

    def Get_Additional_Region_Info(self):
        if ( self._additional_region_info == None ):
            return []
        return self._additional_region_info

    def Get_Flags(self):
        return self._flags

    def Get_Name(self):
        return self._name

class Tile_With_Edges(Tile):
    def __init__(self, name, rules):
        Tile.__init__(self, name, rules)
        self._edgetype = []
        for edge in self.Get_Edge_Info():
            regions = [ region_type for (region_type,n) in edge]
            type = rules.Identify_Edge(regions)
            self._edgetype.append(type)

        self._symmetry = 4

        # Compute rotational symmetry (1 - 90 deg symmetry, 2 - 180 deg symmetry, 4 - no symmetry)
        if (( self._edgetype[0] == self._edgetype[2] )
        and ( self._edgetype[1] == self._edgetype[3] )):
            if ( self._edgetype[0] == self._edgetype[1] ):
                self._symmetry = 1
            else:
                self._symmetry = 2

    def Get_Edge(self,e):
        assert ( e >= 0 ) and ( e < 4 )
        return self._edgetype[e]

    def Get_Rotational_Symmetry(self):
        return self._symmetry


class Tile_With_Edges_And_Regions(Tile_With_Edges):
    def __init__(self, name, rules):
        Tile_With_Edges.__init__(self, name, rules)
        max_reg = 0
        rtype = dict()
        self._edge_region = []
        self._non_edge_region = []

        for edge in self.Get_Edge_Info():
            regions = []
            for (region_type,region_number) in edge:
                rtype[ region_number ] = region_type
                regions.append( region_number )
            self._edge_region.append(regions)

        for (region_type,region_number,adj_list) in self.Get_Additional_Region_Info():
            if ( rtype.has_key( region_number ) ):
                raise Broken_Tile_Exception(
    "Tile " + self.Get_Name() + " region " + str(region_number) + 
    " - schema is incorrect.\n" +
    "Region " + str(region_number) + " cannot be defined twice.")

            rtype[ region_number ] = region_type
            self._non_edge_region.append((region_type,region_number))
        
        for r in rtype.keys():
            assert r >= 0
            if ( r > max_reg ):
                max_reg = r

        self._number_of_regions = max_reg + 1
        self._region_types = []
        for r in range(0,self._number_of_regions):
            if ( not rtype.has_key(r) ):
                raise Broken_Tile_Exception(
    "Tile" + self.Get_Name() + "region" + str(j) + " - schema is incorrect.\n"
    "Region " + str(r) + "is not defined.")

            self._region_types.append(rtype[ r ])

        self._Compute_Region_Adjacencies()
        self._tx_tables_built = 0

    def Get_Number_Of_Regions(self):
        return self._number_of_regions

    def Get_Edge_Regions(self,e):
        return self._edge_region[e]

    def Get_Region_Adjacencies(self,region):
        assert 0 <= region < self._number_of_regions
        return self._adjacencies[ region ]

    def _Compute_Region_Adjacencies(self):

        # 1. Edge regions.
        # It is dead easy to detect when two edge regions are adjacent,
        # as they are adjacent in the edge list.
        edge_region_list = []
        for e in [0,1,2,3,0]:
            for r in self.Get_Edge_Regions(e):
                edge_region_list.append(r)

        adjacency_list = []
        a = edge_region_list.pop()
        while len(edge_region_list) > 0:
            b = edge_region_list.pop()
            adjacency_list.append((a,b))
            a = b
   
        # 2. Additional regions. Here the adjacency information must be provided
        # by the tile schema.
        for (region_type,region_number,adj_list) in self.Get_Additional_Region_Info():
            for adj in adj_list:
                assert 0 <= adj < self._number_of_regions
                assert adj != region_number
                adjacency_list.append((region_number,adj))

        # Reduce to a set, ensuring reflexivity of each relation:
        adjacency_set = set([])
        for (a,b) in adjacency_list:
            adjacency_set |= set([(a,b)])
            adjacency_set |= set([(b,a)])

        # Indexed adjacency lists are built.
        self._adjacencies = [ [] for i in range(0,self._number_of_regions) ]
        for (a,b) in adjacency_set:
            self._adjacencies[ a ].append(b) 

    def Calculate_Region_For_Position(self,graphics_tile,(mx,my),rotation):
        # Reverse the rotation
        sz = library.BASIC_TILE_SIZE - 1
        while ( rotation != 0 ):
            mx , my = my , sz - mx
            rotation -= 1
        gr = graphics_tile.Get_Graphics_Region_For_Point(mx,my)
        if ( gr >= 0 ):
            return self.Translate_From_Graphics_Region(graphics_tile,gr)
        return -1

    def Validate_Subregion(self, graphics_tile, region):
        if ( 0 <= region < self._number_of_regions ):
            return region
        else:
            return -1

    def Get_Centre_Of_Region(self,graphics_tile,region,rotation):
        gr = self.Translate_To_Graphics_Region(graphics_tile,region)
        if ( gr < 0 ):
            return (-10,-10)
        (mx,my) = graphics_tile.Get_Centre_Of_Graphics_Region(gr)
        # Apply rotation
        sz = library.BASIC_TILE_SIZE - 1
        while ( rotation != 0 ):
            mx , my = sz - my , mx
            rotation -= 1
        return (mx,my)

    def Get_Type_Of_Region(self,region):
        if ( 0 <= region < self._number_of_regions ):
            return self._region_types[ region ]
        else:
            return '?'

    def _Build_Edge_Translation_Table(self,graphics_tile):
        if (self._tx_tables_built):
            return
        mapping = dict ()
        max_g = 0

        # Find the regions on the edge
        for e in range(0,4):
            graphics_edge = graphics_tile.Get_Graphics_Regions_For_Edge(e)
            tile_logic_edge = self.Get_Edge_Regions(e)

            if ( len(graphics_edge) != len(tile_logic_edge) ):
                raise Broken_Tile_Exception(
    "Tile " + self.Get_Name() + " edge " + str(e) + 
    " - masks are incorrect.\n" +
    "The number of regions along this edge is " + str(len(graphics_edge)) +
    " in the mask, but " + str(len(tile_logic_edge)) + " in the tile logic.")

            for (g,t) in zip(graphics_edge,tile_logic_edge):
                if ( mapping.has_key(g) ):
                    if ( mapping[ g ] != t ):
                        raise Broken_Tile_Exception(
    "Tile " + self.Get_Name() + " edge " + str(e) + 
    " - masks are incorrect.\n" +
    "Two regions are connected in the mask, " +
    "but the logic says they should not be.")
                else:
                    mapping[ g ] = t
                if ( g > max_g ):
                    max_g = g
            
        edge_region_count = self.Get_Number_Of_Regions() - len(self._non_edge_region)

        # Build translation table
        self._tx_t2g = [ -1 for i in range(0,self.Get_Number_Of_Regions()) ]
        self._tx_g2t = []
        extra_graphics_region = []
        for g in range(0,max_g + 1):
            if ( mapping.has_key(g) ):
                t = mapping[g]
                self._tx_t2g[t] = g
                self._tx_g2t.append(t)
            else:
                self._tx_g2t.append(-1)
                extra_graphics_region.append(g)

        # A warning condition:
        for i in self._tx_g2t:
            if ( i == -1 ):
                print "WARNING: Tile",self.Get_Name(),"- warning:"
                print "Non-edge graphics region list:",repr(extra_graphics_region)
                print "Non-edge tile logic region list:",repr(self._non_edge_region)
                print "Mismatch detected."

        # Translation for extra regions, too:
        for t in range(edge_region_count, self.Get_Number_Of_Regions()):
            if ( len(extra_graphics_region) > 0 ):
                g = extra_graphics_region.pop(0)
                self._tx_t2g[t] = g
                self._tx_g2t[g] = t
            else:
                g = len(self._tx_g2t)
                self._tx_t2g[t] = g
                self._tx_g2t.append(t)

        # Deal with an error condition:
        for i in self._tx_t2g:
            if ( i == -1 ):
                raise Broken_Tile_Exception(
    "Tile " + self.Get_Name() + " - masks are incorrect.\n" +
    "Tile logic region has no graphics region mapping!" +
    "\nt2g list:" + repr(self._tx_t2g) +
    "\ng2t list:" + repr(self._tx_g2t))

        self._tx_tables_built = 1

    def Translate_From_Graphics_Region(self,graphics_tile,graphics_region):
        self._Build_Edge_Translation_Table(graphics_tile)
        if ( 0 <= graphics_region < len(self._tx_g2t) ):
            return self._tx_g2t[graphics_region]
        else:
            return -1 
        
    def Translate_To_Graphics_Region(self,graphics_tile,region):
        self._Build_Edge_Translation_Table(graphics_tile)
        if ( 0 <= region < len(self._tx_t2g) ):
            return self._tx_t2g[region]
        else:
            return -1 



#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: popup.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 


import pygame, math
import resources, constants, library


class Popup:
    NOT_DRAWN = 1
    ON_SCREEN = 2
    FADING_IN = 3
    NOT_PRESENT = 4

    def __init__(self, meeple_graphics, rules, cache,
                    background_colour, (width, height)):
        self.__meeple = meeple_graphics
        self.__cache = cache
        self.__rules = rules
        self.__font = resources.Get_Font(12)
        self.__edge_margin = 5
        self.__width = width
        self.__height = height
        self.__size = (width, height)
        self.__surface = pygame.Surface(self.__size)
        self.__background_colour = background_colour

        self.__max_fade = 250
        self.__fade_speed = 40

        self.Draw_Nothing()

    def __Setup(self):
        self.__surface.fill(self.__background_colour)
        return self.__surface 

    def __Max_XY(self,x,y):
        pass
    
    def __Finish(self):
        return True

    def __Draw_Region_Stats(self,(stats_display,empty_text)):            

        # Note: drawing is attempted twice.
        # A second attempt is only necessary if the first attempt overflowed the
        # available surface size. 
        done = False
        while not done:
            stats_surf = self.__Setup()

            (item_height,meeple_width) = self.__meeple.Get_Size()
            half_item_height = item_height / 2
            y = 0
            for (rtype,rtype2,slist,points) in stats_display:
                x = 0

                if ( len(slist) != 0 ):
                    y += half_item_height
                    for player_number in slist:
                        x += meeple_width
                        self.__meeple.Draw_Meeple((x,y),
                                    player_number,1,stats_surf)
                    y += half_item_height
                    self.__Max_XY(x + meeple_width,y)

                    txt = ""
                else:
                    txt = empty_text

                txt += self.__rules.Name_For_Region_Type(rtype)
                if ( points > 0 ):
                    txt += " scored " + str(points)
                    if ( rtype != rtype2 ):
                        txt += ( " (via " + 
                            self.__rules.Name_For_Region_Type(rtype2) + ")" )

                x = 0
                txt_surf = self.__font.render(txt,True,
                    library.colours.region_stats_fg)
                stats_surf.blit(txt_surf,(x,y))
                y += txt_surf.get_rect().height
                self.__Max_XY(x + txt_surf.get_rect().width,y)

            done = self.__Finish()

    def __Draw_After_Fadeup(self,fn,params):
        self.Draw_Nothing()
        self.__fade_value = 0
        self.__fader_state = self.NOT_DRAWN
        self.__fadeup_call = fn
        self.__fadeup_params = params
 
    def __Draw_Tile_Stats(self,(example_tiles, tiles_remaining)):
        display_size = len(example_tiles)

        display_width = constants.TILE_STATS_WIDTH
        ymargin = self.__edge_margin

        tile_sum = sum([ count for (number, count) in example_tiles ])

        done = False
        while not done:
            stats_surf = self.__Setup()

            x = y = xi = 0

            if ( display_size == 0 ):
                txt = "No tiles fit here."
            else:
                txt = str(tile_sum) + " of " + str(tiles_remaining + 1) + " fit here:"
            txt_surf = self.__font.render(txt,True,
                    library.colours.tile_stats_fg)
            stats_surf.blit(txt_surf,(x,y))
            y += txt_surf.get_rect().height + ymargin
            self.__Max_XY(x + txt_surf.get_rect().width,y)

            tsz = constants.SMALL_TILE_SIZE
            for (number, count) in example_tiles:
                self.__cache.Get(number).Draw_One(stats_surf,
                            pygame.Rect(x, y, tsz, tsz), 0)
                x += tsz
                txt = "x" + str(count)
                txt_surf = self.__font.render(txt,True,
                        library.colours.tile_stats_fg)
                y2 = y + (( tsz - txt_surf.get_rect().height ) / 2 )
                stats_surf.blit(txt_surf,(x,y2))
                x += tsz

                self.__Max_XY(x,y + tsz)

                xi += 1
                if ( xi >= display_width ):
                    xi = x = 0
                    y += tsz + ymargin

            done = self.__Finish()

    def Render(self,surf,(x,y)):
        if ((( self.__fader_state == self.FADING_IN )
        or ( self.__fader_state == self.ON_SCREEN ))):
            m = self.__edge_margin
            surf.blit(self.__surface,(x,y))
    
    def Fade_Up(self):
        if ( self.__fader_state == self.NOT_DRAWN ):
            self.__fade_value += self.__fade_speed
            if ( self.__fade_value > self.__max_fade ):
                # Time to do the drawing work.
                self.__fadeup_call( self.__fadeup_params )
                self.__fadeup_call = None
                # Then fade in
                self.__fader_state = self.FADING_IN
                self.__fade_value = 0

        elif ( self.__fader_state == self.FADING_IN ):
            self.__fade_value += self.__fade_speed
            if ( self.__fade_value > 255 ):
                self.__fader_state = self.ON_SCREEN

    def Draw_Nothing(self):
        self.__fade_value = 0
        self.__fader_state = self.NOT_PRESENT

    def Draw_Region_Stats(self,stats_display,empty_text="Empty "):
        if ( len(stats_display) == 0 ):
            self.Draw_Nothing()
        else:
            #self.__Draw_After_Fadeup(self.__Draw_Region_Stats,(stats_display,empty_text))
            self.__Draw_Region_Stats((stats_display,empty_text))
            self.__fader_state = self.ON_SCREEN

    def Draw_Tile_Stats(self,example_tiles,tiles_remaining):
        #self.__Draw_After_Fadeup(self.__Draw_Tile_Stats,(example_tiles, tiles_remaining))
        self.__Draw_Tile_Stats((example_tiles, tiles_remaining))
        self.__fader_state = self.ON_SCREEN

    def Draw_Tooltip(self, text):
        self.__fader_state = self.ON_SCREEN
        tts = self.__Setup()
        y = 0
        for txt in text.split('\n'):
            txt_surf = self.__font.render(txt,True,
                        library.colours.region_stats_fg)
            tts.blit(txt_surf, (0, y))
            y += txt_surf.get_rect().height

        done = self.__Finish()
        assert done




#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: fig2png.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 

import os
import constants

mogrify_params = "" # "-antialias"

def Fig2Png():
    # These images appear in the base resource file.
    # You can override them in your own resource files.
    figs = [ "chat.fig" ,
            "magcursor.fig" ,
            "menu.fig" ,
            "ok.fig" ,
            "remain.fig" ,
            "score.fig" ,
            "skipmeeple.fig" ,
            "nextturn.fig" ,
            "undo.fig" ,
            "zoom.fig" ,
            "pencil.fig" ]

    sz = constants.MENU_ICON_SIZE_B

    for fig_name in figs:
        png_name = fig_name
        x = png_name.find('.')
        assert x > 0
        png_name = png_name[ 0:x ] + ".png"
        temp_name = "temp.png"
        os.system("fig2dev -L png %s > %s" % (fig_name, temp_name))
        os.system("convert " + mogrify_params + 
            " -resize %ux%u %s %s" % (sz, sz, temp_name, png_name))
        os.unlink(temp_name)
    

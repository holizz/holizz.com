#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: place_menu.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# 

import pygame 
from pygame.locals import *

import board_graphics , meeple_graphics , library , resources , constants


class Place_Menu(board_graphics.Board_Graphics):
    def __init__(self, surface, cache, game, gui_msg_fn, sidebar, background):
        self.__cache = cache

        board_graphics.Board_Graphics.__init__(self,
                surface, cache, game, gui_msg_fn, sidebar, background)

        self.__current_player = None
        self.__preview_drawing = None
        self.__surface = surface
        self.__game = game
        self.__menu_graphics = None
        self.__caption_graphics = None
        self.__menu_data = None
        self.__menu_rects = None
        self.__menu_choice = None
        self.__menu_graphics_rect = None
        self.__icon_name_graphics = None
        self.__rotation_choices = None
        self.__caption_pos = (0,0)

        self.__num_players = self.__game.Get_Num_Players()
        self.__meeples = meeple_graphics.Meeple(
                            library.MENU_ICON_SIZE,
                            self.__num_players)

        self.__font = resources.Get_Font(18)
    
        # set up the size of the tile previews:
        self.Scale(self.__cache.Get_Size())

    def Draw(self):
        board_graphics.Board_Graphics.Draw(self)
        self.Draw_Menu()
        self.__surface.blit(self.__caption_graphics, self.__caption_pos)

    def Draw_Menu(self):
        self.__game.Read_Lock(True)
        self.__current_player = self.__game.Get_Current_Player()
        self.__preview_drawing = self.__game.Get_Preview_Drawing()
        new_menu_data = self.__game.Get_Display_Menu()
        self.__game.Read_Lock(False)

        if (( new_menu_data != self.__menu_data )
        or ( self.__menu_graphics == None )):
            self.__Redraw_Icon_Name('')
            self.__Redraw_Menu(new_menu_data)
            self.__menu_choice = None

        sr = self.__surface.get_rect()
        mr = self.__menu_graphics_rect
        ir = self.__icon_name_graphics.get_rect()
        ir.centerx = sr.centerx
        ir.bottom = mr.top

        # This rect, block, covers the entire selection area.
        block = Rect(2, ir.top, sr.width - 4, sr.height - ( ir.top + 2 ))
        pygame.draw.rect(self.__surface, library.colours.place_menu_bg, block)
        

        self.__surface.blit(self.__menu_graphics, mr.topleft)

        if ( self.__menu_choice != None ):
            (item, rect, icon_name) = self.__menu_choice
            pygame.draw.rect(self.__surface, 
                library.colours.place_menu_highlight, rect, 1)

        self.__surface.blit(self.__icon_name_graphics, ir.topleft)
        cr = block.move(0, - self.__caption_graphics.get_rect().height)
        self.__caption_pos = cr.topleft


    def Mouse_Move_Event(self, (sx,sy)): 
        for (item, rect, icon_name) in self.__menu_rects:
            if ( rect.collidepoint((sx,sy)) ):
                new_choice = (item, rect, icon_name)
                if ( self.__menu_choice != new_choice ):
                    self.__Redraw_Icon_Name(icon_name)
                self.__menu_choice = new_choice
                return
        board_graphics.Board_Graphics.Mouse_Move_Event(self, (sx, sy))
        


    def Click_Event(self, (sx,sy)):
        # Clicked on a menu option?
        self.__menu_choice = None
        self.Mouse_Move_Event((sx,sy))
       
        if ( self.__menu_choice != None ):
            (item, rect, icon_name) = self.__menu_choice

            self.__game.Mouse_Click(item, (0,0), (0,0))
            self.__menu_choice = None
            return

        board_graphics.Board_Graphics.Click_Event(self, (sx, sy))

    def __Redraw_Icon_Name(self, icon_name):
        self.__icon_name_graphics = self.__font.render(icon_name, True, 
                library.colours.icon_name_fg)
        
    GAP_WIDTH = library.MENU_ICON_SIZE / 4

    [ R_CCW , R_CW , R_CONFIRM , R_UNDO ] = [ 0, 1, 2, -1 ]

    def __Redraw_Menu(self, menu_data):
        # Examine menu type
        if ( menu_data == None ):
            menu_type = 'z'
            menu_items = [ self.R_UNDO ]
        else:
            (menu_type, menu_items) = menu_data

        # Rotation menus get reordered.
        if ( menu_type == 'r' ):
            if ( 3 in menu_items ):
                menu_items = [ m for m in menu_items if m != 3 ]
                menu_items.insert(0, 3)

        # Drawing code.
        w = ( len(menu_items) * ( library.MENU_ICON_SIZE + self.GAP_WIDTH )) - self.GAP_WIDTH
        if ( w < 1 ):
            w = 1

        self.__menu_data = menu_data
        self.__menu_rects = []
        mg = self.__menu_graphics = pygame.Surface((w, library.MENU_ICON_SIZE))
        mg.fill(library.colours.place_menu_bg)

        sr = self.__surface.get_rect()
        mr = mg.get_rect()
        mr.centerx = sr.centerx
        mr.bottom = sr.bottom - 1

        x = 0
        for item in menu_items:
            r = Rect(x, 0, library.MENU_ICON_SIZE, library.MENU_ICON_SIZE)
            (file_name, icon_name) = self.__Get_Icon_Name(menu_type, item)
            pygame.draw.rect(mg, (0,0,0), r)
            
            self.__Draw_Extra_Pre(mg, menu_type, item, r)

            if ( file_name != None ):
                ri = resources.Get_Resource_Image(file_name, r.size)
                mg.blit(ri, r.topleft)

            self.__Draw_Extra_Post(mg, menu_type, item, r)

            r = r.move(mr.topleft)
            self.__menu_rects.append((item, r, icon_name))

            x += self.GAP_WIDTH + library.MENU_ICON_SIZE

        self.__caption_graphics = self.__font.render(self.__Get_Menu_Name(
                    menu_type), True, 
                    library.colours.place_menu_caption_fg)

        self.__menu_graphics_rect = mr



                
    def __Draw_Extra_Post(self, mg, menu_type, item, r):
        if (( menu_type == 'm' ) and ( item >= 0 )):
            self.__meeples.Draw_Meeple(r.center,
                    self.__current_player, False, mg)

    def __Draw_Extra_Pre(self, mg, menu_type, item, r):
        if (( menu_type == 'r' ) and ( 0 <= item <= 3 )):
            # Basic button
            ri = resources.Get_Resource_Image("ui/basic_button.png",
                    (library.MENU_ICON_SIZE, library.MENU_ICON_SIZE))
            mg.blit(ri, r.topleft)
            
            # Plus tile (rotated appropriately)
            if ( self.__preview_drawing != None ):
                (ignore1, ((number, rotation), ignore2)) = self.__preview_drawing

                self.__cache.Get(number).Draw_One(mg, r, 
                            ( rotation + item ) % 4)
            # Rotation arrow is overlaid on top of this.


    def __Get_Menu_Name(self, menu_type):
        if ( menu_type == 'm' ):
            return 'Place a meeple...'
        elif ( menu_type == 'c' ):
            return 'Confirm move...'
        elif ( menu_type == 'r' ):
            return 'Select tile rotation...'
        elif ( menu_type == 'z' ):
            return 'Zoom...'
        else:
            return ''

    def __Get_Icon_Name(self, menu_type, item):
        if ( menu_type == 'm' ):
            if ( item >= 0 ):
                return ("ui/skipmeeple.png", "Don't place a meeple")
        elif ( menu_type == 'c' ):
            if ( item >= 0 ):
                return ("ui/ok.png", 'Confirm move')
        elif ( menu_type == 'r' ):
            if ( item == 3 ):
                return ("ui/ccw.png", 'Rotate anticlockwise')
            elif ( item == 0 ):
                return (None, "No rotation")
            elif ( item == 1 ):
                return ("ui/cw.png", 'Rotate clockwise')
            elif ( item == 2 ):
                return ("ui/cw.png", 'Rotate 180 degrees')
        elif ( menu_type == 'z' ):
            return ("ui/ok.png", "Zoom out")

        return ("ui/undo.png", "Undo move")
        
        






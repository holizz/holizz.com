#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: message_window.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# Message windows.
#
# The message window may be used in two modes. In one, it is a PGU widget
# that can be embedded in a GUI layout, e.g. lobby screen. In the other,
# it is an overlay window for the game screen. 
# 

import pygame, collections, threading
import library, resources, extra, time

from pygame.locals import *
from pgu import gui

MESSAGE_HISTORY_SIZE = 120
MAX_MESSAGES = 150


class Message_Window(gui.Container):
    def __init__(self, (w, h), dtime, widget_mode, **params):
        assert widget_mode # non-widget mode no longer supported

        params[ 'width' ] = w
        params[ 'height' ] = h
        gui.Container.__init__(self, **params)

        self.__sb = gui.VScrollBar(0, 0, MESSAGE_HISTORY_SIZE, 10,
                height=h)
        (w1, h1) = self.__sb.resize()
        w2 = w - w1
        self.__mww = self.Message_Window_Widget((w2 - 1, h),
                background=library.colours.message_surface)
        self.add(self.__mww, 0, 0)
        self.add(self.__sb, w2, 0)
        self.__sb.connect(gui.CHANGE, self.__Scroll, None)
        self.__sb.value = MESSAGE_HISTORY_SIZE

    class Message_Window_Widget(gui.Widget):
        def __init__(self, (w, h), **params):
            params[ 'width' ] = w
            params[ 'height' ] = h
            gui.Widget.__init__(self, **params)

            self.__box_size = (w, h)
            self.__messages = []
            self.__messages_lock = threading.Semaphore()
            self.__message_redraw = True
            self.__force_update = False
            self.__message_surface = pygame.Surface(self.__box_size)
            self.__scroll_pos = 0


        def Message(self, msg, colour):
            # Message is thread safe. Call it from anywhere at any time
            # (except Message itself).
            msg = extra.Filter_Message(msg)
            if (( msg == None ) or ( len(msg) == 0 )):
                return

            sender_id = None

            tt = time.time()
            tm = time.localtime(tt)
            tcode = ":".join([ "%02u" % t for t in tm[3:6] ]) 
            msg = " [%s] %s" % (tcode, msg)

            self.__messages_lock.acquire()
            self.__message_redraw = True
            self.__messages.append([msg, None, colour])
            self.__force_update = True
            self.__messages_lock.release()

        def Draw_Messages(self, surf):
            self.__messages_lock.acquire()
            on_screen = True
            change_flag = False

            # message boxing algorithm
            if ( self.__message_redraw ):
                change_flag = True

                font = resources.Get_Font(12)

                MARGIN = 4
                (width, height) = self.__box_size
                library.Edge_Bevel_Effect(self.__message_surface,
                        library.colours.message_surface, 
                        library.colours.message_edge_gamma)

                if ( len(self.__messages) > MAX_MESSAGES ):
                    self.__messages = self.__messages[ 
                            -MESSAGE_HISTORY_SIZE: ]
               
                len_limited = min(len(self.__messages), MESSAGE_HISTORY_SIZE)
                bottom_message = 1 + max(5, min((( 
                        self.__scroll_pos * len_limited) /
                                MESSAGE_HISTORY_SIZE ), 
                        len(self.__messages) - 1))

                # Have the messages been rendered yet?
                for m in reversed(self.__messages):
                    if ( m[1] != None ):
                        # go no further - messages past this point are rendered
                        break
                    else:
                        msg = m[0]
                        colour = m[2]

                        word_list = msg.split()
                        word_list.reverse() # as pops from the right are more
                                            # efficient
                        x = 0
                        line = []
                        text_surf = []
                        x_limit = width - ( MARGIN * 2 )
                        max_h = 0

                        def Out(): 
                            text_surf.append(font.render(" ".join(line), 
                                            True, colour))

                        while ( len(word_list) != 0 ):
                            word = word_list.pop()
                            (w, h) = font.size(word + " ")
                            x += w
                            if ( x > x_limit ):
                                Out()
                                x = w # space gives a little extra left margin
                                line = [ word ]
                            else:
                                line.append(word)
                            if ( h > max_h ):
                                max_h = h
                        Out()
                       
                        if ( len(text_surf) == 1 ):
                            all_surf = text_surf[ 0 ]
                        else:
                            all_surf = pygame.Surface((x_limit,
                                        max_h * len(text_surf)))
                            all_surf.fill((0, 0, 0))
                            all_surf.set_colorkey((0, 0, 0))
                            for (y, ts) in enumerate(text_surf):
                                y *= max_h
                                all_surf.blit(ts, (0, y))

                        m[1] = all_surf

                # Render messages
                y = height - MARGIN
                for m in reversed(self.__messages[ :bottom_message ]):
                    h = m[1].get_rect().height
                    if ( y <= -h ):
                        # Disappeared off the top - stop writing!
                        break
                    y -= h
                    self.__message_surface.blit(m[1], (MARGIN, y))

                # plus box..
                #pygame.draw.rect(self.__message_surface,
                        #library.colours.message_border,
                        #self.__message_surface.get_rect(), 1)

            # Draw it
            if ( on_screen ):
                surf.blit(self.__message_surface, (0, 0))
            self.__messages_lock.release()

            return change_flag

        def Get_Message_Update(self):
            self.__messages_lock.acquire()
            fu = self.__force_update 
            self.__force_update = False
            self.__messages_lock.release()
            return fu

        def paint(self, s):
            self.Draw_Messages(s)

        def update(self, s):
            if ( self.Draw_Messages(s) ):
                return [ s.get_rect() ]
            else:
                return []

        def event(self, e):
            pass

        def resize(self,width=None,height=None):
            return self.__box_size

        def Clear(self):
            self.__messages_lock.acquire()
            self.__messages.clear()
            self.__messages_lock.release()

        def Scroll(self, pos):
            self.__messages_lock.acquire()
            self.__scroll_pos = pos
            self.__message_redraw = True
            self.__messages_lock.release()

    def __Scroll(self, *args):
        self.__mww.Scroll(self.__sb.value)

    def Clear(self):
        self.__mww.Clear()

    def Get_Message_Update(self):
        return self.__mww.Get_Message_Update()

    def Message(self, msg, colour):
        self.__mww.Message(msg, colour)


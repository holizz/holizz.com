#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: tile_cache.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# Tile Cache.  
# 

import tile_graphics , library

# Each tile cache works for a particular size.
class Tile_Cache:
    "Holds copies of all tile graphics."
    def __init__(self, rules, feeder_cache=None):
        assert feeder_cache == None # not supported any more.
        self.__tc = dict()
        self.__tc_list = []
        self.__sz = library.BASIC_TILE_SIZE
        self.__rules = rules

    def __Load(self, name):
        nt = tile_graphics.Tile_Graphics(name, self.__rules)
        nt.Scale(self.__sz)
        self.__tc[ name ] = nt
        self.__tc_list.append(nt)
        return nt

    def Get(self, name):
        nt = self.__tc.get(name, None)
        if ( nt == None ):
            return self.__Load(name)
        else:
            if ( nt.Get_Size() != self.__sz ):
                nt.Scale(self.__sz)
            return nt

    def Scale(self,sz):
        self.__sz = sz

    def Get_Size(self):
        return self.__sz

    def Flush(self):
        for nt in self.__tc_list:
            nt.Flush()



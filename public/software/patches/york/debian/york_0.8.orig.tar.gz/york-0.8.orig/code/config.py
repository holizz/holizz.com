# 
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: config.py,v 1.1 2006/08/09 19:59:13 jack Exp $

import pygame, pickle, sys, os
import startup, sound, library, extra, whitelist

from pygame.locals import *

CFG_VERSION = 4

class Config:
    def __init__(self):
        # Default settings:
        self.version = library.Version()
        self.cfg_version = CFG_VERSION
        self.sound_volume = sound.Get_Max_Volume()
        self.seen_before = False
        self.history = []
        self.name = ""
        self.game_name = ""
        self.game_password = ""
        self.tile_mod = None

        self.remaining_tile_count = 'default'
        self.video_resolution = '800x600'
        self.fullscreen = True
        self.server_port = str(library.DEFAULT_PORT)
        self.trusted = dict()


cfg = Config()


class Init_Exception(Exception):
    pass


def Add_Game_To_History(ginfo):
    if (( ginfo != None )
    and ( ginfo.Is_Valid() )):
        for (i, gi2) in enumerate(cfg.history):
            if ( gi2.address == ginfo.address ):
                print 'Added to history index',i
                cfg.history[ i ] = ginfo
                return
        cfg.history.append(ginfo)


def Get_User_Dir():
    home = extra.Get_Home()
    if ( home == None ):
        home = os.getcwd()
    return os.path.abspath(os.path.join(home, ".York"))

def Get_CFG_Filename():
    return os.path.join(Get_User_Dir(), "York.cfg")

def Get_Exception_File():
    return os.path.join(Get_User_Dir(), "errors.txt")

def Get_Recordings_Dir():
    return os.path.join(Get_User_Dir(), "recordings")

def Initialise():
    global cfg

    ud = Get_User_Dir()
    if ( not os.path.exists(ud) ):
        try:
            os.mkdir(ud)
        except:
            raise Init_Exception("Unable to create user directory %s." % ud)
        
    write_ex = "Unable to write to user directory %s." % ud
    rd = Get_Recordings_Dir()
    if ( not os.path.exists(rd) ):
        try:
            os.mkdir(rd)
        except:
            raise Init_Exception(write_ex)

    # Try to read configuration - this is allowed to fail.
    fn = Get_CFG_Filename()
    try:
        f = file(fn, "rb")
        cfg2 = pickle.load(f)
        f.close()
        if ( cfg2.cfg_version == CFG_VERSION ):
            # Configuration is valid, we can use it.
            cfg = cfg2

        try:
            x = cfg.tile_mod
        except:
            cfg.tile_mod = None
    except Exception, x:
        pass

    # Try to write configuration - this must not fail.
    if ( not Save() ):
        raise Init_Exception(write_ex)
    

def Save():
    global cfg

    fn = Get_CFG_Filename()
    try:
        f = file(fn, "wb")
        pickle.dump(cfg, f)
        f.close()
        return True
    except Exception, x:
        return False


def Get_Set_Mode_Flags():
    global cfg
    flags = 0
    if ( cfg.fullscreen
    and ( not "--window" in sys.argv )):
        flags |= FULLSCREEN
    return flags

def Get_Video_Res(res=None):
    if ( res == None ):
        res = cfg.video_resolution
    l = res.split('x')
    if ( len(l) != 2 ):
        return library.MENU_RESOLUTION
    try:
        x = int(l[ 0 ])
        y = int(l[ 1 ])
    except:
        return library.MENU_RESOLUTION

    return (x, y)





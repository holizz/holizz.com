#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: game_logic_driver.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# Game Logic Driver. See class for details.
# 


import copy, random, traceback, sys, md5
import game_logic, library, tile, tile_instance, extra, constants


NO_MORE_TILES = 'end.of.bag'


class Game_Logic_Driver:
    """
    Board_Logic <--- Game_Logic <--- Game_Logic_Driver 
                                        YOU ARE HERE
                                           <--- Board_Graphics <---- Main Loop

    This class contains a state machine that is designed to work in 
    lock-step with equivalent state machines on the computers of the 
    other players. This is where the game meets the network (via the 
    Message_Queue class, in fact).

    There are two modes for this class. In master mode, instances act
    as master state machines, picking the next tile and enforcing the
    turn order. In slave mode, instances work as user interfaces.

    Game modifications that need to change the turn order must
    make extensions to the state machine. To do this, subclass
    existing State functions. The State functions should all end by
    returning a pointer to the next function, or by calling Expect_Message,
    or by returning None. Returning None forces a repeat of the state.
    Be aware that Expect_Message returns None if no message is waiting:
    states that end in Expect_Message may repeat an unlimited number of
    times. Also, never trust any part of any message you receive over the 
    network.

    """

    def __init__(self, rules, game_info, gui_msg_fn, progress_fn,
                cache, message_queue, master):
        
        # Start up
        self.__rules = rules
        self.__game_info = game_info
        self.__num_players = len(self.__game_info.player_names)
        self.__cache = cache
        self.__mq = message_queue
        self.__is_master = master
        self.message_fn = gui_msg_fn
        self.progress_fn = progress_fn
        self.__game_ready = False
        self.__game_ready_enable = False

        self.__ids_required = set([ id
                for id in self.__game_info.player_ids 
                if ( id != None ) ])

        if ( self.__is_master ):
            self.message_fn = lambda x: None

        self.__rules.Reset()

        # Start up synchronisation code
        self.__debug_sync_calls = ( '--desync' in sys.argv )
        self.__sync = md5.new()
        self.Sync(self.__num_players)

        # Build tileset. The Rules control the stacking order
        # and the contents of the stack. It is important that all
        # players build stacks with the same contents, in the same
        # initial order, as consistent tile numbering must be in use.
        self.__master_tile_stack = []
        self.__tile_bag = []
        mini_cache = dict() 
        for name in self.__rules.Build_Stack(game_info.subgame):
            if ( mini_cache.has_key(name) ):
                t = mini_cache[ name ]
            else:
                t = tile.Tile_With_Edges_And_Regions(name, self.__rules)
                mini_cache[ name ] = t
            ti = tile_instance.Tile_Instance(t, self.__rules)
            self.__master_tile_stack.append(ti)
            self.__tile_bag.append(ti)

        
        self.__tile_bag.sort()
        self.__remaining = len(self.__tile_bag)

        # Sync check - do all players have the same tile bag?
        for ti in self.__tile_bag:
            self.Sync(ti.Get_Name())

        if ( not self.__is_master ):
            # The slave doesn't have a tile stack. 
            self.__master_tile_stack = None

        # Lower level game logic
        self.__game_logic = game_logic.Game_Logic(
                        self.__rules, self.__num_players)
        self.__game_logic_copy = None

        # Who am I?
        self.__local_id = self.__mq.Get_ID()
        if ( not self.__is_master ):
            assert self.__local_id != None
            assert self.__local_id > 0

        # State machine/UI init
        self.__Init()
        self.__game_over = False
        self.__state = self.State_Boot
        self.__player = -1
        self.__turn_number = 0
        self.__current_tile = None
        self.__position_stats = dict()
        self.__display_menu = None
        self.__probabilities = []
        self.ui_mode = self.FINISHED

        # Other debugging
        self.__debug_game_sends = ( '--desends' in sys.argv )
        self.__debug_states = ( '--destates' in sys.argv )

        # Board limits
        self.__max_x = 0
        self.__max_y = 0
        self.__min_x = 0
        self.__min_y = 0

    def Check_For_Drops(self):
        if ( self.__is_master ):
            # Master version - check for remote players who have dropped
            # due to quit or network error. Should ignore observers who drop.
            ids_present = set(self.__mq.Get_ID_List())
            dropped = self.__ids_required - ids_present
            if (( not self.__game_over )
            and ( len(dropped) > 0 )):
                player_list = [ self.__Id_To_Name(id)[ 0 ] for id in dropped ]
                self.Send_Master_Message(
                        'The following players have dropped from the game: ' +
                        self.__List_Players(player_list))
                self.Send_Master_Message(
                        "The game cannot continue without all players. " +
                        "If you would like to finish the game, rehost it " +
                        "and select the 'Resume from Recording' option.")
                self.Send(self.ABNORMAL_STOP_CODE)
                self.__state = self.State_Aborted
                return
        else:
            # Slave version - is the network connection still ok?
            if (( not self.__mq.Is_Ok() )
            and ( not self.__game_over )):
                self.message_fn("Network error - disconnected!")
                self.message_fn("You have been disconnected from the game.")
                self.__state = self.State_Aborted
                return


    # Tick() is called in order to cause state machine transitions.
    def Tick(self):
        self.Check_For_Drops()

        if ( self.__is_master ):
            # Don't waste memory storing special effects
            self.__game_logic.Get_Special_Effects() 


        new_state = None
        try:
            new_state = self.__state(self.__is_master)

        except self.Desync, r:
            self.__state = self.State_Nothing_Happens
            self.message_fn('Sync error: ' + str(r))
            if ( self.__is_master ):
                self.Send_Master_Message('Game out of sync: ' + str(r))
                self.Send_Master_Message(
                        "This game cannot continue. However, you may be " +
                        "able to restore the game before the error by " +
                        "rehosting it and selecting the " +
                        "'Resume from Recording' option.")
            self.Send(self.ABNORMAL_STOP_CODE)

        except self.Abort_Game, r:
            self.__state = self.State_Aborted
            self.message_fn(str(r))
            if ( self.__is_master ):
                self.Send_Master_Message(str(r))
            self.Send(self.ABNORMAL_STOP_CODE)

        if (( new_state != None )
        and ( new_state != self.__state )):
            if ( self.__debug_states ):
                self.__Print_ID()
                print 'state change to',new_state

            self.__state = new_state
            return True
        else:
            return False # No state change

    def __Print_ID(self):
        if ( self.__is_master ):
            print 'master',
        else:
            print 'slave %u' % self.__local_id,

    # State machine states
    def State_Boot(self, master):
        STARTUP_MESSAGE = "startupgame"
        if ( master ):
            self.Send(STARTUP_MESSAGE)
            self.Send_Master_Message("The game has begun. Good luck!")
            return self.State_Begin_Turn
        else:
            return self.Expect_Message(STARTUP_MESSAGE, 
                        0, self.Handle_Startup_Message)

    def Handle_Startup_Message(self, sender_id):
        return self.State_Begin_Turn

    def State_Begin_Turn(self, master):
        for i in xrange(self.__num_players):
            # Find the next player. Order of players is the
            # same as the order of colours.
            self.__player = ( self.__player + 1 ) % self.__num_players
            if ( self.__game_info.player_ids[ self.__player ] != None ):
                break

        if ( self.__game_info.player_ids[ self.__player ] == None ):
            self.Desync("No active players?")

        self.__turn_number += 1
        self.__game_logic.Set_Turn_Number(self.__turn_number)
        self.__game_logic.Set_Current_Player(self.__player)

        self.Sync(self.__player)
        self.Sync(self.__turn_number)

        return self.State_Demo_Recorder_Checkpoint_1

    def State_Demo_Recorder_Checkpoint_1(self, master):

        DEMO_CHECKPOINT_1 = "chk1"

        self.__game_ready = self.__game_ready_enable

        if ( master ):
            # Checkpoints in two parts.
            # This part is not encapsulated - it is caught by the
            # demo playback mechanism and may cause the execution
            # of Slave_To_Master.
            self.__mq.Send(constants.RAW_CHECKPOINT_MESSAGE)
            # This part is a regular message causing a state transition.
            self.Send(DEMO_CHECKPOINT_1)

            return self.State_Demo_Recorder_Checkpoint_2
        else:
            return self.Expect_Message(DEMO_CHECKPOINT_1, 
                        0, self.Handle_Demo_Recorder_Checkpoint_1)

    def Handle_Demo_Recorder_Checkpoint_1(self, sender_id):
        return self.State_Demo_Recorder_Checkpoint_2

    def State_Demo_Recorder_Checkpoint_2(self, master):
        return self.State_Wait_For_Tile

    def State_Wait_For_Tile(self, master):
        # Note, if adding states 

        NEXT_TILE_IS = "nexttileis"

        if ( master ):
            # Master must pick a tile at this point.
            tn = NO_MORE_TILES
            while True:
                if ( len(self.__tile_bag) == 0 ):
                    # Game ends.
                    break
                self.__current_tile = ti = self.__master_tile_stack.pop()
                ti2 = self.Remove_Tile_From_Bag(ti.Get_Name())
                assert ti2 != None

                rc = self.__game_logic.Set_Tile(ti)

                if ( rc ):
                    tn = ti.Get_Name()
                    break
                else:
                    self.Send_Master_Message(
                "Game rejected a tile (%s) that did not fit." % ti.Get_Name())

            self.Send(NEXT_TILE_IS, tn)

            if ( tn == NO_MORE_TILES ):
                return self.State_End_Game

            return self.State_Init_UI
        else:
            return self.Expect_Message(NEXT_TILE_IS, 
                        1, self.Handle_Next_Tile_Is, True)

    def Handle_Next_Tile_Is(self, sender_id, tn):
        if ( tn == NO_MORE_TILES ):
            return self.State_End_Game

        ti = self.__current_tile = self.Remove_Tile_From_Bag(tn)
        if ( ti == None ):
            raise self.Desync(
                    "Game requested tile %s which was not in the bag." % tn)

        rc = self.__game_logic.Set_Tile(ti)

        if ( not rc ):
            raise self.Desync("Game requested tile that can't be placed.")

        return self.State_Init_UI

    def __Init(self):
        self.__preview_tile = None
        self.__highlighted_region = None
        self.__preview_meeple_pos = None
        self.__current_stats = None
        self.__current_stats_updated = False
        self.__current_stats_position = None
        self.__force_update_ui = True
        self.ui_mode = self.PLACE_TILE
        self.__cur_player_id = 0
        self.__my_turn = False
        self.__last_tx = self.__last_ty = 0
        self.__display_menu = None
        self.__move_data = None

    def State_Init_UI(self, master):
        # Ok, now we have a tile.

        self.__Init()
        self.__cur_player_id = self.__game_info.player_ids[ self.__player ]
        self.__my_turn = ( self.__cur_player_id == self.__local_id )
        self.__game_logic_copy = copy.deepcopy(self.__game_logic)
        self.__game_logic_copy.Get_Special_Effects() # Remove sfx from undo copy

        if ( master ):
            self.Send_Master_Message(
                    self.__game_info.player_names[ self.__player ] + 
                            ", your turn has started.")

        return self.State_Set_UI_Mode

    def State_Set_UI_Mode(self, master):
        UI_MODE_IS = "uimodeis"
        if ( master ):
            self.Send(UI_MODE_IS, self.ui_mode)

            if ( self.ui_mode == self.FINISHED ):
                return self.State_Begin_Turn

            return self.State_Get_Move
        else:
            return self.Expect_Message(UI_MODE_IS, 
                        1, self.Handle_UI_Mode_Is, True)

    def Handle_UI_Mode_Is(self, sender_id, ui_mode):
        self.ui_mode = ui_mode
        if ( self.ui_mode == self.FINISHED ):
            return self.State_Begin_Turn

        return self.State_Get_Move

    SLAVE_MOUSE_CLICK = "slavemouse"
    MASTER_MOUSE_CLICK = "mastermouse"

    def State_Get_Move(self, master):
        if ( master ):
            return self.Expect_Message(self.SLAVE_MOUSE_CLICK,
                    4, self.Master_Handle_Mouse_Click)
        else:
            return self.Expect_Message(self.MASTER_MOUSE_CLICK,
                    5, self.Slave_Handle_Mouse_Click)

    def Master_Handle_Mouse_Click(self, sender_id, tx, ty, region, choice):
        assert self.__is_master
        if ( sender_id == self.__cur_player_id ):
            self.Send(self.MASTER_MOUSE_CLICK,
                    tx, ty, region, choice, sender_id)
            self.__move_data = (tx, ty, region, choice, sender_id)
            return self.State_Do_Move

        # Not correct id.. this is a mouse click from the wrong player.
        return self.State_Get_Move

    def Slave_Handle_Mouse_Click(self, master_id, 
                        tx, ty, region, choice, player_id):
        assert not self.__is_master
        self.__move_data = (tx, ty, region, choice, player_id)
        return self.State_Do_Move

    def State_Do_Move(self, master):
        (tx, ty, region, choice, player_id) = self.__move_data
        self.__Print_ID()
        print 'State_Do_Move',self.__move_data

        if (( choice != None ) and ( choice < 0 )):
            # Undo move.
            self.__game_logic = copy.deepcopy(self.__game_logic_copy)
            self.ui_mode = self.PLACE_TILE
            self.__display_menu = None
            self.__Compute_Probabilities()
            self.__preview_tile = None
            self.__highlighted_region = None
            self.__preview_meeple_pos = None
            self.__move_data = None
            return self.State_Set_UI_Mode

        rc = None

        if ( self.ui_mode == self.PLACE_TILE ):
            rc = self.__game_logic.Place_Tile(self.__cache,
                        choice, (tx,ty), region)
            self.__last_tx = tx
            self.__last_ty = ty

        elif ( self.ui_mode == self.CHOOSE_ROTATION ):
            rc = self.__game_logic.Choose_Rotation(self.__cache,
                        choice, (tx,ty), region)

        elif (( self.ui_mode == self.PLACE_MEEPLE )
        or ( self.ui_mode == self.CONFIRM )):
            rc = self.__game_logic.Place_Meeple_And_Confirm(self.__cache,
                        choice, (tx,ty), region, self.__Scoring_Msg_Fn)

        self.__Print_ID()
        print rc
        if ( rc != None ):
            (sel, choices) = rc
            if ( sel == 'r' ):
                self.ui_mode = self.CHOOSE_ROTATION

            elif (( sel == 'c' ) or ( sel == 'm' )):
                if ( sel == 'c' ):
                    self.ui_mode = self.CONFIRM
                else:
                    self.ui_mode = self.PLACE_MEEPLE
                self.__Compute_Probabilities()

            elif ( sel == '!' ):
                self.ui_mode = self.FINISHED

                # Only expand now.
                self.__max_x = max(self.__last_tx, self.__max_x)
                self.__max_y = max(self.__last_ty, self.__max_y)
                self.__min_x = min(self.__last_tx, self.__min_x)
                self.__min_y = min(self.__last_ty, self.__min_y)

            if ( self.__my_turn ):
                self.__display_menu = rc
            else:
                self.__display_menu = None

        self.__force_update_ui = True
        self.Sync(rc)
        return self.State_Set_UI_Mode

    def State_End_Game(self, master):
        (top_score, winner_list) = self.__game_logic.End_Game(
                        self.__cache,self.__Scoring_Msg_Fn)
        assert len(winner_list) > 0  

        self.__Init()
        self.ui_mode = self.GAME_OVER

        winner_name = self.__List_Players([ self.__game_info.player_names[ n ] 
                            for n in winner_list])
        if ( len(winner_list) == 1 ):
            txt = winner_name + " is the winner, with "
        else:
            txt = winner_name + " are joint winners, with "
        txt += str(top_score) + " points."
        self.__force_update_ui = True
        self.__game_logic.Final_Score(txt)
        if ( master ):
            self.Send_Master_Message(txt)
        return self.State_Nothing_Happens

    def State_Nothing_Happens(self, master):
        self.__game_over = True
        return self.Expect_Message("no such message", # (message is impossible)
                    0, self.Handle_Nothing_Happens)

    def Handle_Nothing_Happens(self, id):
        return self.State_Nothing_Happens

    def State_Aborted(self, master):
        self.__game_over = True
        return self.Expect_Message("no such message",
                    0, self.Handle_Aborted)

    def Handle_Aborted(self, id):
        return self.State_Aborted

    # Message transmission and reception.
    # All messages begin with:
    #    GAME <sync code> <message type>
    # which is then followed by a variable number of parameters

    MESSAGE_SEPARATOR = ' '
    MESSAGE_STARTS = 'YRK'
    MASTER_MESSAGE_CODE = "mastersays"
    MASTER_CHAT_MESSAGE_CODE = "chatmsg"
    CHAT_MESSAGE_CODE = "chatreq"
    ABNORMAL_STOP_CODE = "STOP"
    PLACE_TILE = "pt"
    CHOOSE_ROTATION = "cr"
    PLACE_MEEPLE = "pm"
    FINISHED = "fi"
    GAME_OVER = "eg"
    CONFIRM = "ok"
    UI_MODES = [ PLACE_TILE , CHOOSE_ROTATION , GAME_OVER ,
                PLACE_MEEPLE , CONFIRM , FINISHED ]

    def Expect_Message(self, expect_message_type,
            expect_message_length, message_handler,
            string_message=False):

        msg_and_sender_id = self.__mq.Receive()
        if ( not self.__mq.Is_Ok() ):
            raise self.Abort_Game("Network error - game aborted.")

        if ( msg_and_sender_id == None ):
            return None

        (msg, sender_id) = msg_and_sender_id
        msg_fields = msg.split(self.MESSAGE_SEPARATOR)

        if (( len(msg_fields) < 3 )
        or ( msg_fields[ 0 ] != self.MESSAGE_STARTS )):
            if ( msg == constants.RAW_GAME_READY_MESSAGE ):
                self.__game_ready_enable = True
                print 'Game ready enable True'
                print 'current state is',self.__state
            elif ( msg.startswith(constants.RAW_PROGRESS_MESSAGE) ):
                if ( not self.Is_Game_Over() ):
                    try:
                        v = int(msg[ len(constants.RAW_PROGRESS_MESSAGE): ])
                        self.progress_fn(v, constants.PROGRESS_BASE)

                    except ValueError:
                        pass

            return None # not valid message
       
        message_length = len(msg_fields) - 3
        check_sync = msg_fields[ 1 ]
        message_type = msg_fields[ 2 ]
        parameters = msg_fields[ 3: ]
        
        if ( message_type == expect_message_type ):
            if (( sender_id != self.__cur_player_id )
            and self.__is_master ):
                if ( self.__debug_game_sends ):
                    print 'Rejected message from wrong id (%u)' % sender_id
                return None

            if ( expect_message_length != message_length ):
                raise self.Desync(
    "Expected message of type %s to be of length %u, but received %u." %
    (expect_message_type, expect_message_length, message_length))

            if ( not string_message ):
                # string -> (integer/None) conversion
                for i in xrange(len(parameters)):
                    v = parameters[ i ]
                    if ( v == str(None) ):
                        v = None
                    else:
                        try:
                            v = int(v)
                        except ValueError:
                            raise self.Desync(
    "Game message of type %s: parameter %u is malformed." %
    (expect_message_type, i))
                    parameters[ i ] = v

            if (( check_sync != self.Get_Sync() )
            and ( not self.__is_master )):
                errmsg = ( "%s (id %u) out of sync. Got %s, not %s." %
                        (self.__Id_To_Name(sender_id)[ 0 ], sender_id, 
                        check_sync, self.Get_Sync()) )
                self.Send(self.CHAT_MESSAGE_CODE, errmsg)
                raise self.Desync("Sync code check failed: %s" % errmsg) 

            return message_handler(sender_id, *parameters)

        else:
            parameters = self.MESSAGE_SEPARATOR.join(parameters)
            if ( message_type == self.MASTER_MESSAGE_CODE ):
                if ( not self.Is_Muted() ):
                    self.message_fn(parameters)
            elif ( message_type == self.MASTER_CHAT_MESSAGE_CODE ):
                if ( not self.Is_Muted() ):
                    self.Decode_Chat_Message(parameters)
            elif ( message_type == self.CHAT_MESSAGE_CODE ):
                if ( self.__is_master ):
                    self.Send(self.MASTER_CHAT_MESSAGE_CODE,
                        str(sender_id) + ": " + parameters)
            elif ( message_type == self.ABNORMAL_STOP_CODE ):
                if ( not self.__is_master ):
                    raise self.Abort_Game("Game halted.")
            return None
            
    def Send(self, type_code, *parameters):
        msg_fields = [ self.MESSAGE_STARTS,
                        self.Get_Sync(), type_code ] + [
                    str(i) for i in parameters ]
        msg = self.MESSAGE_SEPARATOR.join(msg_fields)
        if ( self.__debug_game_sends ):
            self.__Print_ID()
            print msg
        self.__mq.Send(msg)

    def Decode_Chat_Message(self, msg):
        # Chat message. Begins with 'sender id:'.
        x = msg.find(':')
        if ( x <= 0 ):
            return
        ok = True
        for i in msg[ 0:x ]:
            ok = ok and i.isdigit()
        if ( not ok ):
            return # Malformed message

        sender_id = int(msg[ 0:x ])
        msg = msg[ 2+x: ]

        (player_name, colour) = self.__Id_To_Name(sender_id)
        
        if ( colour == None ):
            return # Bogus message from unknown player id?

        self.message_fn(player_name + ": " + msg, colour)

    def __Id_To_Name(self, sender_id):
        if ( self.__game_info.id_to_col_and_name.has_key( sender_id ) ):
            return self.__game_info.id_to_col_and_name[ sender_id ]
        else:
            return ("Unknown id %u" % sender_id, None)

    def Sync(self, values):
        self.__sync.update(repr(values))

        # Python is wonderful.
        if ( self.__debug_sync_calls ):
            self.__Print_ID()
            print 'sync:',repr(values),
            print 'becomes',self.Get_Sync(),'when called at'
            traceback.print_stack(limit=4, file=sys.stdout)

    def Get_Sync(self):
        return self.__sync.hexdigest()[:8]

    class Desync(Exception):
        def __init__(self,msg):
            self.msg = msg
    
        def __str__(self):
            return str(self.msg)

    class Abort_Game(Exception):
        def __init__(self,msg):
            self.msg = msg
    
        def __str__(self):
            return str(self.msg)

    def Send_Master_Message(self, msg):
        assert self.__is_master
        self.Send(self.MASTER_MESSAGE_CODE, msg)


    def Send_Chat_Message(self,msg):
        if ( len(msg) > 100 ):
            msg = msg[ :100 ]
        if ( len(msg) == 0 ):
            return

        msg = extra.Launder_Message(msg)
        self.Send(self.CHAT_MESSAGE_CODE, msg)

    # User interface.
    def Mouse_Move(self, choice, (tx,ty), (mx, my)):
        assert not self.__is_master
        rc = None
        region = self.__game_logic.Convert_Minor_XY_To_Subregion(
                self.__cache, (tx, ty), (mx, my))
        if ( self.__my_turn ):
            if ( self.ui_mode == self.PLACE_TILE ):
                rc = self.__game_logic.Mouse_Over_Place_Tile(
                        self.__cache, choice, (tx,ty), region)
            elif ( self.ui_mode == self.CHOOSE_ROTATION ):
                rc = self.__game_logic.Mouse_Over_Rotate_Tile(
                        self.__cache, choice, (tx,ty), region)
            elif ( self.ui_mode == self.PLACE_MEEPLE ):
                rc = self.__game_logic.Mouse_Over_Place_Meeple(
                        self.__cache, choice, (tx,ty), region)
            else: # confirm, game over, etc.
                rc = self.__game_logic.Mouse_Over_Default(
                        self.__cache, choice, (tx,ty), region)
        else:
            rc = self.__game_logic.Mouse_Over_Default(
                    self.__cache, choice, (tx,ty), region)

        force_update = False

        if ( rc == None ):
            self.__preview_tile = None
            self.__highlighted_region = None
            self.__preview_meeple_pos = None
            self.__current_stats = None
            self.__current_stats_updated = ( self.__current_stats != None )
        else:
            (prev, hr, self.__preview_meeple_pos) = rc
            if (( prev != None ) 
            or ( self.ui_mode != self.CHOOSE_ROTATION )): 
                # "sticky" previews in choose rotation mode
                self.__preview_tile = prev

            old_stats = self.__current_stats

            if (( hr != self.__highlighted_region )
            or ( self.__current_stats_position != (tx,ty) )):
                self.__highlighted_region = hr
                if ( hr != None ):
                    (r,x,y) = hr
                    # Region-specific stats are available!
                    self.__current_stats = (True, 
                        self.__game_logic.Get_Region_Statistics(r))
                else:
                    # Position specific stats?
                    if ( self.__position_stats.has_key((tx,ty)) ):
                        self.__current_stats = (False, 
                                self.__position_stats[ (tx,ty) ])
                    else:
                        # No stats available.
                        self.__current_stats = None

                self.__current_stats_updated = ( 
                        self.__current_stats != old_stats )


        self.__current_stats_position = (tx,ty)
        return rc

    def Mouse_Click(self,choice, (tx,ty), (mx, my)):
        assert not self.__is_master

        if ( not self.__game_ready ):
            return

        if ( self.ui_mode != None ):
            # LATER - don't send mouse clicks unless it is your turn.
            # We are not doing that for now, because we don't want to hide
            # bugs in the message muxer.
            region = self.__game_logic.Convert_Minor_XY_To_Subregion(
                    self.__cache, (tx, ty), (mx, my))
            self.Send(self.SLAVE_MOUSE_CLICK, tx, ty, region, choice)

    def __List_Players(self,player_list):
        player_list = [ x for x in player_list if ( x != None ) ]
        if ( len(player_list) == 0 ):
            return '<empty>'
        final = player_list.pop()

        if ( len(player_list) == 0 ):
            return final

        return ', '.join(player_list) + ' and ' + final

    def __Scoring_Msg_Fn(self,preamble,player_list,postscript,score):
        self.message_fn(preamble + ": " + 
                self.__List_Players([ self.__game_info.player_names[ n ] 
                        for n in player_list ]) + 
                " " + postscript + " " + str(score) + " points." )

    def __Compute_Probabilities(self):

        self.__remaining = len(self.__tile_bag)
        p = self.__game_logic.Get_Probabilities(self.__tile_bag)
        self.__probabilities = [ (position, probability) 
                    for (position, probability, example_tiles) in p ]

        self.__position_stats.clear()
        for ((tx,ty), probability, example_tiles) in p:
            self.__position_stats[ (tx,ty) ] = example_tiles
        
    def __UI_Mode_Is(self,test):
        return ( test == self.ui_mode )

    def Is_Placing_Tile(self):
        return self.__UI_Mode_Is(self.PLACE_TILE)

    def Is_Rotating_Tile(self):
        return self.__UI_Mode_Is(self.CHOOSE_ROTATION)

    def Is_Placing_Meeple(self):
        return self.__UI_Mode_Is(self.PLACE_MEEPLE)

    def Is_Confirming(self):
        return self.__UI_Mode_Is(self.CONFIRM)

    def Is_Game_Over(self):
        return self.__UI_Mode_Is(self.GAME_OVER)

    def Get_Map_Bounds(self):
        out = ((self.__min_x,self.__min_y), (self.__max_x,self.__max_y))
        return out

    def Get_Preview_Drawing(self):
        return self.__preview_tile

    def Get_Preview_Meeple_Position(self):
        return self.__preview_meeple_pos

    def Get_Probabilities(self):
        return self.__probabilities

    def Get_Tile_Draw_List(self):
        g = self.Is_Game_Over()
        return self.__game_logic.Get_Tile_Draw_List(g)

    def Get_Player_HUD_Info(self):
        out = [ (name,num,score,meeples,str(info))
            for (name,num,(score,meeples,info)) in zip(
                        self.__game_info.player_names,
                        xrange(self.__num_players),
                        self.__game_logic.Get_Player_HUD_Info())
            if ( name != None ) ]
        return out
   
    def Get_Num_Players(self):
        return self.__num_players

    def Get_Current_Player(self):
        cp = self.__game_logic.Get_Current_Player()
        return cp 

    def Get_Current_Tile_Name(self):
        return self.__game_logic.Get_Current_Tile_Name()

    def Get_Set_Of_Possible_Placements(self):
        return self.__game_logic.Get_Set_Of_Possible_Placements()
        
    def Is_Region_Empty(self,r):
        return self.__game_logic.Is_Region_Empty(r)

    def Get_Special_Effects(self):
        sfx = self.__game_logic.Get_Special_Effects()
        return sfx

    def Is_Highlighted_Region_Empty(self):
        if ( self.__highlighted_region == None ):
            f = True
        else:
            (region,draw_list,r_type) = self.__highlighted_region
            f = self.__game_logic.Is_Region_Empty(region)
        return f

    def Get_Highlight_Draw_List(self):
        if ( self.__highlighted_region == None ):
            draw_list = []
        else:
            (region,draw_list,r_type) = self.__highlighted_region
            #draw_list = copy.deepcopy(draw_list)
        return draw_list

    def Get_Display_Menu(self):
        return self.__display_menu

    def Get_Num_Remaining_Tiles(self):
        return self.__remaining

    def Get_Update_Flag(self):
        f = self.__force_update_ui 
        self.__force_update_ui = False
        return f

    def Get_Current_Statistics(self):
        return self.__current_stats

    def Have_Statistics_Changed(self):
        x = self.__current_stats_updated
        self.__current_stats_updated = False
        return x

    def Get_New_Tiles(self):
        return self.__game_logic.Get_New_Tiles()

    def Not_Local_Player(self,player_num):
        return ( self.__local_id != self.__game_info.player_ids[ player_num ] )

    def Max_Meeples(self):
        return self.__rules.Max_Meeples()

    def Get_Player_Objects(self):
        return self.__game_logic.Get_Player_Objects()

    def Get_Player_Names(self):
        return self.__game_info.player_names
    
    def Get_Turn_Number(self):
        return self.__turn_number

    def Read_Lock(self, x):
        # This 'feature' was removed when Game_Logic_Driver ceased
        # being a thread and turned into a state machine.
        # Good thing too, it was absolutely horrible.
        pass

    def Stop(self):
        # Nothing to stop.
        pass

    def Slave_To_Master(self, server_mq):
        # A demo has reached the final checkpoint before the end or another
        # resume point.
        # We are therefore making the transition from slave (demo playing)
        # mode to master (game playing) mode. The result is a new
        # preconfigured instance of Game_Logic_Driver, for use as the master.
        # The current instance continues as the client of the current player.
        # Thus, games are resumed from demos. This only happens during 
        # the call to self.__mq.Hit_Checkpoint(self.Slave_To_Master) so
        # the next state is always known.

        assert self.__state == self.State_Demo_Recorder_Checkpoint_1, (
            "state is actually %s" % str(self.__state))

        master_instance = self.__class__(self.__rules,
                    self.__game_info, self.message_fn, self.progress_fn,
                    self.__cache, server_mq, True)

        master_instance.__Init()
        master_instance.__state = (
            master_instance.State_Demo_Recorder_Checkpoint_1 )
        master_instance.__player = self.__player
        master_instance.__turn_number = self.__turn_number
        master_instance.ui_mode = self.ui_mode
        master_instance.__game_logic = copy.deepcopy(self.__game_logic)
        master_instance.__game_logic_copy = copy.deepcopy(self.__game_logic)
        master_instance.__sync = self.__sync.copy()

        if ( self.__debug_sync_calls ):
            print 'Slave to master transition:'
            print 'Slave sync:',self.Get_Sync()
            print 'Master sync:',master_instance.Get_Sync()

        # Slave -> Master tile bag copy. We can't just shuffle the slave
        # tile bag and copy it because the master tile stack may need to
        # be arranged in a particular way, e.g. for river expansion.

        new_master_stack = []
        new_slave_stack = []
        for master_tile in reversed(master_instance.__master_tile_stack):
            slave_tile = self.Remove_Tile_From_Bag(master_tile.Get_Name())
            if ( slave_tile != None ):
                new_master_stack.append(master_tile)
                new_slave_stack.append(slave_tile)
        assert len(self.__tile_bag) == 0

        new_master_stack.reverse()
        new_slave_stack.reverse()

        new_master_tile_bag = []
        new_slave_tile_bag = []
        for (master_tile, slave_tile) in zip(
                        new_master_stack, new_slave_stack):
            new_master_tile_bag.append(master_tile)
            new_slave_tile_bag.append(slave_tile)
            
        self.__tile_bag = new_slave_tile_bag
        master_instance.__tile_bag = new_master_tile_bag
        master_instance.__master_tile_stack = new_master_stack
        master_instance.Send_Master_Message(
                "Game resumed from recording. %u tiles still in bag." % (
                            len(new_slave_tile_bag)))
        self.__tile_bag.sort()
        master_instance.__tile_bag.sort()

        return master_instance

    def Get_Tile_Bag(self):
        # Don't change the tile bag! This is for viewing only.
        return self.__tile_bag 

    def Is_Muted(self):
        return not self.__game_ready

    def Is_Game_Over(self):
        return self.__game_over

    def Is_Ready(self):
        return self.__game_ready

    def Remove_Tile_From_Bag(self, name):
        for i in reversed(xrange(len(self.__tile_bag))):
            ti = self.__tile_bag[ i ]
            if ( ti.Get_Name() == name ):
                self.__tile_bag.pop(i)
                return ti
        return None
        



# 
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: sound.py,v 1.1 2006/08/09 19:59:13 jack Exp $


import pygame 
from pygame.locals import *

import resources

__vol = 1

def Get_Max_Volume():
    return 100

def Get_Sound_Volume():
    global __vol
    return int(__vol * Get_Max_Volume())

def Set_Sound_Volume(v):
    global __vol
    v = v / float(Get_Max_Volume())
    if ( v < 0 ):
        v = 0
    if ( v > 1 ):
        v = 1
    __vol = v

def FX(name):
    s = resources.Load_Sound(name) # (comes from a cache)
    if ( s != None ):
        v = Get_Sound_Volume()
        if ( v > 0 ):
            s.set_volume(v)
            s.play()



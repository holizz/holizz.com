#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: board_logic.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# Board Logic.  Low-level rulechecking, and board database management.
#
# This is one of the oldest modules in York. You can spot the older modules
# because they have been designed with a poorer understanding of Python.
# Here, we see attributes using a single underscore to signify 'private',
# 0 and 1 being used in place of False and True, and various other suboptimal
# statements.
# 

import re
import library , tile_instance , tile_graphics 

class Board_Logic:
    """
    Board_Logic <--- Game_Logic <--- Game_Logic_Driver <--- Board_Graphics <---- Main Loop
    YOU ARE HERE

    This is the lowest level of game machinery. Enforces the low-level placement 
    rules, and maintains a tile database allowing moves to be validated and
    scores computed in O(len(self._tile_list)) time.
    """
    
    def __init__(self,rules):
        self._rules = rules
        self._tiles = dict()
        self._adjacencies = [ [] ] 
        self._region_number = 1
        self._region_owner = [ 0 ]
        self._region_contents = [ set([]) ]
        self._region_open_ends = [ set([]) ]
        self._region_occupiers = [ set([]) ]
        self._tile_list = []
        self._tile_for_region = [ None ]
        self._closed_regions = set([])
        self._meeple_set = set([])
        self._all_possible_placements = set([])
        self._regex_cache = dict()

    def Can_Place(self,tile_instance,(x,y)):
        if ( len(self._tile_list) == 0 ):
            if (( x == 0 ) and ( y == 0 )):
                return range(0, 4)
            else:
                return []

        # Is there a tile there already?
        if ( self._tiles.has_key((x,y)) ):
            return []

        # Is there a neighbouring tile?
        neighbour = 0
        for i in [ (x,y-1), (x,y+1), (x-1,y), (x+1,y) ]:
            neighbour = neighbour or self._tiles.has_key(i)
        if ( not neighbour ):
            return []

        # Check special placement rules, if any.
        out = self._rules.Get_Possible_Rotations(tile_instance, (x, y), self)

        if ( len(out) == 0 ):
            return out

        # Check edges.
        out2 = []
        rs = tile_instance.Get_Rotational_Symmetry()
        for i in xrange(4):
            if (( i < rs ) and ( i in out )):
            
                edges = tile_instance.Get_All_Edges()
                if ( self._Try_Edges(edges, (x,y)) ):
                    out2.append(i)

            tile_instance.Rotate()

        return out2


    def Get_Set_Of_Allowed_Rotations(self,tile_instance,(x,y)):
        return set(self.Can_Place(tile_instance, (x, y)))

    def Place_Tile(self,tile_instance,(x,y)):
        # Sanity check:
        assert len(self.Can_Place(tile_instance,(x,y))) != 0

        tile_instance.Set_Region_Offset(self._region_number)

        # The master region map is updated
        start = self._region_number
        finish = start + tile_instance.Get_Number_Of_Regions()
        for i in range(start,finish):
            # Initially, each region only contains itself, and owns itself too.
            self._region_contents.append(set([i]))
            self._region_owner.append(i)
            self._region_open_ends.append(set()) # done later
            self._region_occupiers.append(set())
            self._adjacencies.append(tile_instance.Get_Region_Adjacencies(i))
            self._tile_for_region.append(((x,y),tile_instance))

        self._region_number = finish

        # Sanity check:
        for i in [self._region_contents,self._region_owner,
                self._region_open_ends,self._region_occupiers,
                self._adjacencies,self._tile_for_region]:
            assert ( len(i) == self._region_number )

        # Put it on the map and tile list
        self._tiles[(x,y)] = tile_instance
        self._tile_list.append(((x,y),tile_instance))

        closures = set()
        neighbours = [((x-1,y),3),((x+1,y),1),((x,y-1),0),((x,y+1),2)]

        # Update the possible placement set
        # (done before region merging so we can detect open ends, or lack thereof)
        self._all_possible_placements.discard((x, y))
        for (ot_key,edge) in neighbours:
            if ( not self._tiles.has_key(ot_key) ):
                self._all_possible_placements.add(ot_key)
                l = tile_instance.Get_Edge_Regions(edge)
                for rnum in l:
                    self._region_open_ends[rnum].add(ot_key)


        # Does this placement satisfy any special completion rules?
        for special_completion in self._rules.Get_Special_Completions(
                    tile_instance, (x, y), self):
            closures.add(special_completion)
                    
        # Region merging along edges
        merges = set([])
        for (ot_key,edge) in neighbours:
            if self._tiles.has_key(ot_key):
                ot = self._tiles[ot_key]
                ot_edge = ( edge + 2 ) % 4

                assert tile_instance.Get_Edge(edge) == ot.Get_Edge(ot_edge)

                ot_regions = ot.Get_Edge_Regions(ot_edge)
                nt_regions = reversed(tile_instance.Get_Edge_Regions(edge))
                assert len(ot_regions) == len(nt_regions)

                for (otr,ntr) in zip(ot_regions,nt_regions):
                    merges |= set(self._Region_Merge(otr,ntr))

        # Did any merges result in a closure?
        # Note: must check this after merging is complete!
        for r in merges:
            if ( len(self._region_open_ends[self.Find_Region_Owner(r)]) == 0 ):
                closures.add(r)

        # Eliminate equivalents in closure set
        closures = set([ self.Find_Region_Owner(x) for x in closures ])
        self._closed_regions |= closures

        # Where can we place a meeple on this tile?
        # Regions must be empty and of a suitable type.
        meeple_regions = set()
        for local in xrange(start, finish):
            if ( self.Can_Place_In_Region(local) ):
                meeple_regions.add(local)

        return (list(closures), list(meeple_regions))

    def Can_Place_In_Region(self, region):
        region = self.Find_Region_Owner(region)

        ((x, y), tile) = self._tile_for_region[region]

        return (( len(self._region_occupiers[region]) == 0 )
            and ( self._rules.Can_Place_In_Region(
                    tile.Get_Type_Of_Region(region)) ))

            
    def Find_Region_Owner(self,r):
        assert ( r != 0 )
        ro = self._region_owner[r]
        while ro != r:
            r = ro
            ro = self._region_owner[r]
        assert ( ro != 0 )
        return ro

    def _Region_Merge(self,or1,or2):
        r1 = self.Find_Region_Owner(or1)
        r2 = self.Find_Region_Owner(or2)
        if ( r2 == r1 ):
            return []
        elif ( r2 > r1 ):
            r1,r2 = r2,r1

        # r2 is merged into r1. Note: r1 > r2.
        # Thus the owner of any region is always the most recently
        # placed part of that region. This is important elsewhere.
        self._region_contents[r1] |= self._region_contents[r2]
        self._region_occupiers[r1] |= self._region_occupiers[r2]
        self._region_open_ends[r1] = ( self._region_open_ends[r2] | 
                self._region_open_ends[r1] ) & self._all_possible_placements
        self._region_owner[r2] = r1
        self._region_contents[r2] = set([])
        self._region_occupiers[r2] = set([])
        self._region_open_ends[r2] = set([])


        # Allows faster referencing
        self._region_owner[or2] = r1
        self._region_owner[or1] = r1

        return [r1]
    

    def _Try_Edges(self,edges,place):
        # Fast string matching for a single edge (described as a string)
        agg = self._Edges_For_Missing_Tile(place)
        for i in range(0,4):
            x = agg[i]
            y = edges[i]
            if (( x != '.' ) and ( x != y )):
                return 0
        return 1

    def _Edges_For_Missing_Tile(self,(tx,ty)):
        agg = "" 
        for (place,edge) in [ ((tx,ty-1),2), ((tx+1,ty),3), ((tx,ty+1),0), ((tx-1,ty),1) ]:
            if ( not self._tiles.has_key(place)) :
                # Any edge is acceptable
                agg = agg + "."
            else:
                agg = agg + self._tiles[place].Get_Edge(edge)
        return agg

    def Get_Set_Of_Possible_Placements(self,tile_instance):
        # A subset of self._all_possible_placements is returned,
        # containing only the places valid for this tile.

        if ( len(self._tile_list) == 0 ):
            return [(0,0)]

        subset = set()
        edges = tile_instance.Get_All_Edges()
        edges += edges

        # Edge check:
        for rotation in xrange(tile_instance.Get_Rotational_Symmetry()):
            for place in self._all_possible_placements:
                if (( not ( place in subset ))
                and ( self._Try_Edges(edges[rotation:], place))):
                    subset.add(place)

        # Special rules check:
        subsubset = set()
        for place in subset:
            if ( len(self.Can_Place(tile_instance, place)) != 0 ):
                subsubset.add(place)

        return subsubset

    def _Find_Unique_Edge_Configurations(self, tile_bag, edge_function):
        counts = dict()
        out_list = []
        for thing in tile_bag:
            edges = str(edge_function(thing))
            edges = edges + edges
            seen_before = False

            for i in xrange(4):
                if ( counts.has_key(edges[ i : ( i + 4 ) ]) ):
                    seen_before = True
                    break

            edges = edges[ i : ( i + 4 ) ]

            if ( seen_before ):
                counts[ edges ].append(thing)
            else:
                counts[ edges ] = [ thing ]
                out_list.append(edges)

        return [ counts[ edges ] for edges in out_list ]

    def Compute_Probabilities(self,tile_bag):
        # Find all tiles that could fit in each possible position.

        places_to_examine = self._Find_Unique_Edge_Configurations(
                self._all_possible_placements,self._Edges_For_Missing_Tile)
        tiles_to_examine = self._Find_Unique_Edge_Configurations(
                tile_bag,lambda tile: tile.Get_All_Edges())
        if (( 0 == len(tiles_to_examine)) or ( 0 == len(places_to_examine) )):
            return []

        output = []

        for place_list in places_to_examine:
            place = place_list[ 0 ]
            required = str(self._Edges_For_Missing_Tile(place))

            if ( self._regex_cache.has_key(required) ):
                m = self._regex_cache[ required ]
            else:
                m = self._regex_cache[ required ] = re.compile(required)

            correct_edge_tiles = []

            # This initial scan only uses edges.
            # Places and tiles that have the same edges are all
            # compared at the same time.
            for tile_list in tiles_to_examine:
                possible = tile_list[ 0 ].Get_All_Edges()
                if ( m.search(possible + possible) != None ):
                    correct_edge_tiles.extend(tile_list)

            # Note: No need to worry about exposing the bag order -
            # it's only the master tile stack that must be secret.

            # The next scan will bring in mod-specific placement
            # rules, e.g. monastery rule.
            if ( len(correct_edge_tiles) != 0 ):
                # Classify each tile in correct_edge_tiles by
                # tile name - this is particularly easy as
                # correct_edge_tiles is in bag order.

                classified_tiles = []
                last_tile = None
                count = 0
                for tile in correct_edge_tiles:
                    if (( last_tile != None )
                    and ( tile.Get_Name() == last_tile.Get_Name() )):
                        count += 1
                    else:
                        if ( last_tile != None ):
                            classified_tiles.append((last_tile, count))
                        count = 1
                        last_tile = tile

                assert last_tile != None
                classified_tiles.append((last_tile, count))

                for place in place_list:

                    can_place_tiles = []
                    hits = 0
                    for (tile, count) in classified_tiles:
                        if ( len(self._rules.Get_Possible_Rotations(
                                    tile, place, self)) != 0 ):
                            can_place_tiles.append((tile.Get_Name(), count))
                            hits += count
                    
                    if ( len(can_place_tiles) != 0 ):
                        output.append((place, hits,
                                    can_place_tiles))

        return output

    def Get_Occupied_Regions(self):
        out = []
        for region in range(0,len(self._region_occupiers)):
            if ( len(self._region_occupiers[ region ]) != 0 ):
                out.append(region)
        return out

    def Get_Adjacent_Closed_Regions(self,region):
        region = self.Find_Region_Owner(region)
        adj_set = set([])
        for subregion in self._region_contents[region]:
            adj_set |= set(self._adjacencies[ subregion ])
        adj_set_2 = set([])
        for adj_subregion in adj_set:
            ((x,y),tile) = self._tile_for_region[adj_subregion]
            adj_type = tile.Get_Type_Of_Region(adj_subregion)
            adj_region = self.Find_Region_Owner(adj_subregion)
            if ( adj_region in self._closed_regions ):
                adj_set_2 |= set([(adj_region, adj_type)])
        return list(adj_set_2)

    def Get_Tile_List(self):
        return self._tile_list

    def Get_Tile_At(self,tx,ty):
        if ( self._tiles.has_key((tx,ty)) ):
            return self._tiles[(tx,ty)]
        else:
            return None

    def Get_Tiles_In_Region(self,region):
        return [ (self._tile_for_region[r],r) for r in self._region_contents[region] ]

    def Get_Meeples_In_Region(self,region):
        return self._region_occupiers[self.Find_Region_Owner(region)]

    def Empty_Region(self,region):
        region = self.Find_Region_Owner(region)
        self._region_occupiers[ region ] = set([])

        for (((tx,ty),tile),subregion) in self.Get_Tiles_In_Region(region):
            m = tile.Get_Meeple()
            if (( m != None ) and ( self.Find_Region_Owner(m.Get_Region()) == region )):
                self._meeple_set -= set([((tx,ty),m)])
                tile.Remove_Meeple()

    def Place_Meeple(self,tile_instance,(tx,ty),graphics_tile,region,meeple):
        tile_instance.Place_Meeple(graphics_tile,region,meeple)
        self._meeple_set |= set([((tx,ty),meeple)])
        self._region_occupiers[self.Find_Region_Owner(region)] |= set([meeple])


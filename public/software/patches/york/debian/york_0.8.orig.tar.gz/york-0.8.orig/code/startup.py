#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: startup.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 

# Python version check. 2.4.x or higher is required.
# This also checks your Pygame version (after Python)
# Earlier versions *might* work but I haven't tested them...
# 2.4 is certainly required for built-in set() support.

import sys

def Check_Version(check_for_pgu):
    fault = False
    if ( sys.__dict__.has_key("version_info" ) ):
        (major, minor, micro, releaselevel, serial) = sys.version_info
        if (( major < 2 )
        or (( major == 2 ) and ( minor < 4 ))):
            fault = True
    else:
        major = 1
        minor = 0
        fault = True

    if ( fault ):
        print ""
        print "Python version 2.4 or higher is required."
        print "You appear to be using version",(str(major) + "." + str(minor))
        print "Please install the latest version from http://www.python.org/"
        sys.exit(1)
    
    try:
        import pygame
    except:
        print ""
        print "Pygame does not appear to be installed."
        print "Please install the latest version from http://www.pygame.org/"
        sys.exit(1)
  
    try:
        # God damn! The size of this field changed between 
        # ver. 1.6 and ver. 1.7. Arrgh. 
        [major, minor] = list(pygame.version.vernum)[ 0:2 ]
        x = pygame.version.ver
    except:
        print ""
        print "Pygame is installed, but you have an old version."
        print "Please install the latest version from http://www.pygame.org/"
        sys.exit(1)

    if (( major < 1 )
    or ( major == 1 ) and ( minor < 7 )):
        print ""
        print "Pygame version 1.7.x or higher is required."
        print "Please install the latest version from http://www.pygame.org/"
        sys.exit(1)

    if ( check_for_pgu ):
        try:
            from pgu import gui
        except:
            print ""
            print "Unable to load PGU."
            print "PGU is included with York... but it's not available.."
            print "York is confused."
            sys.exit(1)

    print "Python version",sys.version,"- good"
    print "Pygame version",pygame.version.ver,"- good"

def Main_Ready():
    import main, extra
    error_msg = extra.Run_Managed(main.Main, None, False)

    if ( len(error_msg) != 0 ):
        print error_msg
        main.Exception_Display(error_msg)

    extra.Shutdown()


def Main():
    print "Now checking your Python environment:"
    Check_Version(True)

    # Psyco is optional, but recommended :)
    if ( not "--no-psyco" in sys.argv ):
        try:
            import psyco
            psyco.profile()
        except Exception, r:
            print 'Psyco not found. If the game runs too slowly, '
            print 'install Psyco from http://psyco.sf.net/'

    import library

    print ''
    print ''
    print 'York. Copyright (C) Jack Whitham 2006.'
    print 'This is free software, provided under the GNU GPL version 2.'
    print 'You are playing version',library.Version()
    print ''

    Main_Ready()

    #if ( "--profile" in sys.argv ):
        #import profile
        #profile.run('startup.Main_Ready()', 'york.profile')
    #else:




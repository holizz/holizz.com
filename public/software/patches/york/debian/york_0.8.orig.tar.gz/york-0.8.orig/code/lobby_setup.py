#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: lobby_setup.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# 
# The top level code for hosting games.
# 


import pygame
import lobby, server, client, config, message_queue, demo_mq, thread_mgr



class Game_Exception(Exception):
    def __init__(self,msg):
        self.msg = msg

    def __str__(self):
        return str(self.msg)



class TCP_Host_Game:
    def __init__(self, rules, mod_name, user_name, password, 
                        demo_recording_stream, port=None):
        self.__lobby = None
        self.__demo_recorder = None

        if ( port == None ):
            port = int(config.cfg.server_port)

        # Game server:
        server_mq = server.Server() 

        if ( demo_recording_stream == None ):
            # Regular client/demo player message queue:
            client_mq = demo_mq.Demo_MQ(None) 
        else:
            # Demo recording client:
            self.__demo_recorder = client_mq = (
                demo_mq.Demo_MQ(demo_recording_stream) )

        self.__mqs = [ server_mq, client_mq ]

        error_msg = server_mq.Host(port, mod_name, password)

        unknown = "unknown error"
        loopback = "localhost"

        if ( not server_mq.Is_Ok() ):
            self.Stop()

            if ( error_msg == None ):
                error_msg = unknown

            raise Game_Exception("Unable to start server on port %u: %s" % (
                    port, error_msg))

        print 'Start lobby.'
        lobby_net = lobby.Lobby(rules, client_mq, server_mq)

        # Wait for server to become ready to service connections
        while ( not server_mq.Is_Open() ):
            print 'Spinning (server)...'
            if ( not server_mq.Is_Ok() ):
                self.Stop()

                # Unfortunately, the error code is hidden from us..
                raise Game_Exception("Server startup error!")

            pygame.time.wait( 100 )
        
        print 'Lobby is ready for connections.'

        # Ready for connections now.
        error_msg = client_mq.Connect(loopback, port,
                    user_name, password)
        if ( error_msg != None ):
            raise Game_Exception(
                    "%s connection error: %s" % (name, error_msg) )

        if ( not client_mq.Is_Ok() ):
            self.Stop()
            raise Game_Exception("Client connection error!")

        # Check it's ok.
        to_check = [ ("Server", server_mq), 
                    ("Client", client_mq) ]

        for (name, mq) in to_check:
            if ( not mq.Is_Ok() ):
                error_msg = "%s error" % name

                self.Stop()

                raise Game_Exception(
                        "%s connection error: %s" % (name, error_msg) )

        print 'Returning.'

        self.__lobby = lobby_net

    def Stop(self):
        if ( self.__demo_recorder != None ):
            self.__demo_recorder.Close()
            self.__demo_recorder = None

        for mq in self.__mqs:
            thread_mgr.Stop_Thread(mq)
        self.__mqs = []
        self.__lobby = None

    def Get_Lobby(self):
        return self.__lobby
    
    def Is_Ok(self):
        return ( self.__lobby != None )








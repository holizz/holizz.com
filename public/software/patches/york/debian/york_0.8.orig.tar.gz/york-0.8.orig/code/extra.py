# 
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: extra.py,v 1.1 2006/08/09 19:59:13 jack Exp $
#
# This area is an extension of the library. It deals with support
# code that isn't specific to any particular game. Some parts of this
# code have been copied from other programs I've written. But then,
# that is true of much of York.

import os, sys, time, pygame, traceback, threading
from pygame.locals import *
import library, thread_mgr, meeple_graphics, constants, config

from library import Filter_Message, Launder_Message

__managed_shutdown_mutex = threading.Semaphore()


def Is_Windows():
    return ( sys.platform[ :3 ].lower() == 'win' )


def Get_OS():
    # On my machine, sys.platform reports 'linux2'. Remove digits.
    pf = sys.platform.title()
    for i in xrange(len(pf)):
        if ( not pf[ i ].isalpha() ):
            pf = pf[0:i]
            break

    if ( pf == 'Win' ):
        pf = 'Windows'
    return pf

def Get_System_Info():
    # Some information about the run-time environment.
    # This gets included in savegames - it may be useful for
    # debugging problems using a savegame as a starting point.
    return repr([time.asctime(), sys.platform, sys.version, 
            pygame.version.ver, sys.prefix, sys.executable])

def Get_Home():
    for i in [ "HOME", "APPDATA" ]:
        home = os.getenv(i)
        if ( home != None ):
            return home
    return None

# Meeple generator
def Make_Meeple_Images(meeple_sz, rules):
    meeple_images = []
    meeple_factory = meeple_graphics.Meeple(meeple_sz * 2,
                rules.Get_Max_Players())
    for i in xrange(rules.Get_Max_Players()):
        img = meeple_factory.Get_Surface(i, 1)
        r = Rect(0, 0, meeple_sz, meeple_sz)
        r.center = img.get_rect().center
        img = img.subsurface(r)
        meeple_images.append(img)
    return meeple_images

def Run_Managed(fn, on_exception=None, shutdown=True):
    # The given function is run inside an exception catcher to
    # ensure a clean exit in the event of an exception.

    # This text is prepared now in case it raises an exception :)
    if ( on_exception == None ):
        on_exception = [ '',
        'Exception in York! The following information has been written to',
        config.Get_Exception_File() + ':',
        '',
        'If you are using the latest version of York, please report this',
        'information to the programmer using the email address given at',
        'http://www.jwhitham.org.uk/york/. The easiest way to do this is',
        'to send the file named above as an email attachment. Thankyou for',
        'your help.', 
        '',
        'System: ' + Get_System_Info(),
        'York version: ' + library.Version(),
        '' ]

    try:
        fn()
        return ''

    except SystemExit:
        if ( shutdown ):
            Shutdown()
        return ''

    except:
        on_exception.append(traceback.format_exc())
        on_exception.append('***')
        on_exception.append('')
        out = '\n'.join(on_exception)

        try:
            f = file(config.Get_Exception_File(), "at")
            f.write(out)
            f.close()
        except:
            pass

        if ( shutdown ):
            print out
            Shutdown()

        return out

def Shutdown():
    global __managed_shutdown_mutex
    __managed_shutdown_mutex.acquire()
    thread_mgr.Shutdown()
    pygame.display.quit()
    __managed_shutdown_mutex.release()
    sys.exit(1)

def Make_Debug_Hook(original):
    hook_lock = threading.Semaphore()

    class Stdout_Hook:
        def __init__(self):
            self.hook = None

        def write(self, msg):
            hook_lock.acquire()
            try:
                try:
                    if ( self.hook != None ):
                        for submsg in msg.split('\n'):
                            self.hook(submsg)
                    original.write(msg)
                except Exception, e:
                    original.write('Exception in stdout hook!\n')
                    traceback.print_exc(file=original)
                    original.flush()
            except:
                original.write('Exception in emergency handler!\n')
                original.flush()

            hook_lock.release()

        def Attach(self, hook):
            hook_lock.acquire()
            self.hook = hook
            hook_lock.release()

    return Stdout_Hook()

def Game_Video_Mode(vr=None):
    if ( vr == None ):
        vr = config.Get_Video_Res()
        fallback = True
    else:
        fallback = False
    sm = config.Get_Set_Mode_Flags()
    print 'Game resolution:',vr
    print 'Set mode flags:',sm
    try:
        screen = pygame.display.set_mode(vr, sm)
        if ( screen == None ):
            raise Exception
    except:
        if ( fallback ):
            print 'set_mode failed, using fallback resolution'
            screen = pygame.display.set_mode(library.MENU_RESOLUTION, sm)
            if ( screen == None ):
                raise Exception("set_mode fallback failed")
        else:
            return None
                    
    screen.fill((0,0,0))
    pygame.display.flip()
    return screen

def Menu_Video_Mode():
    screen = pygame.display.set_mode(library.MENU_RESOLUTION,
            config.Get_Set_Mode_Flags())
    screen.fill((0,0,0))
    pygame.display.flip()
    return screen

def Convert(pic1, pic2, more):
    # Convert uses ImageMagick. 
    import resources

    cv = "convert"
    if ( Is_Windows() ):
        cv2 = os.path.join(resources.BASE_DIR, 'win', 'convert.exe')
        if ( os.path.exists(cv2) ):
            cv = cv2

    rc = os.system('"%s" %s %s %s' % (cv, more, pic1, pic2))
    if ( rc != 0 ):
        print ""
        print "The ImageMagick convert program appears to have failed."
        print "Ensure that ImageMagick is installed."

        sys.exit(0)



#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: graphics_module.py,v 1.1 2006/08/09 20:34:50 jack Exp jack $
#
#


import pygame
from pygame.locals import *


import library


# When a tile has just been loaded, it is preprocessed.
# This function gets the original tile image, straight from the data file,
# with only a conversion to the local graphics mode.
def Preprocess_Tile(tile_surf, name, rules):
    pass

# When a tile must appear at a new resolution, it is rescaled.
# This function is called after scaling.
def Tile_Rescaled(tile_surf, name, rules):
    pass

# After rescaling and rotation, a tile is ready to be drawn,
# and this function is called. The results are cached.
# This function is only called for tiles that are drawn in the
# main window.
def Tile_Finalise(tile_surf, name, rules):
    # Add border to tile. Done here so that the rotation is
    # always the same.

    tile_rect = tile_surf.get_rect()
    width = tile_rect.width

    edge_surf = pygame.Surface(tile_rect.size)
    library.Edge_Bevel_Effect(edge_surf, (120, 140, 120), 120)
    edge_surf.set_alpha(140)
    tile_copy = tile_surf.copy()
    tile_surf.blit(edge_surf, (0, 0))
    i2 = tile_rect.width / 20
    i2 = min(i2, -library.EDGE_BEVEL_EFFECT_MARGIN, 2)
    i = i2 / 2
    tile_surf.blit(tile_copy, (i, i), Rect(i, i, 
                    width - i2, width - i2))




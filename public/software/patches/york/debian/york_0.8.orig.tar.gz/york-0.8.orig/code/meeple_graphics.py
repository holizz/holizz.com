#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: meeple_graphics.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 

import library , pygame , resources

class Meeple:

    def __init__(self,sz,num_players):
        self.__meeple_pic = ( 
            resources.Get_Resource_Image("ui/meeple.png").convert_alpha() )
        self.__sz = 0
        self.__num_players = num_players
        self.Scale(sz)

    def Scale(self,sz):
        if ( sz == self.__sz ):
            return

        self.__sz = sz
        basic_meeple = pygame.transform.scale(self.__meeple_pic,(sz,sz))
        bsz = ( sz * 3 ) / 2 

        # Produce meeple highlighting effect
        hlevel = []
        hgradient = []
        hpalette = []
        # step 1. compute gradients
        hgradient.append([0, 255])                           # black/white
        hgradient.append([0, 128, 255, 128, 255])            # highlight 1
        hgradient.append([0, 128, 255, 255, 255, 128, 255])  # highlight 2

        # step 2. scale and apply edging effect
        basic = basic_meeple.convert() # was convert(8)
        for gradient in hgradient:
            h = library.Edge_Expansion_Effect(basic,len(gradient)-1)
            hpalette.append([ (x,x,x) for x in gradient ])
            hlevel.append(h)
        self.__max_level = len(hlevel)

        # step 3. recolour for all players
        self.__meeple_pics = []
        for player in range(0,self.__num_players):
            self.__meeple_pics.append([])

            (r,g,b) = library.Get_Colour_For_Player(player)
            for (pal,hpic) in zip(hpalette,hlevel):
                pal[ len(pal) - 1 ] = ((r*x)/256,(g*x)/256,(b*x)/256)
                h = hpic.copy()
                h.set_palette(pal)
                h.set_colorkey((0,0,0))
                h.set_alpha(255)
                self.__meeple_pics[ player ].append(h)

    def Get_Surface(self, player, highlighting):
        assert 0 <= highlighting < self.__max_level
        assert 0 <= player < self.__num_players
        return self.__meeple_pics[ player ][ highlighting ]

    def Draw_Meeple(self,(sx,sy),player,highlighting,surf):
        m = self.Get_Surface(player, highlighting)
        x = sx - m.get_rect().width / 2
        y = sy - m.get_rect().height / 2
        surf.blit(m,(x,y))

    def Get_Size(self):
        sz = self.__sz
        return (( sz * 4 ) / 10,sz / 4)


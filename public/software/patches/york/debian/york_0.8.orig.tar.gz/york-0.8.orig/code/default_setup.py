#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: default_setup.py,v 1.1 2006/08/09 19:59:13 jack Exp $
#

# Default tile definitions:

def Road(a,b,c):
    return [('F',a),('R',b),('F',c)]

def City(a):
    return [('C',a)]

def Field(a):
    return [('F',a)]

def Monastery(a,adj_list):
    return ('M',a,adj_list)


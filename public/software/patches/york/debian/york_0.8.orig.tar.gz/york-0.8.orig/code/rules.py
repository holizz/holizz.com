#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: rules.py,v 1.3 2006/08/09 20:38:35 jack Exp $
# 
# Basic game rules. Game modifications are able to override these rules
# by defining a class that inherits from Basic_Rules, and registering that
# class as their Rules module.
# 


import random, sys


class Rules_Exception(Exception):
    pass

class Meeple:
    def __init__(self,player):
        self._player = player
        self.Remove()

    def Place(self,tile_instance,(mx,my),region):
        assert ( not self.Is_Placed() )
        self._position = (mx,my)
        self._region = region
        # don't use tile instance

    def Remove(self):
        self._position = None
        self._region = None
    
    def Is_Placed(self):
        return ( self._position != None )
    
    def Get_Position(self):
        assert self.Is_Placed()
        return self._position

    def Get_Region(self):
        assert self.Is_Placed()
        return self._region

    def Get_Player(self):
        return self._player

    def Make_Ghost(self):
        assert self.Is_Placed()
        g = Meeple(self._player)
        g.Place(None,self._position,self._region)
        return g

class Basic_Player_Object:
    def __init__(self, number, max_meeples):
        self.number = number
        self.score = 0
        self.meeples = [ Meeple(number) for i in xrange(max_meeples) ]
        self.record = []

    def Info(self):
        # What you want to see after the player's name.
        return "(%u)" % self.score

    def Get_HUD_Info(self):
        return (self.score, self.meeples, self.Info())

    def Score(self, turn_number, region_type, 
                    plus, href, text):

        self.score += plus

        # Score records from all players are brought together
        # in scoresheet.py
        class R:
            pass

        r = R()
        r.player_number = self.number
        r.turn_number = turn_number
        r.record_number = len(self.record)
        r.region_type = region_type
        r.score = plus
        r.acc_score = self.score
        r.href = href
        r.text = text

        self.record.append(r)

    def End_Game(self):
        pass


class Basic_Rules:
    """Extend this class to implement new game rules -- 
       if your rule is not controlled from here, then I have done it wrong.
    """
    def __init__(self):
        self.Reset()

    def Reset(self):
        import tile_db
        self.__tile_db = tile_db.Tile_Database()
        self.__field_style_scoring_records = dict()



    # This procedure is called after the game has ended and
    # all regions have been scored. It computes field scores.

    def Score_Final(self, game_objs, cache, scoring_msg_fn, timecode): 
        simple_numbering = 1

        for key in self.__field_style_scoring_records.keys():
            (adj_region, adj_type, field_type) = key
            plist = self.__field_style_scoring_records[ key ]

            city_shares = [ [0,i] for i in xrange(
                                len(game_objs.player_objects)) ]

            for player in plist:
                city_shares[ player ][ 0 ] += 1
            city_shares.sort(cmp=lambda x,y: cmp(y[0],x[0]))

            must_match = city_shares[0][0]
            assert must_match > 0

            sc = self.Get_Field_Style_Score(field_type, adj_type)

            scorer_list = []
            for [num_meeples, player] in city_shares:
                if ( num_meeples != must_match ):
                    break
                scorer_list.append(player)

            ft_name = self.Name_For_Region_Type(field_type) + "."
            if ( len(scorer_list) == 1 ):
                text = "is the sole supplier, from " + ft_name
            else:
                text = "are joint suppliers, from " + ft_name

            href = (0, 0) # XXX Generate suitable co-ords for region

            for player in scorer_list:
                game_objs.player_objects[ player ].Score(timecode, 
                                    field_type, sc, href, text)

            game_objs.game_logic.Add_Scoring_Special_Effect(
                        cache, adj_region, sc)

            at_name = ( self.Name_For_Region_Type(adj_type) + " " + 
                        str(simple_numbering) )
            scoring_msg_fn(at_name,scorer_list, text, sc)

            game_objs.game_logic.Add_Final_Region_Information(adj_region,
                        adj_type,field_type,scorer_list,sc)

            simple_numbering += 1

    def Prepare_Field_Style_Scoring(self, game_objs,
                        field_region, field_type, shares):
        plist = []
        for [num_meeples, player] in shares:
            for i in range(0,num_meeples):
                plist.append(player)

        # For each 'city' and 'field_type', build a list of meeples that 
        # contribute.
        # We call this function for each 'field', and not for 
        # each 'city', therefore we must prepare the data here and score it 
        # later.
        adj_list = game_objs.board_logic.Get_Adjacent_Closed_Regions(
                                                            field_region)
        for (adj_region, adj_type) in adj_list:
            if ( self.Is_Field_Style_Scoring_Pair(field_type, adj_type) ):
                k = (adj_region, adj_type, field_type)

                if ( not self.__field_style_scoring_records.has_key(k) ):
                    self.__field_style_scoring_records[k] = []
              
                self.__field_style_scoring_records[k] += plist
        
        game_objs.board_logic.Empty_Region(field_region)
        
        game_objs.game_logic.Add_Final_Region_Information(field_region,
                            field_type,field_type,plist,-1)

    def Compute_Monastery_Score(self, game_objs,
                (tx, ty), tiles_in_region, region_number, type, is_closed):
        score = 0
        for x in xrange(tx - 1, tx + 2):
            for y in xrange(ty - 1, ty + 2):
                if ( game_objs.board_logic.Get_Tile_At(x, y) != None ):
                    score += 1
        return score

    def Compute_Region_Score(self, game_objs, 
                (tx, ty), tiles_in_region, region_number, type, is_closed):

        # Fields are not scored at this time..
        assert self.Is_Closeable(type)

        # Is it a monastery?
        if ( type == 'M' ):
            return self.Compute_Monastery_Score(game_objs, 
                (tx, ty), tiles_in_region, region_number, type, is_closed)

        # Must be a road or city.
        return self.Compute_City_Score(game_objs,
                (tx, ty), tiles_in_region, region_number, type, is_closed)


    def Compute_City_Score(self, game_objs, 
                (tx, ty), tiles_in_region, region_number, type, is_closed):

        assert ( type in "CR" ) # City or road

        score = 0
        for tile in tiles_in_region:
            flags = tile.Get_Flags()
            if ( flags != None ):
                if (( 's' in flags ) and ( type == 'C' )):
                    score += 1
                    # extra point due to shield flag in city

            score += 1

        if ( is_closed and ( type == 'C' ) and ( score > 2 )):
            # double points for non-tiny completed city
            score *= 2

        return score

    def Get_Graphics_Module(self):
        # Here is how to do low-level stuff to the user interface.
        import graphics_module
        return graphics_module

    def Get_Game_Logic_Driver_Class(self):
        # Here is how to customise the turn controller.
        import game_logic_driver
        return game_logic_driver.Game_Logic_Driver
        
    def Identify_Edge(self, regions):
        if ( regions == ['F','R','F'] ):
            type = 'R'
        elif ( regions == ['F'] ):
            type = 'F'
        elif ( regions == ['C'] ):
            type = 'C'
        else:
            raise Rules_Exception(
        "Declared tile has unknown edge configuration: " + repr(regions))
        return type

    def Name_For_Region_Type(self,rt):
        if ( rt == 'F' ):
            return "Field"
        elif ( rt == 'R' ):
            return "Road"
        elif ( rt == 'C' ):
            return "City"
        elif ( rt == 'M' ):
            return "Monastery"
        else:
            return "UNKNOWN REGION TYPE"

    def Can_Place_In_Region(self, rt):
        return rt in "FRCM"

    def Get_Possible_Rotations(self, tile_instance, (tx, ty), board_logic):
        # Return valid rotations for tile at (tx, ty).
        # This should not need to check the edges - that's already been done.
        # Note: this function is called during evaluation of probabilities
        # so it should be fast in the common case.



        # Check 'no adjacent monasteries' rule.
        # TODO make this rule optional - not everyone plays it
        if ( self.Is_Monastery(tile_instance.Get_Flags())):
            for x in xrange(tx - 1, tx + 2):
                for y in xrange(ty - 1, ty + 2):
                    ti2 = board_logic.Get_Tile_At(x, y)
                    if (( ti2 != None )
                    and ( self.Is_Monastery(ti2.Get_Flags()) )):
                        return []

        return range(0, 4)

    def Commit_Placement(self, game_objs, tile_instance, (tx, ty)):
        # Called at end of turn, when a tile is finalised.
        return

    def Get_Special_Completions(self, tile_instance, (tx, ty), board_logic):
        # Return the list of regions that have been completed by the
        # placement of tile_instance at (tx, ty). tile_instance has already
        # been placed. This does not return regions that are complete
        # as a result of being closed (cities and roads). It is used
        # for monasteries.

        completed = []

        for x in xrange(tx - 1, tx + 2):
            for y in xrange(ty - 1, ty + 2):
                ti2 = board_logic.Get_Tile_At(x, y)

                if (( ti2 != None )
                and ( self.Is_Monastery(ti2.Get_Flags()) )):

                    empty_square = False
                    for xi in xrange(x - 1, x + 2):
                        for yi in xrange(y - 1, y + 2):
                            ti3 = board_logic.Get_Tile_At(xi, yi)
                            if ( ti3 == None ):
                                empty_square = True

                    if ( not empty_square ):
                        for (mon_region_type, mon_region) in (
                                ti2.Get_Additional_Region_Info()):
                            completed.append(mon_region)

        return completed


    def Is_Closeable(self,region_type):
        return ( region_type != 'F' )
   
    def Get_Player(self, player):
        return Basic_Player_Object(player, self.Max_Meeples())

    def Max_Meeples(self):
        return 7

    def Is_Monastery(self, tile_flags):
        return (( tile_flags != None )
            and ( 'm' in tile_flags ))

    def Is_Field_Style_Scoring_Pair(self,field_type,adj_type):
        return (( field_type == 'F' ) and ( adj_type == 'C' ))

    def Get_Field_Style_Score(self,field_type,adj_type):
        assert field_type == 'F'
        assert adj_type == 'C'
        return 4    # 4 points per city!

    def Get_Max_Players(self):
        # Must match number of meeple colours available
        return 6

    def Get_Max_Observers(self):
        # Observers includes players (sorry: this is counter-intuitive)
        return 12

    def Get_Subgame_List(self):
        # 0 is the default subgame. It should always be present.
        return [ (0, "Normal (72 tiles)"),
                (1, "Test (25 tiles)"),
                (2, "Double (144 tiles)")]

    def Get_Tile_DB(self):
        return self.__tile_db

    def Build_Stack(self, subgame):
        tdb = self.Get_Tile_DB()
        tdb.Reset()
        add = tdb.Add_Tile

        repeats = 1
        if ( subgame == 2 ):
            repeats = 2 # double game
        if ( subgame == 1 ):
            def Test_Add(name, *ignore):
                tdb.Add_Tile(name, 1)
            add = Test_Add
                

        for i in xrange(repeats):
            # Row 1
            add('basic.city', 5)
            add('basic.2citiescorner', 2)
            add('basic.2citiesopposite', 3)
            add('basic.citytriangle', 3)
            add('basic.citytriangle.bonus', 2)
            # Row 2
            add('basic.cityspan', 1)
            add('basic.cityspan.bonus', 2)
            add('basic.squarecity', 1)
            add('basic.bigcity', 3)
            add('basic.bigcity.bonus', 1)
            # Row 3
            add('basic.city.straightroad', 4)
            add('basic.city.curveroad1', 3)
            add('basic.city.curveroad2', 3)
            add('basic.2citiescorner.curveroad1', 3)
            add('basic.2citiescorner.curveroad1.bonus', 2)
            # Row 4
            add('basic.bigcity.road', 1)
            add('basic.bigcity.road.bonus', 2)
            add('basic.city.tjunction', 3)
            add('basic.monastery', 4)
            add('basic.monastery.road', 2)
            # Row 5
            add('basic.straightroad', 8)
            add('basic.curveroad', 9)
            add('basic.tjunction', 4)
            add('basic.crossroads', 1)

            tdb.Shuffle_Tiles()
            add('basic.city.straightroad', 1) # start tile

        return tdb.Get_Stack()



        

#!/usr/bin/python2.4
#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: tile_compiler.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 

import pygame , sys , os
import tile_graphics , resources , tile_db , autogen , constants



def Tile_Compiler(staging_area, tileset_program_list, rules, do_autogen):

    root_dir = os.getcwd()
    
    pygame.init()
    pygame.font.init()
    screen = pygame.display.set_mode((320, 240))

    # Get declarations of tiles to be compiled.
    print 'Examining tile set...'
    tile_db = rules.Get_Tile_DB()
    tile_db.Reset()

    globals_dict = dict()
    globals_dict[ 'Declare_Tile' ] = tile_db.Declare_Tile
    locals_dict = dict()
    for tileset_code in tileset_program_list:
        exec tileset_code in globals_dict, locals_dict


    if ( do_autogen ):
        pygame.display.set_caption("Tile Autogenerator")

        os.chdir(staging_area)
        for x in ('tilepics', 'tilemasks'):
            try:
                os.mkdir(x)
            except:
                pass
        os.chdir(root_dir)

        for name in tile_db.Get_All_Declared_Tiles():
            print 'Autogenerating', name
            autogen.Make_Tile(staging_area, screen, name,
                tile_db.Get_Flags(name),
                tile_db.Get_Autogen_Data(name))

    else:
        pygame.display.set_caption("Tile Compiler")

        os.chdir(staging_area)
        try:
            os.mkdir(constants.COMPILED)
        except:
            pass

        # Do compilation work.
        for name in tile_db.Get_All_Declared_Tiles():
            print 'Compiling', name
            tile_db.Add_Tile(name)
            tg = tile_graphics.Tile_Graphics(
                    name, rules, True)
            tile_db.Save(name)
            tg.Draw(screen, 0, 0, 0)
            pygame.display.flip()

    os.chdir(root_dir)
    print "Finished."


#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: board_graphics.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# Board Graphics. User interface graphics class - used to draw windows on the game.
#


import pygame, math
from pygame.locals import *
import library, game_logic_driver, tile_cache, resources, config
import meeple_graphics, scoresheet


class Board_Graphics:
    """
    Board_Logic <--- Game_Logic <--- Game_Logic_Driver <--- Board_Graphics <---- Main Loop
                                                            YOU ARE HERE

    """

    def __init__(self, view_surface, cache, game, 
                gui_msg_fn, sidebar, back_colour):
        self._game = game
        self._gui_msg_fn = gui_msg_fn
        self._cache = cache
        self._sidebar = sidebar

        self._hint_font_sz = 20
        self._hint_font = self._score_font = resources.Get_Font(
                self._hint_font_sz)

        w = view_surface.get_rect().width / 2
        h = view_surface.get_rect().height / 2
        self._border_size = 2

        self._num_players = self._game.Get_Num_Players()
        self._s = view_surface
        self._mouse_position = (0,1)
        self._last_mouse_x_y = (0,0)
        self._mouse_moved = False


        #self._background_image = None
        #resources.Get_Image_For_Background(back_img)
        self.__back_colour = back_colour

        self._meeples = meeple_graphics.Meeple(
                            self._cache.Get_Size(),self._num_players)


        self.__expect_size = self._cache.Get_Size()
        self.Scale(self._cache.Get_Size())
        self.Scroll_And_Zoom((0,0), False)
        self.Refresh()


    def Scale(self,sz):
        self.__marker = pygame.Surface((sz,sz))
        self.__marker.set_colorkey((0,0,0))

        assert self._cache.Get_Size() == self.__expect_size

        self._meeples.Scale(sz)
        self._cache.Scale(sz)
        self.Refresh()
        self.__expect_size = sz

        assert self._cache.Get_Size() == self.__expect_size

    def Get_Size(self):
        return self._cache.Get_Size()

    def __Scroll_And_Zoom(self, centre_on, allow_rescale):
        board_rect = self._s.get_rect()
        sz = self.Get_Size()

        # Will a resize be required?
        if ( allow_rescale ):
            map_rect = self.__Get_Map_Pixel_Rect()

            w1 = map_rect.width
            map_rect = map_rect.fit(board_rect)
            w2 = map_rect.width
            if ( w2 < w1 ):
                f = float(w2) / float(w1)
                if ( f < 0.95 ):
                    # scaling required!
                    sz = int(( float(sz) * f ) - 2.0 )
                    self.Scale(sz)

        if ( centre_on != None ):
            (tx,ty) = centre_on
            # Centre on specified tile.
            sx = tx * sz
            sy = ty * sz
            # (sx,sy) is co-ordinate of top left corner of centre tile.
            sx += sz / 2
            sy += sz / 2
        else:
            # Centre on map rect centre
            map_rect = self.__Get_Map_Pixel_Rect()
            (sx,sy) = map_rect.center

        # (sx,sy) is the centre of the centre tile.
        self._scroll_x = sx - board_rect.centerx
        self._scroll_y = sy - board_rect.centery
        
    def Scroll_And_Zoom(self, centre_on, rescale):
        self._game.Read_Lock(True)
        self.__Scroll_And_Zoom(centre_on, rescale)
        self._game.Read_Lock(False)

        
    def Draw(self):
        #print 'UPDATE 2',self
        self._game.Read_Lock(True)

        self._mouse_moved = False
        self._s.fill(self.__back_colour)
        #library.Draw_Background(self._background_image, self._s, self._s.get_rect())

        placeable_location_colour = library.colours.placeable_location_colour
        highlight_menu_colour = library.colours.highlight_menu_colour

        size = self._cache.Get_Size()
        highlighted_meeples = set([])
        all_meeples = set([])
        nt = self._game.Get_Num_Remaining_Tiles()
        max_width = 0
        max_width_caused_by = ""
        
        # Draw probabilities (if enabled):
        if ( not config.cfg.remaining_tile_count.startswith("Not") ):
            perc = config.cfg.remaining_tile_count.startswith("Perc")
            for ((tx,ty), prob) in self._game.Get_Probabilities():
                if self._Is_Tile_Onscreen(tx,ty):
                    if ( perc ):
                        if ( 0 < prob <= nt ):
                            prob_str = '%u%%' % (( prob * 100 ) / nt )
                        else:
                            prob_str = ""
                    else:
                        prob_str = '%u' % prob

                    surf = self._hint_font.render(prob_str, False,(0, 120, 0))
                    (sx,sy) = self._Calc_Scr((tx,ty))
                    (w,h) = surf.get_size()
                    sx += ( size - w ) / 2
                    sy += ( size - h ) / 2
                    self._s.blit(surf,(sx,sy))

                    if ( w > max_width ):
                        max_width = w
                        max_width_caused_by = prob_str

        # Resize hint font in the event of width overflow.
        while (( max_width >= (( size * 9 ) / 10 ))
        and ( self._hint_font_sz >= 10 )):
            self._hint_font_sz -= 1
            self._hint_font = resources.Get_Font(self._hint_font_sz)
            (w, h) = self._hint_font.size(max_width_caused_by)
            max_width = w

        # Draw placeable locations
        if ( self._game.Is_Placing_Tile()):
            for (tx,ty) in self._game.Get_Set_Of_Possible_Placements():
                pygame.draw.rect(self._s,placeable_location_colour,self._Get_Tile_Rect(tx,ty),1)
                if ( self._mouse_position == (tx,ty) ):
                    pygame.draw.rect(self._s,highlight_menu_colour,
                            self._Get_Tile_Rect(tx,ty).inflate(-4,-4),4)
                    
        # Draw tiles and meeples:
        for ((tx,ty),(di,meeple)) in self._game.Get_Tile_Draw_List():
            if self._Is_Tile_Onscreen(tx,ty):
                self._Draw_Tile(self._Calc_Scr((tx,ty)),di)
                if ( meeple != None ):
                    all_meeples |= set([(tx,ty,di,meeple)])

        # Draw preview tile (if any)
        if ( self._game.Is_Placing_Tile() or self._game.Is_Rotating_Tile()):
            pd = self._game.Get_Preview_Drawing()
            if ( pd != None ):
                ((tx,ty),(di,meeple)) = pd
                #print 'Preview Tile DI:',di
                self._Draw_Tile(self._Calc_Scr((tx,ty)),di)
                pygame.draw.rect(self._s,highlight_menu_colour,
                        self._Get_Tile_Rect(tx,ty).inflate(-2,-2),2)

        # Draw region highlighting:
        if ( self._game.Is_Highlighted_Region_Empty() ):
            if ( self._game.Is_Placing_Meeple() 
            and ( self._game.Get_Preview_Meeple_Position() != None )):
                colour = library.colours.region_valid_meeple
            else:
                colour = library.colours.region_invalid_meeple
        else:
            colour = library.colours.region_not_empty
        for ((tx,ty),(di,meeple),graphics_region) in self._game.Get_Highlight_Draw_List():
            if self._Is_Tile_Onscreen(tx,ty):
                self._Draw_Region(self._Calc_Scr((tx,ty)),di,graphics_region,colour)
                if ( meeple != None ):
                    highlighted_meeples |= set([(tx,ty,di,meeple)])

        # Draw meeples!
        regular_meeples = all_meeples - highlighted_meeples
        for (tx,ty,di,meeple) in regular_meeples:
            if ( meeple.Is_Placed() ):
                self._Draw_Meeple(self._Calc_Scr((tx,ty)),meeple.Get_Position(),meeple.Get_Player(),0)
        for (tx,ty,di,meeple) in highlighted_meeples:
            if ( meeple.Is_Placed() ):
                self._Draw_Meeple(self._Calc_Scr((tx,ty)),meeple.Get_Position(),meeple.Get_Player(),1)

        # A preview meeple may be drawn:
        if ( self._game.Is_Placing_Meeple()):
            pmp = self._game.Get_Preview_Meeple_Position()
            if ( pmp != None ):
                ((tx,ty),mxy) = pmp
                self._Draw_Meeple(self._Calc_Scr((tx,ty)),mxy,self._game.Get_Current_Player(),2)

        self._game.Read_Lock(False)

    def Draw_FX(self, scoring_fx, flashing_fx):
        self._game.Read_Lock(True)

        size = self._cache.Get_Size()

        # Show special effects, if any
        for ((effect_draw_list,score,level), c) in scoring_fx:

            sxa = sya = 0
            for effect in effect_draw_list:
                ((tx,ty),(di,meeple),graphics_region) = effect
                (sx,sy) = self._Calc_Scr((tx,ty))
                if self._Is_Tile_Onscreen(tx,ty):
                    self._Draw_Region((sx,sy),di,graphics_region,(c,c,c),(c*3)/4)
                    # XXX Can't use the meeple field - the meeples may have been
                    # taken off the board.
                sxa += sx 
                sya += sy
            if ( len(effect_draw_list) > 0 ):
                # The score value appears above the region and floats off into the distance.
                s = self._score_font.render(repr(score),False,
                        library.colours.floating_score)
                x = ( sxa / len(effect_draw_list)) + ( size / 2 ) - ( s.get_rect().width / 2 )
                y = ( sya / len(effect_draw_list)) + ( size / 2 ) - ( s.get_rect().height / 2 )
                y -= level
                s.set_alpha(c)
                self._s.blit(s,(x,y))

        # The control panel tracks areas that should flash, due to moves made
        # by other players.
        m = ( self._cache.Get_Size() / 8 )
        m2 = m * -2
        for (tx,ty,colour,alpha) in flashing_fx:
            pos = self._Calc_Scr((tx,ty))
            r_draw = self.__marker.get_rect()
            pos = self.__Screen_Edge(r_draw.move(pos),m).topleft
            pygame.draw.rect(self.__marker,colour,r_draw)
            pygame.draw.rect(self.__marker,(0,0,0),r_draw.inflate(m2,m2))
            self.__marker.set_alpha(alpha)
            self._s.blit(self.__marker,pos)

        # For debugging.
        # self._s.blit(self._font.render(self._game.Get_Debug_Info(),False,(255,255,255)),(0,0))
        self._game.Read_Lock(False)

            
    
    def Click_Event(self,(sx,sy)):
        ((tx,ty),(mx,my)) = self._Begin((sx,sy))

        self._game.Mouse_Click(None,(tx,ty),(mx,my))


    def Refresh(self):
        self._refresh = True

    def Mouse_Move_Event(self,(sx,sy)):
        ((tx,ty),(mx,my)) = self._Begin((sx,sy))
        change = self._game.Mouse_Move(None,(tx,ty),(mx,my))

        if ( self._refresh ):
            stats_display = self._game.Get_Current_Statistics()
            if ( stats_display == None ):
                self._sidebar.Draw_Nothing()
            else:
                # Note: we can do this on every mouse move because nothing
                # is actually drawn until the mouse has remained static for the
                # fadeup time.
                (is_region_specific, stats_display) = stats_display
                if ( is_region_specific ):
                    if ( self._game.Is_Placing_Meeple() ):
                        self._sidebar.Draw_Region_Stats(stats_display,
                                    "Place a meeple on this ")
                    else:
                        self._sidebar.Draw_Region_Stats(stats_display)
                else:
                    self._sidebar.Draw_Tile_Stats(stats_display,
                                self._game.Get_Num_Remaining_Tiles())
            self._refresh = False

        self._mouse_position = (tx,ty)

        return change


    def _Begin(self,(sx,sy)):
        # Detect mouse movement, in general.
        if ( self._last_mouse_x_y != (sx,sy) ):
            self._last_mouse_x_y = (sx,sy)
            self._mouse_moved = True
            self._sidebar.Not_AFK()

        # Conversion of co-ordinates
        tx = self._Calc_Tile_X(sx)
        ty = self._Calc_Tile_Y(sy)
        sx -= self._Calc_Scr_X(tx)
        sy -= self._Calc_Scr_Y(ty)
        sz = self._cache.Get_Size()
        mx = ( sx * library.BASIC_TILE_SIZE ) / sz
        my = ( sy * library.BASIC_TILE_SIZE ) / sz
        return ((tx,ty),(mx,my))

    def _Draw_Tile(self,(sx,sy),(number,rotation)):
        tile_graphs = self._cache.Get(number)
        tile_graphs.Draw(self._s,sx,sy,rotation)
        
    def _Draw_Region(self,(sx,sy),(number,rotation),graphics_region,colour,alpha=140):
        tile_graphs = self._cache.Get(number)
        tile_graphs.Draw_Region(self._s,sx,sy,rotation,graphics_region,colour,alpha)

    def _Draw_Meeple(self,(sx,sy),(x,y),player,highlighting=0,surf=None):
        sz = self._cache.Get_Size()
        sx += int( ( x * sz ) / library.BASIC_TILE_SIZE )
        sy += int( ( y * sz ) / library.BASIC_TILE_SIZE )
        if ( surf == None ):
            surf = self._s
        self._meeples.Draw_Meeple((sx,sy),player,highlighting,surf)

    def _Get_Tile_Rect(self,x,y):    
        sz = self._cache.Get_Size()
        return Rect(self._Calc_Scr_X(x),self._Calc_Scr_Y(y),sz,sz)

    def _Calc_Scr(self,(tx,ty)):
        return (self._Calc_Scr_X(tx),self._Calc_Scr_Y(ty))

    # Begin functions that will need to take scrolling into account...
    def _Calc_Scr_X(self,x):
        return ( x * self._cache.Get_Size() ) - self._scroll_x

    def _Calc_Scr_Y(self,y):
        return ( y * self._cache.Get_Size() ) - self._scroll_y

    def _Calc_Tile_X(self,x):
        return ( x + self._scroll_x ) / self._cache.Get_Size()

    def _Calc_Tile_Y(self,y):
        return ( y + self._scroll_y ) / self._cache.Get_Size()
    # End functions that will need to take scrolling into account

    def __Half_Size(self):
        return self._cache.Get_Size() / 2

    def _Is_Tile_Onscreen(self,tx,ty):
        return self._Get_Tile_Rect(tx,ty).colliderect(self._s.get_rect())

    def Zoom_Helper(self, (sx, sy)):
        return (self._Calc_Tile_X(sx), self._Calc_Tile_Y(sy))

    def __Get_Meeple_Size(self):
        return self._meeples.Get_Size()

    def __Screen_Edge(self,r,margin):
        s = self._s.get_rect()
        r = Rect(r)

        if ( r.right < margin ):
            r.right = margin
        elif ( r.left > ( s.width - margin )):
            r.left = s.width - margin
        if ( r.bottom < margin ):
            r.bottom = margin
        elif ( r.top > ( s.height - margin )):
            r.top = s.height - margin

        return r


    def __Get_Map_Pixel_Rect(self):
        ((x1,y1),(x2,y2)) = self._game.Get_Map_Bounds()
        size = self._cache.Get_Size()
        x1 -= 1
        y1 -= 1
        x2 += 1
        y2 += 1

        border = self._border_size
        if ( x1 > -border ): x1 = -border
        if ( y1 > -border ): y1 = -border
        if ( x2 < border ): x2 = border
        if ( y2 < border ): y2 = border
        
        return Rect(x1 * size, y1 * size,
                    (( x2 - x1 ) + 1 ) * size,
                    (( y2 - y1 ) + 1 ) * size)






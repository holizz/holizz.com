
# Not finished.
# $Id: simple_ai.py,v 1.1 2006/08/09 19:59:13 jack Exp $

import game_logic_driver

class Simple_AI(game_logic_driver.Game_Logic_Driver):
    def __init__(self,rules,game_info,gui_msg_fn,cache,client_mq,server_mq=None):
        self.__ai_msg = gui_msg_fn
        game_logic_driver.Game_Logic_Driver.__init__(self,rules,
                    game_info,gui_msg_fn,cache,client_mq,server_mq)
        

    def __Msg(self,msg):
        print msg
        self.__ai_msg(msg)

    def AI_Move(self,ui_mode,game_logic,m):
        # Get a move from the AI.
        # Note 1: lock is held while this function is called.
        # Note 2: return should be like a high-level mouse click event, i.e. a list:
        #    [tx,ty,mx,my,choice]

        if ( m == None ):
            mtype = None
            mlist = []
        else:
            (mtype, mlist) = m

        if ( ui_mode == self.PLACE_TILE ):
            p = self.Get_Probabilities()    
            if ( len(p) == 0 ):     # First turn
                self.__Msg("AI - take the first turn")
                return [0,0,0,0,None]
            else:
                p.sort(cmp=lambda (a,prob1),(b,prob2): cmp(prob1,prob2))
                # Smallest probability now at start of list.
                poss_placements = self.Get_Set_Of_Possible_Placements()

                for ((tx,ty),prob) in p:
                    if ( (tx,ty) in poss_placements ):
                        # We can place here.
                        self.__Msg("Placed at " + repr((tx,ty)) + " prob " + str(prob))
                        return [tx,ty,0,0,None]

                assert 0 # error!
                return None

        elif ( ui_mode == self.CHOOSE_ROTATION ):
            # Use the menu.
            assert mtype != None
            return [0,0,0,0,mlist.pop(0)] # pick first item (a rotation)

        elif ( ui_mode == self.PLACE_MEEPLE ):
            assert mtype != None
            return [0,0,0,0,mlist.pop(0)] # pick first item (confirm no place meeple)
        
        elif ( ui_mode == self.CONFIRM ):
            return [0,0,0,0,mlist.pop(0)] # pick first item (confirm)
            
        return None


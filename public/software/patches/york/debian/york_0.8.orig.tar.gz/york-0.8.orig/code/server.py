#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: server.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 


import socket, threading, time
import message_queue, extra, thread_mgr, library

STATE_CONNECTING = 10
STATE_CONNECTED = 11
STATE_DISCONNECTED = 12
STATE_TIMEOUT = 13
STATE_STOPPED = 14
STATE_KICKED = 15
STATE_WRONG_PASSWORD = 16
STATE_ERROR = 17





class Connection_Servlet(threading.Thread):
    """Manages a single client connection, from the point of view of
    both the game server and the game client (both use this class).

    If the serv_id parameter is zero, then the class works in client mode.
    """
    def __init__(self, conn, mod_name,
                    user_name, password, mail_queue, serv_id=0):

        threading.Thread.__init__(self)
        thread_mgr.Add_Thread(self)

        assert password != None
        self.__mutex = threading.Semaphore()
        self.__conn = conn
        self.__mod_name = mod_name
        self.__user_name = user_name
        self.__password = password
        self._mq = mail_queue
        self._serv_id = serv_id
        self._state = STATE_CONNECTING
        nm = "Connection_Servlet("+str(serv_id)+")"
        self.setName(nm)
        self.start()


    def Is_Ok(self):
        s = self.Get_State()
        return s in [ STATE_CONNECTING, STATE_CONNECTED, 
                STATE_WRONG_PASSWORD ]

    def Get_State(self):
        self.__mutex.acquire()
        s = self._state
        self.__mutex.release()
        return s

    def Get_Mod_Name(self):
        self.__mutex.acquire()
        m = self.__mod_name
        self.__mutex.release()
        return m

    def Get_ID(self):
        self.__mutex.acquire()
        s = self._serv_id
        self.__mutex.release()
        if ( s <= 0 ):
            return None  # not set yet
        else:
            return s

    def run(self):
        extra.Run_Managed(self.__Real_Run)

    def __Real_Run(self):
        (c, addr) = self.__conn

        self.__mutex.acquire()
        svr = ( self._serv_id > 0 )

        if ( svr ):
            name = "Server"
        else:
            name = "Client"

        name += str(self._serv_id) + ":"
        print name,"starting..."
        self.__mutex.release()

        s = self.__Negotiate(c, addr, svr) 
        print 'Negotiate returned',s

        if ( s != STATE_CONNECTED ):
            c.close()
            self.__mutex.acquire()
            self._state = s
            self.__mutex.release()
            return 

        self.__mutex.acquire()
        self._state = s
        self._mq.Signal_Change()
        self._mq.Net_Add(self._serv_id,"") # startup message (for testing)
        self.__mutex.release()

        c.settimeout(0.05)

        buffer = ""
        rx_timeout_setting = 15
        rx_timeout_at = time.time() + rx_timeout_setting
        tx_timeout_setting = 8 
        tx_timeout_at = time.time() + tx_timeout_setting

        while self._state == STATE_CONNECTED:
            # Receive a message..
            try:
                msg = c.recv(1024)
            except socket.error, emsg:
                msg = ""

            ct = time.time() 
            if ( msg == "" ):
                # No message.. timeout?
                if ( rx_timeout_at <= ct ):
                    print name,"timed out!"
                    self._state = STATE_TIMEOUT
                    break
            else:
                # Handle received message(s)..
                rx_timeout_at = ct + rx_timeout_setting
                buffer += msg

                eol = buffer.find("\n")

                while ( eol != -1 ):
                    msg = buffer[0:eol]
                    buffer = buffer[eol+1:]
                    eol = buffer.find("\n")

                    if ( msg == message_queue.KICK_MESSAGE ):
                        self._state = STATE_KICKED

                    self._mq.Net_Add(self._serv_id,msg)

            # Send messages..
            try:
                msg = self._mq.Net_Remove(self._serv_id)
                if ( msg == message_queue.KICK_MESSAGE ):
                    self._state = STATE_KICKED

                if (( msg == None )
                and ( tx_timeout_at <= ct )):
                    msg = ""    # Dummy message - keeps connection alive.

                if ( msg != None ):
                    tx_timeout_at = ct + tx_timeout_setting

                while ( msg != None ):
                    c.sendall(msg + "\n",0)
                    msg = self._mq.Net_Remove(self._serv_id)
                    if ( msg == message_queue.KICK_MESSAGE ):
                        self._state = STATE_KICKED
                
            except socket.error, emsg:
                # Dead socket?
                print name,"err:",emsg
                self._state = STATE_DISCONNECTED
                break
  
        c.close()
        print name,"clean exit"
        if ( svr ):
            self._mq.IM_Remove_ID(self._serv_id)

    def __Wait_For_Line(self,conn):
        if ( self._state == STATE_STOPPED ):
            return ""

        try:
            msz = 1024
            msg = conn.recv(msz)
            eol = msg.find("\n")
            while ( eol == -1 ):
                msg = msg + conn.recv(msz)
                if ( len(msg) > msz ):
                    break
                eol = msg.find("\n")

            # Sanity check.
            if ( len(msg[ eol: ].strip()) != 0 ):
                print "Message formatting error! Non-whitespace characters",
                print "follow newline!"
                msg = ""
            else:
                msg = extra.Launder_Message(msg[0:eol])

        except socket.error, emsg:
            print "Receive failed:",emsg,"state is",self._state
            msg = ""

        return msg


    def __Negotiate(self, conn, addr, server_mode):
        conn.settimeout(10) # negotiation timeout

        id_code_prefix = "Your ID code is:"
        password_id = "The password is:"
        user_name_id = "My name is:"
        mod_id = "MOD is:"
        ok_string = "Thankyou"

        # No reason why computers can't be polite to each other....
        nego_sequence = [ "Hello?" ,                    # C
            "Good day, what version are you?" ,         # S
            "I am version " + library.Version() + "-1", # C
            "So you want to play York then?",           # S
            "Yes please!",                              # C
            "What is the password?",                    # S
            password_id + self.__password.strip(),      # C
            "Take a seat, then, and await your ID.",    # S
            "Thankyou."]                                # C

        # Each side of the connection must send exactly one line before 
        # waiting for single line from the other side. If you send two
        # or more lines without waiting, they may become joined during
        # their travels through the aether, which breaks __Wait_For_Line.

        try:
            if ( not server_mode ):
                # Client negotiating with server. We begin the sequence.
                conn.sendall(nego_sequence[0] + "\n",0)
                seq = 1
            else:
                # Server negotiating with client. Client begins the sequence.
                seq = 0

            while ( seq < len(nego_sequence) ):
                # Current part (receive)

                expecting = nego_sequence[ seq ]
                msg = self.__Wait_For_Line(conn)
    
                if ( not msg.startswith(expecting) ):
                    if ( expecting.startswith(password_id) ):
                        # Right message - but wrong password?
                        #print "Wrong password"
                        return STATE_WRONG_PASSWORD

                        
                    #print "Wrong message:",expecting
                    return STATE_ERROR

                # Next part (send)
                seq += 1
                if ( seq >= len(nego_sequence) ):
                    break

                conn.sendall(nego_sequence[seq] + "\n",0)

                seq += 1

            print "Enter stage 2 " + str(server_mode)

            # Negotiation passed! 
            if ( server_mode ):

                # Server sends ID
                self.__mutex.acquire()
                msg = "%s%u\n" % (id_code_prefix, self._serv_id)
                self.__mutex.release()
                print 'ID:' + msg
                conn.sendall(msg, 0)

                # Client sends user name
                user_name_response = self.__Wait_For_Line(conn)
                if ( not user_name_response.startswith(user_name_id) ):
                    return STATE_ERROR

                self.__mutex.acquire()
                self.__user_name = user_name_response = user_name_response[
                        len(user_name_id):].strip()
                self.__mutex.release()
                if ( len(user_name_response) == 0 ):
                    return STATE_ERROR

                # Server sends mod name
                self.__mutex.acquire()
                msg = mod_id + self.__mod_name + "\n"
                self.__mutex.release()
                conn.sendall(msg, 0)

                # Client sends OK
                if ( self.__Wait_For_Line(conn) != ok_string ):
                    return STATE_ERROR
            else:
                # Server sends ID, we receive it
                msg = self.__Wait_For_Line(conn)
                if ( not msg.startswith(id_code_prefix) ):
                    return STATE_ERROR
                try:
                    serv_id_copy = int(msg[ len(id_code_prefix): ])
                except ValueError, emsg:
                    print "Bad ID"
                    return STATE_ERROR
                self.__mutex.acquire()
                self._serv_id = serv_id_copy
                self.__mutex.release()
                #print "Client receives id:",self._serv_id

                # Client sends user name
                self.__mutex.acquire()
                msg = user_name_id + self.__user_name + "\n"
                self.__mutex.release()
                conn.sendall(msg, 0)

                # Server sends mod name. Note: NOT FILENAME.
                # The mod filename is resolved by code in resources.py
                # and (if untrusted) the user will be warned before it is
                # loaded.
                m = self.__Wait_For_Line(conn)
                if ( not m.startswith(mod_id) ):
                    return STATE_ERROR
                m = m[ len(mod_id): ]

                if ( len(m) < 1 ):
                    print "Bad mod name"

                print "mod name = '%s'" % m
                self.__mutex.acquire()
                self.__mod_name = m
                self.__mutex.release()
                print 'ok?'

                # Client sends Ok
                conn.sendall(ok_string + "\n", 0)

            self.__mutex.acquire()
            id = self._serv_id
            user_name = self.__user_name
            self.__mutex.release()

            assert ( user_name != None )

            info = addr[ 0 ] # Originating IP address
            if ( self._mq.IM_Register_ID(id, info, user_name) ):
                return STATE_CONNECTED

        except socket.error, emsg :
            print "Negotiation send failed:",emsg

        print "Negotiation error"
        return STATE_ERROR # Failed..

    def Stop(self):
        self.__mutex.acquire()
        self._state = STATE_STOPPED
        self.__mutex.release()
        self._mq.Signal_Change()
        print "Servlet joining thread"
        self.join()
        print "Servlet done"

class Server(message_queue.Message_Queue):
    def __init__(self):
        message_queue.Message_Queue.__init__(self)
        self._ok = 0
        self._serv = None
        self._mod_name = ""

    def Receive(self):
        rx = message_queue.Message_Queue.Receive(self)
        return rx

    def Host(self,port,mod_name,password):
        """Hosts a new game. You must call this function exactly once
        per Server object. It sets up the port and starts the server,
        or returns an error message. """

        assert password != None
        self._mod_name = mod_name
        self._ok = 0
        out = None
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("", port))
            s.listen(8)
            s.setblocking(0)
            s.settimeout(0.5)
            self._ok = 1
        except socket.error, msg:
            out = msg

        if ( self._ok ):
            self._serv = self.Server((s, "local"), 
                    self.Get_Mod_Name(), password, self)

        return out

    def Is_Ok(self):
        return self._ok and self._serv.Is_Ok()

    def Stop(self):
        if ( self._serv != None ):
            self._serv.Stop()
            self._serv = None

    def Get_Mod_Name(self):
        return self._mod_name

    class Server(threading.Thread):
        "Manages the server - accepting connections and starting servlets."
        def __init__(self, conn, mod_name, password, mail_queue):
            threading.Thread.__init__(self)
            thread_mgr.Add_Thread(self)

            assert password != None
            self.__conn = conn
            self.__mod_name = mod_name
            self.__password = password
            self._mq = mail_queue
            self._ok = 1
            self.setName("Main Server")
            self.start()

        def Is_Ok(self):
            return self._ok

        def run(self):
            extra.Run_Managed(self.__Real_Run)

        def __Real_Run(self):
            print "Main server starting.."
            (ss, addr) = self.__conn
            servlets = []
            id = 20

            while self._ok:
                # Any new connections?
                new_users = []
                try:
                    cl = ss.accept()
                    while ( cl != None ):
                        (c,addr) = cl
                        new_users.append(cl)
                        cl = ss.accept()
                except socket.error, msg:
                    # Accept must have failed.
                    pass

                # Handle each new connection by creating a
                # servlet thread for it
                for (c, addr) in new_users:
                    print "SVR", repr(c), repr(addr)
                    if ( self._mq.Is_Open() ):
                        servlets.append(Connection_Servlet((c, addr),
                                self.__mod_name, 
                                None,
                                self.__password, self._mq,id))
                        id += 1
                    else:
                        print "Connection: but Message Queue is not open.\n"
                        c.close()

                # Servlets may die off. Detect this.
                servlets_copy = []
                while ( len(servlets) != 0 ):
                    sv = servlets.pop()
                    if ( sv.Is_Ok() ):
                        servlets_copy.append(sv)
                        
                servlets = servlets_copy

            # Clean exit:
            for sv in servlets:
                sv.Stop()
            ss.close()

        def Stop(self):
            self._ok = 0
            print "Server joining thread"
            self.join()
            print "Server done"
    
    # Used for internal sanity checking
    def Is_Server(self):
        return 1

    def Get_ID(self):
        return 10

        #if ( self._serv == None ):
            #return None
        #return self._serv.Get_ID()



#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: tile_db.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 


import random, pickle, os
import resources

from constants import COMPILED
from constants import RTR_VERSION


class Tile_Database_Exception(Exception):
    pass

class Rule_Tile_Record:
    pass



class Tile_Database:
    def __init__(self):
        self.Reset()

    def Reset(self):
        self.__all_tiles = []
        self.__all_tiles_hash = dict()
        self.__stack = []

    # The image filename for the specified tile is resolved by Add_Tile
    def Get_Image_Filename(self, name):
        self.__Assert_Present(name)
        f = self.__all_tiles_hash[ name ].img_filename
        assert f != None
        return f

    def Get_Mask_Filename(self, name):
        self.__Assert_Present(name)
        f = self.__all_tiles_hash[ name ].mask_filename
        assert f != None
        return f

    def Get_Tile_Data(self, name):
        self.__Assert_Present(name)
        tr = self.__all_tiles_hash[ name ]
        return (tr.edges, tr.flags, tr.extra_regions)

    def Get_Flags(self, name):
        self.__Assert_Present(name)
        return self.__all_tiles_hash[ name ].flags

    def Get_Autogen_Data(self, name):
        self.__Assert_Present(name)
        return self.__all_tiles_hash[ name ].autogen_data

    def Get_All_Declared_Tiles(self):
        return [ tile_record.name for tile_record in self.__all_tiles ]

    def Get_Num_For_Name(self, name):
        self.__Assert_Present(name)
        return self.__all_tiles_hash[ name ].number

    def Get_Name_For_Num(self, number):
        return self.__all_tiles[ number ].name

    def Get_Stack(self):
        return [ tr.name for tr in self.__stack ]

    def __Assert_Present(self, name):
        if ( not self.__all_tiles_hash.has_key(name) ):
            raise Tile_Database_Exception(
                "Tile %s is not known." % name)

    # Declare_Tile populates the internal tile records for the game.
    # It does not add the tiles to the stack (that's done by Add_Tile).
    def Declare_Tile(self, name, 
                edges, flags, extra_regions, 
                autogen_data):

        tile_record = Rule_Tile_Record()
        tile_record.name = name
        tile_record.edges = edges
        tile_record.flags = flags
        tile_record.extra_regions = extra_regions
        tile_record.autogen_data = autogen_data
        tile_record.number = len(self.__all_tiles)
        tile_record.img_filename = None
        tile_record.mask_filename = None
        tile_record.version = RTR_VERSION

        self.__all_tiles.append(tile_record)
        if ( self.__all_tiles_hash.has_key(name) ):
            raise Tile_Database_Exception(
                'Tile %s redefined! Tiles can only be defined once.' % name)

        self.__all_tiles_hash[ name ] = tile_record
        return tile_record

    # The given tile is added count times to the stack. Format should
    # be an image format (as a string), e.g. 'png', 'jpg', 'bmp', 'tga'.
    # If None is specified, then 'jpg' is tried, followed by 'png'.
    # Format only applies to the tile image, not the mask.
    def Add_Tile(self, name, count=1, format=None):

        if ( not self.__all_tiles_hash.has_key(name) ):
            # Hmm - tile not known. Attempt to load it.
            self.Load(name)

        tile_record = self.__all_tiles_hash[ name ]

        def Make_Name(ext, is_mask):
            if ( is_mask ):
                fname = "tilemasks/" + name
            else:
                fname = "tilepics/" + name
            return fname + "." + ext

        def Try_Format(ext):
            tile_record.img_filename = Make_Name(ext, False)
            return resources.Resource_Exists(tile_record.img_filename)

        # Check for mask (always PNG)
        tile_record.mask_filename = Make_Name("png", True)
        if ( not resources.Resource_Exists(tile_record.mask_filename) ):
            raise Tile_Database_Exception(
                'Tile mask for %s, \'%s\', not found.' % (
                        name, tile_record.mask_filename))

        # Check for image (various formats)
        if ( format == None ):
            rc = Try_Format("jpg")
            rc = rc or Try_Format("jpeg")
            rc = rc or Try_Format("png")
            if ( not rc ):
                raise Tile_Database_Exception(
                    'Tile image for %s, \'%s\', not found. Also tried .jpg.' % 
                            (name, tile_record.img_filename))
        else:
            rc = Try_Format(format)
            if ( not rc ):
                raise Tile_Database_Exception(
                    'Tile image for %s, \'%s\', not found.' % 
                            (name, tile_record.img_filename))
        
        # Ok - add to stack.
        for i in xrange(count):
            self.__stack.append(tile_record)

    def Shuffle_Tiles(self, depth=None):
       
        if ( depth == None ):
            begin_at = 0
        else:
            begin_at = len(self.__stack) - depth

        for x in xrange(begin_at, len(self.__stack) - 1):
            y = random.randint(x, len(self.__stack) - 1)
            (self.__stack[ x ], self.__stack[ y ]) = (
                    self.__stack[ y ], self.__stack[ x ])

    def Load(self, name):
        v = None
        try:
            tr = resources.Depickle("%s/%s.rtr" % (COMPILED, name))
            v = tr.version
        except Exception, x:
            raise Tile_Database_Exception(
                'Tile %s is unknown (not available). More:\n%s' % 
                        (name, str(x)))

        if ( v != RTR_VERSION ):
            raise Tile_Database_Exception(
                'Tile %s RTR data file is wrong version.' % name)
        if ( name != tr.name ):
            raise Tile_Database_Exception(
                'Tile %s RTR data file contains wrong name.' % name)

        if ( self.__all_tiles_hash.has_key(name) ):
            # Replace record
            tr.number = self.__all_tiles_hash[ name ]
            self.__all_tiles_hash[ name ] = tr
            self.__all_tiles[ tr.number ] = tr
        else:
            # Append record
            tr.number = len(self.__all_tiles)
            self.__all_tiles.append(tr)
            self.__all_tiles_hash[ name ] = tr
        
    def Save(self, name):
        tr = self.__all_tiles_hash[ name ]
        fname = os.path.join(COMPILED, "%s.rtr" % name)
        header = file(fname, "wb")
        pickle.dump(tr, header)
        header.close()




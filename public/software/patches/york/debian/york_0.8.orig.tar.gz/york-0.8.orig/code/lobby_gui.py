#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: lobby_gui.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# 
# 
# GUI classes, primarily for lobbies.
# We use Phil's pyGame Utilities (PGU) for our GUI widgets.
# 



import pygame , sys , time , random , threading
import lobby , server , client , library , message_queue 
import tile_cache , resources , message_window , main
import game_screen , extra , chat_box , config , support , demo_mq
import game_info , gui_base , meeple_graphics , lobby_gui_table

from pygame.locals import *
from pgu import gui
from gui_base import Base_Game_Screen, Base_GUI
from library import MENU_RESOLUTION

MARGIN = 40


class Main_Menu_Screen(Base_GUI):
    [ SEL_QUIT , SEL_OPTIONS ,
        SEL_HOST_INTERNET_GAME , SEL_HOST_LAN_GAME ,
        SEL_HOTSEAT_GAME , SEL_JOIN_INTERNET_GAME ,
        SEL_JOIN_LAN_GAME , SEL_PLAY_DEMO ] = xrange(8)

    def Full_Setup(self):

        tbl = gui.Table(align=-1, valign=0, background=(128, 128, 128))
        even = True
        gap = self.MENU_HEIGHT / 6
        (swidth, sheight) = MENU_RESOLUTION
        bwidth = ( swidth * 22 ) / 100

        def Spacer():
            tbl.tr()
            tbl.td(gui.Spacer(1, gap / 2), colspan=3)

        Spacer()
        tbl.tr()
        tbl.td(gui.Label("York", cls="h1", color=(0, 0, 0)), colspan=3)

        for (name,value) in [ 
        
            # Features that are commented out
            # will be available in later releases.

                #("Play Hotseat Game", self.SEL_HOTSEAT_GAME),
                #(None, None),
                #("Join Internet Game", self.SEL_JOIN_INTERNET_GAME),
                #("Host Internet Game", self.SEL_HOST_INTERNET_GAME),
                #(None, None),
                ("Join LAN Game", self.SEL_JOIN_LAN_GAME),
                ("Host LAN Game", self.SEL_HOST_LAN_GAME),
                ("Watch Recording", self.SEL_PLAY_DEMO),
                ("Options", self.SEL_OPTIONS),
                (None, None),
                ("Exit to " + extra.Get_OS(), self.SEL_QUIT)]:

            Spacer()
            tbl.tr()
            tbl.td(gui.Spacer(gap / 2, 1))
            if ( name == None ):
                tbl.td(gui.Spacer(1, gap))
            else:
                b = gui.Button(name,width=bwidth,
                        height=gap)
                self.Connect_Click(b,value)
                tbl.td(b)
            tbl.td(gui.Spacer(gap / 2, 1))

        Spacer()

        tbl2 = gui.Table(align=0, valign=0)
        tbl2.tr()
        tbl2.td(gui.Spacer(width=gap, height=1))
        tbl2.td(tbl, valign=0)
        tbl2.td(gui.Spacer(swidth - ( bwidth + gap ), gap))

        (tw, th) = tbl2.resize()

        container = gui.Container(width=swidth, height=sheight)
        container.add(tbl2, 0, ( sheight - th ) / 2 ) 
        return container

    def Draw_Background(self,surf):
        main.Draw_Menu_Back(surf, False)
        support.Render_Copyrights(surf,
                (surf.get_rect().width - 10, 10), (0, 0, 0))
        support.Render_Copyrights(surf,
                (surf.get_rect().width - 11, 11), (255, 255, 240))



class Message_Screen(Base_GUI):
    def __init__(self):
        Base_GUI.__init__(self)
        self.__dlg = None

    def Show_Message_Dialog(self, exit_message):

        def Ok_Fn(args=None):
            self.__dlg.close()
            self.Set_Return_Code(self.SEL_QUIT)

        self.__dlg = support.Make_Simple_Dialog("York",
                exit_message, None, Ok_Fn)
        self.__dlg.open()

    def Full_Setup(self):
        return gui.Spacer(1,1)


class Lobby_Master_Screen(Base_GUI):

    SEL_START_GAME = 1

    def __init__(self, rules):
        self.__rules = rules
        self.__ready = self.Is_Master()
        self.__demo_recording = False
        self.__message_widget = None
        Base_GUI.__init__(self)

    def Message(self, msg, colour=(200,200,200)):
        if ( self.__message_widget != None ):
            self.__message_widget.Message(msg, colour)

    def Draw_Messages(self, surf):
        # Don't do this. We use a message widget, not a message window.
        # Distinction is important - message widgets are embedded in
        # the GUI form, message windows are overlaid onto screen.
        pass



    def Full_Setup(self):
        (w,h) = MENU_RESOLUTION
        m2 = MARGIN
        m4 = m2 * 2
        m1 = m2 / 2
        pw = ( w * 65 ) / 100 
        ph = ( h - ( m4 + chat_box.CHAT_BOX_SIZE + m1 ))
        mch = ph / 4
        ph = ph - mch
        ch = h / 4

        colour_modulus = 3
        ctw = ( w * 15 ) / 100
        cth = ((( w * 25 * colour_modulus ) / 
                    self.__rules.Get_Max_Players() ) / 100 )

        screen_c = gui.Container(width=w, height=h)

        main_t_2 = gui.Table(align=0, valign=0,
                        width=w - m2, height=h - m2,
                        background=library.colours.lobby_bg)
        main_t_2.tr()

        main_t = gui.Table(align=0, valign=0,
                        width=w - m2, height=h - m2,
                        background=library.colours.lobby_bg)
        main_t.tr()
        main_t.td(gui.Spacer(width=m1, height=1), rowspan=2)
        self.__players_t = lobby_gui_table.Players_Table(self.__rules,
                    self.Is_Master(), 
                    self.__Kick_Pressed, (pw, ph), 
                    width=pw, height=ph)
        main_t.td(self.__players_t, valign=-1)


        controls_t = gui.Table(align=1)

        def Spacer():
            controls_t.tr()
            controls_t.td(gui.Spacer(width=1,height=5))

        def Heading(text, sz=10):
            controls_t.tr()
            controls_t.td(gui.Label(text, align=0,
                    font=resources.Get_Font(sz),
                    color=library.colours.lobby_header_fg))
            Spacer()

        controls_t.tr()
        controls_t.td(gui.Image(resources.Get_Resource_Image("bigicon.png")))

        Heading("Game Setup", 20)

        self.__ready = False
        self.__ready_button = gui.Button("XXXXXX", align=0)
        self.__ready_button.connect(gui.CLICK, self.__Ready_Pressed, None)
        self.__Ready_Label()

        self.__subgame_type_popup = gui.Select(width=ctw)
        for (num, name) in self.__rules.Get_Subgame_List():
            self.__subgame_type_popup.add(name, num)
        self.__subgame_type_popup.value = 0

        controls_t.tr()
        controls_t.td(self.__subgame_type_popup)
        if ( self.Is_Master() ):
            self.__subgame_type_popup.connect(gui.CHANGE,
                        self.__Subgame_Change, None)
        else:
            self.__subgame_type_popup.disabled = True

        Heading("Your status:")
        controls_t.tr()
        controls_t.td(self.__ready_button)
        Spacer()

        if ( self.Is_Master() ):
            Heading("Host controls:")
            self.__start_button = gui.Button("Start Game", align=0)
            self.__start_button.connect(gui.CLICK,
                            self.__Start_Game, None)
            controls_t.tr()
            controls_t.td(self.__start_button)
            Spacer()

        Heading("Available colours:")
        controls_t.tr()
        self.__colours_t = lobby_gui_table.Colours_Table(self.__rules, 
                    colour_modulus,
                    self.__Colour_Pressed, (ctw, cth), width=ctw, height=cth)
        controls_t.td(self.__colours_t)

        l = [ 
            # Add extra buttons here...

            #("Drop Colour", self.__Drop_Colour),
            "",
            ("Exit Game", self.Quit) ]

        controls_t.tr()
        for description in l:
            if ( type(description) == str ):
                Heading(description)
            else:
                (name, fn) = description
                controls_t.tr()
                b = gui.Button(name, align=0)
                b.connect(gui.CLICK, fn, None)
                controls_t.td(b)
                Spacer()

        main_t.td(controls_t, rowspan=2)
        main_t.td(gui.Spacer(width=m1,height=3), rowspan=2)

        (self.__chat_box, self.__chat_c) = chat_box.Make_Chat_Box(
                (w - m4, h), None, self.__Send_Chat_Msg)
        main_t.tr()
        self.__message_widget = message_window.Message_Window(
                (pw, mch), 100000000, True)
        main_t.td(self.__message_widget)
        main_t.tr()
        main_t.td(self.__chat_c, colspan=4)
        #main_t.add(chat_c, m1, m2 + ph)

        main_t_2.td(main_t)

        screen_c.add(main_t_2, m1, m1)
        return screen_c 

    def Quit(self,value=None):
        Base_GUI.Quit(self, value)
        if ( self.Is_Master() ):
            self.__lobby.Server_Quit()
        else:
            self.__lobby.Client_Quit()

    def Is_Master(self):
        return True

    def Run(self, surf, clock, lobby):
        self.__lobby = lobby
        self.__ready = False
        self.Tick()
        return Base_GUI.Run(self, surf, clock)

    def Tick(self):
        assert ( self.__lobby != None )
        assert ( self.__lobby.Is_Server() == self.Is_Master() )

        update = self.__lobby.Tick()

        if ( update ):
            my_id = self.__lobby.Get_Client_MQ().Get_ID()

            # Update required.
            for model_slot in self.__lobby.Get_Slots():

                if ( not model_slot.dirty ):
                    continue

                self.__players_t.Redraw_Row(model_slot.number, 
                            model_slot, my_id)
                model_slot.dirty = False
                self.General_Update()
    
            for (colour, available) in enumerate(
                        self.__lobby.Get_Available_Colours()):
                self.__colours_t.State_Change(colour, available)

            if (( not self.Is_Master() )
            or ( self.__lobby.Is_Resume() )):
                self.__subgame_type_popup.value = self.__lobby.Get_Subgame()
                self.__subgame_type_popup.disabled = True
            else:
                self.__subgame_type_popup.disabled = False

        # Any new messages?
        msg = self.__lobby.Get_Message()
        if ( msg != None ):
            self.Message(msg)
            self.General_Update()

        if ( self.__lobby.Client_Kicked() ):
            # Oh no..
            self.Set_Return_Code(self.SEL_QUIT)
        elif ( self.__lobby.Client_Starting() ):
            # Go!
            self.Set_Return_Code(self.SEL_START_GAME)
        elif ( not self.__lobby.Is_Ok() ):
            # Lobby vanished
            self.Set_Return_Code(self.SEL_QUIT)

    def __Colour_Pressed(self, colour_number):
        if ( 0 <= colour_number < self.__rules.Get_Max_Players() ):
            self.__lobby.Client_Select_Colour(colour_number)

    def __Kick_Pressed(self, slot_number):
        slots = self.__lobby.Get_Slots()
        if (( 0 <= slot_number < len(slots) )
        and ( self.Is_Master() )):
            bye_bye = slots[ slot_number ]
            if ( bye_bye.id != self.__lobby.Get_Client_MQ().Get_ID() ):
                self.__lobby.Kick_ID(bye_bye.id, None)

    def __Ready_Pressed(self, arg=None):
        self.__ready = not self.__ready
        self.__lobby.Client_Set_Ready(self.__ready)
        self.__Ready_Label()

    def __Start_Game(self, arg=None):
        assert self.Is_Master()
        self.__lobby.Server_Start_Game()

    def __Ready_Label(self):
        if ( self.__ready ):
            self.__ready_button.value = "Ready"
        else:
            self.__ready_button.value = "Not Ready"

    def __Send_Chat_Msg(self, arg=None):
        if ( len(self.__chat_box.value) != 0 ):
            self.__lobby.Client_Chat(self.__chat_box.value)
            self.__chat_box.value = ""
            self.__chat_box.repaint()
        self.__chat_box.focus()

    def __Subgame_Change(self, arg=None):
        assert self.Is_Master()
        self.__lobby.Set_Subgame(self.__subgame_type_popup.value)

    def Event(self,e):
        # Special event handler
        if ( e.type == KEYDOWN ):
            if ( e.key == K_RETURN ):
                self.__Send_Chat_Msg()
        Base_GUI.Event(self, e)

class Lobby_Slave_Screen(Lobby_Master_Screen):

    def Is_Master(self):
        return False


class Hotseat_Lobby_Screen(Lobby_Master_Screen):
    pass



class Big_Selection_List_Screen(Base_GUI):

    DESC_LINES = 7

    def Full_Setup(self):
        (w,h) = MENU_RESOLUTION
        m2 = MARGIN
        m4 = m2 * 2
        m1 = m2 / 2
        lh = ( h * 35 ) / 100

        bg = library.colours.sel_screen_bg
        fg = library.colours.sel_screen_fg
        #end_buttons_c = gui.Container(align=0, valign=0, 
                        #width=w - m2, height=50)

        big_list_c = gui.List(w - m4, lh, background=bg)

        big_list_c2 = gui.Container(width=w - m2, height=lh, background=bg)
        big_list_c2.add(big_list_c, m1, 0)

        sel_list_c = gui.Container(align=0, valign=0, 
                        width=w - m2, height=h - m2 )
        sel_list_t = gui.Table(align=0, valign=0)
        sel_list_t.tr()
        sel_list_t.td(gui.Label(
                self.Get_Title(),cls="h1",color=
                library.colours.title_colour,align=0))
        sel_list_t2 = gui.Table(background=bg)
        sel_list_t2.tr()
        sel_list_t2.td(gui.Container(width=w - m2, background=bg, height=m1))
        sel_list_t2.tr()
        sel_list_t2.td(gui.Label(
                "  " + self.Get_Subtitle(), color=fg), align=-1)
        sel_list_t2.tr()
        sel_list_t2.td(big_list_c2)
        sel_list_t2.tr()
        extra_area_c = gui.Container(width=w - m2, background=bg)
        sel_list_t2.td(extra_area_c)
        extra_area_c.add(self.Get_Extra_Children_Table(w - m2), 0, 0)
        sel_list_t2.tr()
        sel_list_t2.td(gui.Container(width=w - m2, background=bg, height=m1))
        sel_list_t2.tr()

        end_buttons_t = gui.Table()
        end_buttons_t.tr()
        support.Buttons2Table(end_buttons_t, self.Get_Buttons())
        sel_list_t2.td(end_buttons_t, align=1)
        sel_list_t2.tr()
        sel_list_t2.td(gui.Container(width=w - m2, background=bg, height=m1))

        sel_list_t.tr()
        sel_list_t.td(sel_list_t2)
        sel_list_c.add(sel_list_t, 0, 0)

        outside_c = gui.Container(width=w - m2, height=h)
        outside_c.add(sel_list_c, 0, 0)

        screen_c = gui.Container(width=w, height=h)
        screen_c.add(outside_c, m1, m1)

        #end_buttons_c.add(end_buttons_t, 0, 0)

        self.__list_widget = big_list_c
        self.__blank = pygame.Surface(library.MOD_ICON_SIZE)
        self.__blank.fill((255, 255, 255))
        self.Reset_List()
        return screen_c 

    def Get_Extra_Children_Table(self, width):
        return gui.Spacer(1,1)

    def Get_Title(self):
        return "None"

    def Get_Subtitle(self):
        return "None"

    def Press_Refresh(self, arg=None):
        pass

    def Reset_List(self):
        self.__list_widget.clear()

    def Add_To_List(self, label, image=None):
        if ( image == None ):
            iw = gui.Image(self.__blank)
        else:
            iw = gui.Image(image)

        self.__list_widget.add(label, iw, label)
        self.__list_widget.repaint()

    def Get_Selection(self):
        return self.__list_widget.value

    def Get_Buttons(self):
        return [("Refresh", self.Press_Refresh),
                (None, None),
                ("Confirm", self.Press_Ok),
                ("Cancel", self.Press_Cancel)]
    

class Mod_Selection_List_Screen(Big_Selection_List_Screen):

    def __init__(self,**params):
        Big_Selection_List_Screen.__init__(self, **params)
        self.__mod_data = dict()
        self.__mod_file_name = self.__mod_name = None
        self.__last_filename = None

    def Run(self, surf, clock):
        self.__dlg = None
        self.__Rebuild()
        return Big_Selection_List_Screen.Run(self,surf,clock)

    def Rules_Only(self):
        # Show only rules mods.
        return True

    def __Rebuild(self):
        self.Reset_List()
        self.__mod_data = dict()
        for mod_rec in resources.Get_Mod_List():
            if (( not mod_rec.is_omnipresent )
            and ( mod_rec.is_rules_mod != self.Rules_Only() )):
                continue

            key = mod_rec.name + ": " + mod_rec.desc[ 0 ]
            self.__mod_data[ key ] = mod_rec
            self.Add_To_List(key, mod_rec.icon_surf)

    def Press_Refresh(self, arg=None):
        resources.Reset()
        self.__Rebuild()

    def Get_Title(self):
        return "Game Modification Selection"

    def Get_Subtitle(self):
        return "Available Modifications:"

    def __Get_Mod_Data(self):
        v = self.Get_Selection()
        if (( v != None ) and ( self.__mod_data.has_key( v ) )):
            return self.__mod_data[ v ]
        else:
            return None

    def Press_Ok(self, args=None):
        mod_rec = self.__Get_Mod_Data()

        if (( mod_rec != None )
        and ( mod_rec.filename != None ) 
        and ( len(mod_rec.filename) > 0 )):
            if ( resources.Is_Warning_Required(mod_rec.filename) ):
                self.__dlg = support.Make_Warning_Dialog(self.Get_Title(),
                    mod_rec.name, self.__Confirm_Ok, None)
                self.__dlg.open()
            else:
                self.__dlg = None
                self.__Confirm_Ok()
        else:
            self.__dlg = support.Make_Simple_Dialog(self.Get_Title(),
                ["Please select a modification from the list."],
                None, None)
            self.__dlg.open()

    def __Confirm_Ok(self, args=None):
        mod_rec = self.__Get_Mod_Data()
        if ( mod_rec != None ):
            self.__mod_file_name = mod_rec.filename
            self.__mod_name = mod_rec.name

            if ( self.__dlg != None ):
                self.__dlg.close()

            if (( len(mod_rec.filename) > 0 ) and ( len(mod_rec.name) > 0 )):
                self.Set_Return_Code(self.SEL_OK)

    def Get_Extra_Children_Table(self, width):
        (self.__desc_lines, t) = support.Make_Multiline_Widget(
                    self.DESC_LINES, width)
        return t

    
    def Get_Mod_Name(self):
        return self.__mod_name

    def Get_Mod_File_Name(self):
        return self.__mod_file_name

    def Tick(self):
        mod_rec = self.__Get_Mod_Data()
        if ( mod_rec != None ):
            name = mod_rec.name
            desc = mod_rec.desc
            filename = mod_rec.filename

            if ( filename != self.__last_filename ):
                desc = [""] + list(desc) + [""]
                support.Change_Multiline_Widget(self.__desc_lines, desc,
                        library.colours.sel_screen_fg)

                self.__last_filename = filename
              
class Host_Setup_Screen(Mod_Selection_List_Screen):
    SEL_OPTIONS = 1
    SEL_RESUME = 2

    def __init__(self, published, name_hint, **params):
        self.__published = published
        self.__game_name = self.__game_password = None
        self.__name_hint = name_hint
        Mod_Selection_List_Screen.__init__(self, **params)

    def Get_Title(self):
        if ( self.__published ):
            return "Host an Internet Game"
        else:
            return "Host a LAN Game"

    def Get_Buttons(self):
        b = Mod_Selection_List_Screen.Get_Buttons(self)
        b = [ ("Options", self.Options),
                ("Resume from Recording", self.Resume) ] + b
        return b

    def Press_Ok(self, args=None):
        if ( self.Validate() ):
            # Now validate mod selection
            Mod_Selection_List_Screen.Press_Ok(self)

    def Validate(self):
        # Validate inputs
        game_name = extra.Filter_Message(self.__game_name.value.strip())
        game_password = extra.Filter_Message(self.__game_password.value.strip())
        min_len = 5

        if (( game_name != None ) and ( len(game_name) >= min_len )):
            config.cfg.game_name = game_name
            config.cfg.game_password = game_password
            return True
        else:
            dlg = support.Make_Simple_Dialog(self.Get_Title(),
                ["You must enter a name for your game. Game names",
                "must be at least %u letters in length." % min_len ],
                None, None)
            dlg.open()
            return False

    def Get_Resume_Flag(self):
        return self.__resume.value

    def Get_Extra_Children_Table(self, width):
        t = gui.Table()
        t.tr()
        part = Mod_Selection_List_Screen.Get_Extra_Children_Table(self, width)
        t.td(part)
        t.tr()

        fg = library.default_colours.sel_screen_fg

        t2 = gui.Table()
        t2.tr()
        t2.td(gui.Label(" Game name:  ",color=fg))
        self.__game_name = gui.Input(size=30)
        if ( len(config.cfg.game_name) > 0 ):
            self.__game_name.value = config.cfg.game_name
        else:
            self.__game_name.value = self.__name_hint

        t2.td(self.__game_name)
        t2.td(gui.Label("   Password:  ",color=fg))
        self.__game_password = gui.Input(size=10)
        self.__game_password.value = config.cfg.game_password
        t2.td(self.__game_password)
        t2.td(gui.Label("   "))

        t.td(t2)
        return t
        
    def Options(self, args=None):
        self.Set_Return_Code(self.SEL_OPTIONS)

    def Resume(self, args=None):
        # Only validate game name and password
        if ( self.Validate() ):
            self.Set_Return_Code(self.SEL_RESUME)


class Join_Game_Screen(Big_Selection_List_Screen):

    def __init__(self,**params):
        Big_Selection_List_Screen.__init__(self, **params)
        self.__dc_addr_w = self.__dc_port_w = self.__dc_dlg = None
        self.__last_selection = None
        self.__selected_game_info = None
        self.__game_list = dict()

    def Run(self, surf, clock):
        self.__address = None
        self.__Rebuild()
        return Big_Selection_List_Screen.Run(self,surf,clock)

    def Get_Game_List(self):
        return [ x for x in config.cfg.history if x.Is_Valid() ]

    def Get_Game_Info(self):
        return self.__selected_game_info

    def __Rebuild(self):
        self.Reset_List()

        gl = self.Get_Game_List()
        gl.sort(cmp=lambda x,y: cmp(y.timestamp, x.timestamp))
        self.__game_list = dict()

        for ginfo in gl:
            key = '%s: %s [%s]' % (ginfo.time, ginfo.name, 
                                    str(ginfo.mod_name))
            self.__game_list[ key ] = ginfo
            self.Add_To_List(key, ginfo.icon)

    def Press_Refresh(self, arg=None):
        self.__Rebuild()

    def Get_Title(self):
        return "Connect To Game"

    def Get_Subtitle(self):
        return "Recently Played Games:"

    def Get_Buttons(self):
        b = Big_Selection_List_Screen.Get_Buttons(self)
        b = [ ("Direct Connection...", self.Direct_Connection),
                (None, None) ] + b
        return b

    def Direct_Connection(self, args=None):
        ([self.__dc_addr_w, self.__dc_port_w], self.__dc_dlg) = (
                support.Make_Input_Dialog(
                    self.Get_Title(), 
                    ["Enter the Internet address of the game:",
                        "Enter the port number:"],
                    "Connect", self.__Do_Direct_Connect, None))
        self.__dc_addr_w.value = ""
        self.__dc_port_w.value = str(library.DEFAULT_PORT)
        self.__dc_dlg.open()

    def __Do_Direct_Connect(self, args=None):
        addr = self.__dc_addr_w.value
        port = self.__dc_port_w.value 

        try:
            port = int(port)
        except:
            dlg = support.Make_Simple_Dialog(self.Get_Title(),
                ["You must enter a port number. Ask the person",
                "hosting the game to tell you the correct value."],
                None, None)
            dlg.open()
            return
       
        if (( port < 1024 ) or ( port > 65535 )):
            dlg = support.Make_Simple_Dialog(self.Get_Title(),
                ["The port number is not valid."],
                None, None)
            dlg.open()
            return

        if (( addr == None ) or ( len(addr) < 2 )):
            dlg = support.Make_Simple_Dialog(self.Get_Title(),
                ["The Internet address is not valid."],
                None, None)
            dlg.open()
            return

        # Ok, go for it!
        self.__selected_game_info = gi = game_info.Game_Info()
        gi.name = 'Game on %s:%u' % (addr, port)
        gi.address = addr
        gi.port = port
        gi.mod_name = "?"
        config.Add_Game_To_History(gi)
        self.Set_Return_Code(self.SEL_OK)

    def Press_Ok(self, args=None):
        v = self.Get_Selection()
        if (( v != None ) and ( self.__game_list.has_key( v ) )):

            self.__selected_game_info = self.__game_list[ v ]
            self.Set_Return_Code(self.SEL_OK)
        else:
            dlg = support.Make_Simple_Dialog(self.Get_Title(),
                ["The Internet address is not valid."],
                None, None)
            dlg.open()
            return


    def Get_Extra_Children_Table(self, width):
        (self.__game_info, t) = support.Make_Multiline_Widget(
                    self.DESC_LINES, width)
        return t

    def Time_Type(self):
        return "Last played: "

    def Tick(self):
        v = self.Get_Selection()
        if (( v != None ) and ( self.__game_list.has_key( v ) )
        and ( v != self.__last_selection )):
            self.__last_selection = v
            ginfo = self.__game_list[ v ]

            desc = [ "",
                "Game name: " + ginfo.name,
                "Modification: " + ginfo.mod_name,
                "Address: " + ginfo.address + 
                        " port " + str(ginfo.port),
                self.Time_Type() + ginfo.time,
                "" ]

            support.Change_Multiline_Widget(self.__game_info, desc,
                    library.colours.sel_screen_fg)


class Inter_Screen(Base_GUI):
    # Goes between 'Join Game' (selection screen) and Lobby

    def Full_Setup(self):
        return gui.Spacer(1,1)

    def Run(self, surf, clock, user_name, client_mq, game_info):
        self.__client_mq = client_mq 
        self.__game_info = game_info
        self.__msg = None
        self.__mod_name = self.__mod_file_name = None
        self.__state = self.__Connect
        self.__user_name = user_name
        self.__password = ""
        self.__password_widget = None
        return Base_GUI.Run(self,surf,clock)

    def Get_Mod_Name(self):
        return self.__mod_name

    def Get_Mod_File_Name(self):
        return self.__mod_file_name

    def Get_Title(self):
        return "Connecting..."

    def __Close(self):
        if ( self.__msg != None ):
            self.__msg.close()
        self.__msg = None

    def Tick(self):
        assert self.__game_info != None
        cmq = self.__client_mq
        self.__state(cmq)

    # A state machine is used to manage the connection.

    def __Connect(self, cmq):
        self.__Close()
        self.__msg = support.Make_Simple_Dialog(self.Get_Title(),
                ["Connecting to game..."], None, self.__Exit)
        self.__msg.open()
        self.__state = self.__Do_Connect

    def __Do_Connect(self, cmq):
        self.__state = self.__Await_Response
        cmq.Connect(self.__game_info.address, 
                    self.__game_info.port, 
                    self.__user_name, self.__password)
        print 'cmq.Connect() returns'

    def __Wait(self, cmq):
        pass

    def __Await_Response(self, cmq):

        if ( cmq.Is_Ok() ):
            cmq_state = cmq.Get_State()

            # Success states:
            if ( cmq_state == server.STATE_CONNECTED ):
                self.__state = self.__Wait
                self.__mod_name = mn = cmq.Get_Mod_Name()
                self.__mod_file_name = mf = resources.Get_Mod_File_Name(mn)

                print 'mod name:',mn,'mod file:',mf

                if ( mf == None ):
                    self.__Close()
                    self.__msg = support.Make_Simple_Dialog(self.Get_Title(),
                        ["This game is running the modification '%s'." %
                            support.Shorten(mn),
                        "This modification is not installed on your computer.",
                        "You cannot join this game without installing it."],
                        None, self.__Exit)
                    self.__msg.open()
                else:
                    if ( resources.Is_Warning_Required(mf) ):
                        self.__Close()
                        self.__msg = support.Make_Warning_Dialog(
                            self.Get_Title(),
                            mn, self.__Enter_Game, self.__Exit)
                        self.__msg.open()
                    else:
                        self.__Enter_Game()

            # Semi-success state:
            elif ( cmq_state == server.STATE_WRONG_PASSWORD ):
                cmq.Stop()
                self.__Enter_Password(cmq)

            # Failure states:
            elif ( cmq_state in [ server.STATE_TIMEOUT,
                    server.STATE_STOPPED, server.STATE_KICKED,
                    server.STATE_DISCONNECTED, server.STATE_ERROR ] ):
                self.__Failure(cmq)

        else:
            self.__Failure(cmq)

    def __Failure(self, cmq):
        cmq.Stop()
        self.__state = self.__Wait
        self.__Close()
        self.__msg = support.Make_Simple_Dialog(self.Get_Title(),
            ["Unable to connect to the specified game.",
            "Please ensure you have given the correct address",
            "and port number."],
            None, self.__Exit)
        self.__msg.open()
               
    def __Exit(self, args=None):
        self.Set_Return_Code(self.SEL_QUIT)

    def __Enter_Game(self, args=None):
        self.Set_Return_Code(self.SEL_OK)

    def __Enter_Password(self, cmq):
        self.__Close()
        self.__state = self.__Wait
        ([self.__password_widget], self.__msg) = (
                support.Make_Input_Dialog(
                    self.Get_Title(), 
                    ["Enter game password:"],
                    "Connect", self.__Confirm_Password, None))
        self.__password_widget.value = self.__password
        self.__msg.open()

    def __Confirm_Password(self, cmq):
        self.__password = self.__password_widget.value
        self.__state = self.__Connect 


class Enter_Name_Screen(Base_GUI):
    # Goes between Main Menu and Join Game/Host Game
    def __init__(self, scr_name):
        Base_GUI.__init__(self)
        self.__screen_name = scr_name

    def Full_Setup(self):
        return gui.Spacer(1,1)

    def Run(self, surf, clock):
        ([self.__name_widget], self.__dlg) = (
                support.Make_Input_Dialog(
                    self.Get_Title(), 
                    ["Enter your name:"],
                    self.Get_Title(), self.__Confirm, self.Press_Cancel))
        self.__name = self.__name_widget.value = config.cfg.name
        self.__dlg.open()
        return Base_GUI.Run(self,surf,clock)

    def Get_Name(self):
        return self.__name

    def Get_Title(self):
        return self.__screen_name

    def __Confirm(self, args=None):
        assert self.__dlg != None 

        self.__name = library.Launder_Player_Name(self.__name_widget.value)
        if ( len(self.__name) != 0 ):
            config.cfg.name = self.__name
            self.__dlg.close()
            self.__dlg = None
            self.Set_Return_Code(self.SEL_OK)

class Demo_Selection_List_Screen(Big_Selection_List_Screen):

    def __init__(self,**params):
        Big_Selection_List_Screen.__init__(self, **params)
        self.__demo_data = dict()
        self.__demo_file_name = self.__mod_file_name = self.__mod_name = None

    def Run(self, surf, clock):
        self.__dlg = None
        self.__Rebuild()
        return Big_Selection_List_Screen.Run(self,surf,clock)

    def __Rebuild(self):
        self.Reset_List()

        mod_data = dict()
        for mod_rec in resources.Get_Mod_List():
            if ( not mod_rec.is_rules_mod ):
                continue

            mod_data[ mod_rec.mod_name ] = mod_rec

        self.__demo_data = dict()
        for demo_info in demo_mq.Get_Demo_List():
            (demo_file_name, mod_name, size) = demo_info
            key = "%s [%s] %u kb" % (demo_file_name, mod_name, size)
            
            if ( not mod_data.has_key( mod_name ) ):
                key += " - mod not installed"
                mod_info = None
            else:
                mod_info = mod_data[ mod_name ]

            self.__demo_data[ key ] = (demo_info, mod_info)
            self.Add_To_List(key, None)

    def Press_Refresh(self, arg=None):
        self.__Rebuild()

    def Get_Title(self):
        return "Recording Selection"

    def Get_Subtitle(self):
        return "Available Recordings:"

    def __Get_Demo_Data(self):
        v = self.Get_Selection()
        if (( v != None ) and ( self.__demo_data.has_key( v ) )):
            return self.__demo_data[ v ]
        else:
            return (None, None)

    def Press_Ok(self, args=None):
        (demo_info, mod_info) = self.__Get_Demo_Data()

        if ( demo_info != None ):
            (demo_file_name, mod_name, size) = demo_info

            if ( mod_info != None ):
                mod_file_name = mod_info.filename

                if ( resources.Is_Warning_Required(mod_file_name) ):
                    self.__dlg = support.Make_Warning_Dialog(self.Get_Title(),
                        mod_name, self.__Confirm_Ok, None)
                    self.__dlg.open()
                else:
                    self.__dlg = None
                    self.__Confirm_Ok()
            else:
                self.__dlg = support.Make_Simple_Dialog(self.Get_Title(),
                    ["The game modification for this recording",
                    "is not installed."],
                    None, None)
                self.__dlg.open()
        else:
            self.__dlg = support.Make_Simple_Dialog(self.Get_Title(),
                ["Please select a recording from the list."],
                None, None)
            self.__dlg.open()

    def __Confirm_Ok(self, args=None):
        (demo_info, mod_info) = self.__Get_Demo_Data()
        (demo_file_name, mod_name, size) = demo_info

        self.__mod_file_name = mod_file_name = mod_info.filename
        self.__mod_name = mod_name
        self.__demo_file_name = demo_file_name 

        if ( self.__dlg != None ):
            self.__dlg.close()

        if (( len(mod_file_name) > 0 ) 
        and ( len(mod_name) > 0 )
        and ( len(demo_file_name) > 0 )):
            self.Set_Return_Code(self.SEL_OK)

    def Get_Mod_Name(self):
        return self.__mod_name

    def Get_Mod_File_Name(self):
        return self.__mod_file_name

    def Get_Demo_File_Name(self):
        return self.__demo_file_name

    def Get_Extra_Children_Table(self, width):
        (unused, t) = support.Make_Multiline_Widget(
                    self.DESC_LINES, width)
        return t

class Tile_Mod_Selection_List_Screen(Mod_Selection_List_Screen):

    def Rules_Only(self):
        # Show only tile mods.
        return False

    def Get_Title(self):
        return "Tile Modification Selection"

    def Get_Subtitle(self):
        return "Available Modifications:"



#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: options_gui.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 


import pygame
from pygame.locals import *
from pgu import gui

import config, support, library, gui_base, lobby_gui


CENTRE_MARGIN = 10

class Options_Generator:
    def __init__(self):
        self.__tbl = gui.Table()
        self.__apply_functions = []
        self.__validator_functions = []
        self.__vid_res = None

    def __Make(self, widget, text, config_attribute):
        self.__tbl.tr()
        self.__tbl.td(gui.Label(text), align=1, valign=0)
        self.__tbl.td(gui.Spacer(width=CENTRE_MARGIN, height=1))
        self.__tbl.td(widget, align=-1, valign=0)

        def Apply_Fn():
            setattr(config.cfg, config_attribute, widget.value)

        self.__apply_functions.append(Apply_Fn)
        return widget

    def __Make_Switch(self, text, config_attribute):
        setting = bool(getattr(config.cfg, config_attribute))
        return self.__Make(gui.Switch(setting), text, config_attribute)

    def __Make_Select(self, text, config_attribute, options):
        setting = str(getattr(config.cfg, config_attribute))
        if ( not ( setting in options )):
            print 'setting forced to',options[ 0 ]
            setting = options[ 0 ]
        w = gui.Select(value=setting, background=(200, 200, 200))
        for v in options:
            w.add(v, v)
        w.value = setting
        return self.__Make(w, text, config_attribute)

    def __Make_Input(self, text, config_attribute, validator_fn):
        setting = str(getattr(config.cfg, config_attribute))
        w = gui.Input(value=setting, width=15)

        def Validate_Fn():
            return validator_fn(w.value)
            
        self.__validator_functions.append(Validate_Fn)
        return self.__Make(w, text, config_attribute)
    
    def __Make_Section(self, name):
        self.__tbl.tr()
        self.__tbl.td(gui.Spacer(width=1, height=CENTRE_MARGIN), colspan=3)
        self.__tbl.tr()
        self.__tbl.td(gui.Label('  %s' % name, cls='h3'), 
                        align=-1, valign=0, colspan=3,
                        background=library.colours.section_name_bg)
        self.__tbl.tr()
        self.__tbl.td(gui.Spacer(width=1, height=CENTRE_MARGIN / 2), colspan=3)

            
    def Add_Omnipresent_Options(self):
        self.__Make_Select('Remaining tile count shown on board as:',
                'remaining_tile_count',
                ['Number of tiles', 'Percentage of bag', 'Not shown'])

    def Add_Option_Screen_Options(self):
        display_modes = []
        for (x, y) in pygame.display.list_modes():
            if (( x >= 800 ) and ( y >= 600 )):
                display_modes.append("%ux%u" % (x,y))


        self.__Make_Section('Game options')
        self.Add_Omnipresent_Options()
        self.__Make_Section('Video options')
        self.__vid_res = self.__Make_Select('Screen resolution during game:',
                'video_resolution', display_modes)

        self.__Make_Switch('Run fullscreen', 'fullscreen')
        self.__Make_Section('Server options')

        def Validate_Port(x):
            try:
                x = int(x)
            except:
                x = 0

            a = 1024
            b = 65535
            if ( not ( a <= x <= b )):
                return 'Server port value must be between %u and %u.' % (a, b)
            return None # valid

        self.__Make_Input('Server port', 'server_port', Validate_Port)

    def Get_Table(self):
        return self.__tbl

    def Press_Apply(self, *args):
        # validation
        for fn in self.__validator_functions:
            x = fn()
            if ( x != None ):
                dlg = support.Make_Simple_Dialog('Configuration',
                        [x], None, None)
                dlg.open()
                return dlg
        # apply
        for fn in self.__apply_functions:
            fn()
        config.Save()
        return None

    def Get_Mode_To_Test(self):
        return config.Get_Video_Res(self.__vid_res.value)


class Options_Screen(gui_base.Base_GUI):
    def Full_Setup(self):
        (w,h) = library.MENU_RESOLUTION
        m2 = lobby_gui.MARGIN
        m = m2 / 2

        self.__og = Options_Generator()
        self.__og.Add_Option_Screen_Options()

        inner_t = gui.Table(align=0)
        inner_t.tr()
        inner_t.td(gui.Spacer(width=m2, height=1))
        inner_t.td(self.__og.Get_Table())
        inner_c = gui.ScrollArea(inner_t, w - ( m2 * 2 ), 
                    h / 2, False)

        buttons_t = gui.Table(align=1,valign=0)
        support.Buttons2Table(buttons_t, 
                [ ('Ok', self.Press_Ok),
                    ('Choose tile mod', self.Press_CTM),
                    ('Test video', self.Press_Test),
                    ('Cancel', self.Press_Cancel) ])

        middle_t = gui.Table(align=0, valign=0,
                        background=library.colours.sel_screen_bg)
        middle_t.tr()
        middle_t.td(gui.Spacer(width=1, height=m), colspan=3)
        middle_t.tr()
        middle_t.td(gui.Spacer(width=m, height=1))
        middle_t.td(inner_c)
        middle_t.td(gui.Spacer(width=m, height=1))
        middle_t.tr()
        middle_t.td(gui.Spacer(width=1, height=m), colspan=3)
        middle_t.tr()
        middle_t.td(buttons_t, colspan=3, align=1)
        middle_t.tr()
        middle_t.td(gui.Spacer(width=1, height=m), colspan=3)

        options_c = gui.Container(align=0, valign=0, 
                        width=w - m2, height=h - m2 )
        options_t = gui.Table(align=0, valign=0)
        options_t.tr()
        options_t.td(gui.Label("Options", cls="h1", color=
                    library.colours.title_colour, align=0))
        options_t.tr()
        options_t.td(middle_t)
        options_c.add(options_t, m, m)

        return options_c 

    SEL_MODE_TEST = 9
    SEL_CTM = 10

    def Press_Ok(self, *args):
        dlg = self.__og.Press_Apply()
        if ( dlg == None ):
            self.Set_Return_Code(self.SEL_OK)

    def Press_Cancel(self, *args):
        self.Set_Return_Code(self.SEL_QUIT)

    def Press_Test(self, *args):
        self.Set_Return_Code(self.SEL_MODE_TEST)

    def Get_Mode_To_Test(self):
        return self.__og.Get_Mode_To_Test()

    def Press_CTM(self, *args):
        self.Set_Return_Code(self.SEL_CTM)

        



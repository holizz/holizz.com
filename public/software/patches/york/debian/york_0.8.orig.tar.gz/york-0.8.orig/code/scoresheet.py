#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: scoresheet.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# Scoresheet building code.
# 


import pygame, sys
from pygame.locals import *
import library, extra, resources








def Get_All_Records(player_objects):
    # Merge and sort all player records
    all_records = []
    for p in player_objects:
        all_records.extend(p.record)

    def Record_Sorter(r1, r2):
        x = cmp(r1.turn_number, r2.turn_number)
        if ( x != 0 ):
            return x
        x = cmp(r1.record_number, r2.record_number)
        if ( x != 0 ):
            return x
        return cmp(r1.player_number, r2.player_number)

    all_records.sort(cmp=Record_Sorter)

    return all_records


def Invent_Scores(rules):
    import random
    all_records = []
    for i in xrange(1000):
        class R:
            pass
        r = R()
        r.player_number = random.randint(0, rules.Get_Max_Players() - 1)
        r.acc_score = random.randint(0, 30)
        r.score = random.randint(0, 20)
        r.turn_number = i + random.randint(0, 4)
        r.text = 'not a real score %u' % i
        all_records.append(r)

    return all_records

def Draw_All_Records(rules, player_objects, player_names, (width, min_height)):
    all_records = Get_All_Records(player_objects)

    if ( '--descore' in sys.argv ):
        print 'Draw_All_Records inventing scores...'
        all_records = Invent_Scores(rules)

    SUMMARY_HEIGHT = 100
    MARGIN = 20
    ROW_HEIGHT = 30
    height = (( len(all_records) + 2 ) * ROW_HEIGHT ) + SUMMARY_HEIGHT
    height = max(height, min_height)

    surf = pygame.Surface((width, height))
    surf.set_colorkey(None)
    surf.fill(library.colours.score_sheet_bg)

    col_data = []
    x1 = x2 = MARGIN

    for i in xrange(rules.Get_Max_Players()):
        if (( player_names[ i ] != None )
        and ( len(player_names[ i ]) != 0 )):
            x2 = x1 + (( width / 2 ) / rules.Get_Max_Players() )
            r = Rect(x1, 0, x2 - x1, ROW_HEIGHT)
            x1 = x2
            col_data.append((i, r))

    col_data.append((rules.Get_Max_Players(),
        Rect(x1, 0, ( width - MARGIN ) - x1, ROW_HEIGHT)))
    score = [ "" for i in xrange(rules.Get_Max_Players()) ]
    num_players = rules.Get_Max_Players()
    meeple_images = extra.Make_Meeple_Images(( ROW_HEIGHT * 3 ) / 4, rules)
    font1 = resources.Get_Font(16)
    font2 = resources.Get_Font(12)

    y = MARGIN
    for i in xrange(-1, len(all_records)):
        header = ( i < 0 )

        if ( not header ):
            record = all_records[ i ]
        else:
            record = None

        for (j, r) in col_data:
            r = r.move((0, y))
            pygame.draw.rect(surf, library.colours.score_sheet_cell_bg, r, 0)
            pygame.draw.rect(surf, library.colours.score_sheet_fg, r, 1)

            text = None

            if ( j < num_players ):
                if ( header ):
                    mir = meeple_images[ j ].get_rect()
                    mir.center = r.center
                    surf.blit(meeple_images[ j ], mir.topleft)
                elif ( j == record.player_number ):
                    score[ j ] = text = str(record.acc_score)
                elif ( record.score == 0 ):
                    text = score[ j ] # summary text - all scores shown
            else:
                if ( record != None ):
                    if ( record.score == 0 ):
                        text = record.text # summary text - no name
                    else:
                        text = 'Turn %u: %s %s' % (
                            record.turn_number,
                            player_names[ record.player_number ], 
                            record.text)

            if ( text != None ):
                if ( j < num_players ):
                    fs = font1.render(text, True, 
                            library.Get_Colour_For_Player(j))
                else:
                    fs = font2.render(text, True,
                            library.colours.score_sheet_text)
                fsr = fs.get_rect()
                fsr.center = r.center
                if ( j >= num_players ):
                    fsr.left = r.left + MARGIN
                surf.blit(fs, fsr.topleft)

        y += ROW_HEIGHT

    return surf

        

#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: resources.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# Resource management module. All resources can be replaced by mods.
# 
# *** The user is warned about the following whenever a new mod is    ***
# *** opened for the first time:---                                   ***
# ***                                                                 ***
# *** Mods may include Python code which will be executed at the      ***
# *** same privilege level as York itself. To guard against malicious ***
# *** code, do not install mods from an untrusted source.             ***
# 
# I consider the benefits of permitting mods to include Python code
# greatly outweigh the potential security risks. In any case, mods
# may include pickled files, which are also a security risk, according
# to the pickle manual for Python 2.4.


import tarfile , sys , pickle
import pygame , os , traceback , md5
from pygame.locals import *

import rules , library , extra , config , default_colours , York
import whitelist

__lib_index = dict()
__img_cache = dict()
__mods = []
__current_mod_name = "ERROR"
__current_rules_factory = None
__snd_cache = dict()
__snd_disabled = False
BASE_MOD = USER_DIR = BASE_DIR = None



# Add a rules mod.
def Add_Mod(path, tiles_only=False):
    global __lib_index, __mods, BASE_MOD

    if ( tiles_only ):
        # No rules loaded, do nothing if the tiles mod is the basic mod.
        if ( path == BASE_MOD ):
            return False
    else:
        # Default rules loaded.
        __Register_Mod("Basic Game", rules.Basic_Rules)

    try:
        mod = tarfile.open(path, 'r')
    except:
        return False

    if ( not tiles_only ):
        try:
            f = mod.extractfile("rules.py")
        except:
            return False

        # Get the initialisation code.
        # If we've got this far, we assume that the mod is correctly built,
        # and contains no malicious code. You now trust the mod author.
        # The file (and MD5 sum) are added to the trust database.
        Trust_File(path)
        init_code = f.read()
        f.close()

        sub_globals = dict()
        sub_globals[ "mod" ] = mod
        sub_globals[ "rules" ] = rules
        sub_globals[ "Add_Mod" ] = Add_Mod
        sub_globals[ "Register_Mod" ] = __Register_Mod
        sub_globals[ "Set_Colours" ] = __Set_Colours
        code = compile(init_code, 'mod loader', 'exec')
        exec(code, sub_globals, dict())

    names = mod.getnames()
    for nm in names:
        if ( tiles_only ):
            if (( not nm.startswith('tile') )
            or ( nm[ -4: ].lower() == '.rtr' )):
                # tiles only mods can only contain tile pictures,
                # tile masks, and mask data (TGM).
                continue

        if ( not __lib_index.has_key( nm ) ):
            __lib_index[ nm ] = [ mod ]
        else:
            __lib_index[ nm ].insert(0, mod)

    __mods.insert(0, mod)

    return True
    
def __Set_Colours(colour_module):
    library.colours = colour_module

def __Register_Mod(name, rules_factory):
    global __current_mod_name
    global __current_rules_factory

    __current_mod_name = name
    __current_rules_factory = rules_factory
       
def Get_Rules():
    global __current_rules_factory
    rules = __current_rules_factory()

    # Return rules
    return rules
   
def Get_Font(size):
    f = pygame.font.Font(os.path.join(BASE_DIR,
                'gui', 'gray', 'Vera.ttf'), size)
    if ( f == None ):
        raise IOError()
    return f

def Get_Mod_Name():
    return __current_mod_name

def Resource_Exists(name):
    return __lib_index.has_key( name )

def Get_Resource_File(name):
    if ( not __lib_index.has_key( name ) ):
        return None

    print "Loading",name,"(%u versions)" % len(__lib_index[ name ])
    return __lib_index[ name ][ 0 ].extractfile(name)

def Get_All_Resource_Files(name):
    return [ f.extractfile(name) for f in __lib_index[ name ] ]

def Get_Override_File(name):
    print name,
    try:
        f = file(name, 'rb')
        print 'loaded from filesystem'
    except:
        try:
            f = Get_Resource_File(name)
            print 'loaded from resource file'
        except:
            f = None
            print 'not found'
    return f

def Get_Resource_Image(name, forced_size=None):
    global __img_cache

    if ( forced_size == None ):
        key = name
    else:
        key = (name, forced_size)

    if ( __img_cache.has_key(key) ):
        return __img_cache[ key ]
    
    f = Get_Resource_File(name)
    img = None
    info = ""
    if ( f != None ):
        try:
            img = pygame.image.load(f)
        except Exception, r:
            img = None
            info = ": " + str(r)
        f.close()

    if ( img == None ):
        s = "WARNING: Unable to load image '" + name + "'" + info
        print ""
        print s
        print ""
        #New_Mail(s)
        img = pygame.Surface((10,10))
        img.fill((255,0,0))

    img = img.convert_alpha()
    if ( forced_size != None ):
        img = pygame.transform.scale(img, forced_size)
    
    i = __img_cache[ key ] = img
    return i

def Depickle(fname):
    header = Get_Resource_File(fname)
    if ( header == None ):
        raise IOError()
    pdata = header.read()
    header.close()

    # You can't depickle directly from a tar file at present...
    # I don't know why.
    return pickle.loads(pdata)

def No_Sound():
    global __snd_disabled
    __snd_disabled = True

def Load_Sound(name):
    global __snd_cache, __snd_disabled
   
    if ( __snd_disabled ):
        return None

    if ( __snd_cache.has_key(name) ):
        return __snd_cache[ name ]

    fname = "sound/" + name + ".wav" # within resource file
    fh = Get_Resource_File(fname)

    if ( fh == None ):
        # Doesn't exit.
        print ""
        print "WARNING: Sound effect " + name + " does not exist."
        print ""
        __snd_cache[ name ] = None
        return None

    try:
        f = pygame.mixer.Sound(fh)
    except Exception, x:
        print ""
        print "WARNING: Error loading sound effect " + name
        print repr(x) + " " + str(x)
        print ""
        f = None
   
    __snd_cache[ name ] = f
    return f

def Initialise(override=False):
    global BASE_MOD, BASE_DIR, USER_DIR, __mods, __lib_index

    if ( BASE_DIR == None ):
        BASE_DIR = os.path.abspath(os.path.dirname(sys.argv[ 0 ]))
        USER_DIR = config.Get_User_Dir()
        BASE_MOD = os.path.join(BASE_DIR, "base.dat")

    __mods = []
    __lib_index = dict()

    c = Get_MD5(BASE_MOD)
    if (( not c in whitelist.Make_Whitelist() )
    and ( not '--detrust' in sys.argv )
    and ( not override )):
        print ""
        print "Base game resources have been modified!"
        print "Game modifications should not modify the base resource file."
        print "You will need to reinstall York."
        print ""
        sys.exit(1)
    
    if (( not Add_Mod(BASE_MOD, False) )
    and ( not override )):
        print ""
        print "Unable to load base game resources."
        print "Please ensure that you are running York from within"
        print "the game directory."
        print ""
        sys.exit(1)

def Reset():
    global __lib_index, __img_cache, __mods, __current_rules_factory
    global __snd_cache, __master_mod_list

    library.colours = default_colours
    __img_cache = dict()
    __current_rules_factory = None
    __snd_cache = dict()
    Initialise()
    __master_mod_list = __Get_Mod_List()

def Get_Mod_List():
    global __master_mod_list
    return __master_mod_list

def Get_MD5(fn):
    try:
        f = file(fn, 'rb')
        checksum = md5.new(f.read()).hexdigest()
        f.close()
    except IOError:
        checksum = ''
    return checksum

def Is_Warning_Required(fn):
    global BASE_MOD
    if ( fn == BASE_MOD ):
        return False # Always trusted

    c = Get_MD5(fn)

    if ( not config.cfg.trusted.has_key(fn) ):
        if ( c in whitelist.Make_Whitelist() ):
            # This file is on my list of approved mods
            config.cfg.trusted[ fn ] = c
            return False
        else:
            # Not yet known.
            return True
    else: 
        # Has the checksum changed?
        if ( config.cfg.trusted[ fn ] == c ):
            return False # No. Already trusted.
        else:
            return True

def Trust_File(fn):
    global BASE_MOD
    if ( fn != BASE_MOD ):
        config.cfg.trusted[ fn ] = Get_MD5(fn)

def Get_Mod_File_Name(mod_name):
    for mod_info in Get_Mod_List():
        if ( mod_info.name == mod_name ):
            return mod_info.filename
    return None

def __Get_Mod_List():
    # list of (name, desc, icon, filename)
    # name is a string
    # desc is a list of strings
    # icon is a Surface or None
    # filename has full path

    global BASE_MOD, BASE_DIR, USER_DIR

    # Get file list
    file_list = []
    for dir in [ BASE_DIR, USER_DIR ]:
        print 'dir', dir
        file_list += [ os.path.abspath(os.path.join(dir, fn))
            for fn in os.listdir(dir) 
            if (( len(fn) > 4 ) and ( fn[ -4: ].lower() == ".dat" )) ]

    class Mod_Record:
        pass

    base_record = Mod_Record()
    base_record.name = "Basic Game"
    base_record.desc = [
        "The original York game, with rules inspired by Carcassonne."]
    base_record.icon_surf = Get_Resource_Image("icon.png")
    base_record.filename = BASE_MOD
    base_record.is_rules_mod = True
    base_record.is_omnipresent = True

    print 'file list:',file_list
        

    # Inspect it, turning each entry into a mod description.
    # Note: No code is executed in the mod during this process!
    # The user will be warned before mod code is executed.
    mod_list = []
    for fn in file_list:
        if ( fn == BASE_MOD ):
            continue

        mr = Mod_Record()
        mr.filename = fn
        mr.is_omnipresent = False

        # ***
        # Part 1 - Get mod information - info.txt
        try:
            mod = tarfile.open(fn, 'r')
            info_file = mod.extractfile("info.txt")
        except Exception, e:
            info_file = None
            print 'Exception while inspecting',fn,':'
            traceback.print_exc(file=sys.stdout)

        if ( info_file == None ):
            continue

        count = 0
        mr.name = extra.Filter_Message(info_file.readline().strip())
        if ( len(mr.name) < 4 ):
            info_file.close()
            continue
        if ( mr.name.lower() == base_record.name[ 0 ].lower() ):
            # Skullduggery! You can't call your game 'Basic Game'.
            info_file.close()
            continue
        mr.desc = []

        try:
            for i in xrange(5):
                rl = info_file.readline().strip()
                mr.desc.append(extra.Filter_Message(rl))
        except EOFError, e:
            pass
        info_file.close()

        # ***
        # Part 2 - Is this a Rules mod?
        # Mods without a rules.py file are tileset-only mods.

        try:
            rules_file = mod.extractfile("rules.py")
            rules_file.close()
            mr.is_rules_mod = True
        except Exception, e:
            mr.is_rules_mod = False
            
        
        # ***
        # Part 3 - Get mod icon image (if any)

        try:
            icon_file = mod.extractfile("icon.png")
            mr.icon_surf = pygame.image.load(icon_file).convert()
        
        except Exception, e:
            print 'Icon access exception:'
            traceback.print_exc(file=sys.stdout)
            mr.icon_surf = None

        if (( mr.icon_surf != None )
        and ( mr.icon_surf.get_rect().size != library.MOD_ICON_SIZE )):
            mr.icon_surf = pygame.transform.scale(mr.icon_surf, 
                                        library.MOD_ICON_SIZE)

        mod_list.append(mr)
        

    def Compare(a, b):
        x = cmp(a.name, b.name)
        if ( x == 0 ):
            x = cmp(a.filename, b.filename)
        return x
    
    mod_list.sort(cmp=Compare)
    mod_list.insert(0, base_record) # always at the top

    return mod_list







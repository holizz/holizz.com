
                                      York

                                alpha prerelease!

         For source code and updates see http://www.jwhitham.org.uk/york/


Credits:
    I would like to thank all of the people who have been waiting a long
    time for this release of York. Thankyou for your patience and support.

Todo before release:
    Heaps. See game_screen.py in source release.

License:

    York, a computer game
    Copyright (C) 2006 Jack Whitham

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License version 2,
    as published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, 
    Boston, MA  02110-1301  USA




#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# 
#


from default_setup import *

def River(a,b,c):
    return [('F',a),('V',b),('F',c)]

# 10 different types of river tile.

Declare_Tile('river.start',
            [Field(0), River(0, 1, 0), Field(0), Field(0)],
            ['r'], None,
            [("riverstart", 0)])
Declare_Tile('river.end',
            [Field(0), River(0, 1, 0), Field(0), Field(0)],
            ['r'], None,
            [("riverend", 0)])
Declare_Tile('river.straight',
            [Field(0), River(0, 1, 2), Field(2), River(2, 1, 0)],
            ['r'], None,
            [("hfield", 0), ("river", 0)])
Declare_Tile('river.curve',
            [Field(0), Field(0), River(0, 1, 2), River(2, 1, 0)],
            ['r'], None,
            [("cfield", 0), ("rivercurve", 0)])
Declare_Tile('river.road.curve',
            [Road(0, 1, 2), Road(2, 1, 0), River(0, 3, 4), River(4, 3, 0)],
            ['r'], None,
            [("cfield", 0), ("cfield", 2), 
                ("rivercurve", 0), ("roadcurve", 2)])
Declare_Tile('river.city.road',
            [City(0), River(1, 2, 3), Road(3, 4, 5), River(5, 2, 6)],
            ['r'], None,
            [("qfield", 0), ("qfield", 1), ("qfield", 2), ("qfield", 3),
            ("river", 0), ("road", 1), ("city1", 0)])
Declare_Tile('river.road.straight',
            [Road(0, 1, 2), River(2, 3, 4), Road(4, 1, 5), River(5, 3, 0)],
            ['r'], None,
            [("qfield", 0), ("qfield", 1), ("qfield", 2), ("qfield", 3),
            ("river", 0), ("road", 1)])
Declare_Tile('river.city.curve',
            [City(0), City(0), River(1, 2, 3), River(3, 2, 1)],
            ['r'], None,
            [("cfield", 0), ("rivercurve", 0), ("city2b", 0)])
Declare_Tile('river.2cities',
            [City(0), River(1, 2, 3), City(4), River(3, 2, 1)],
            ['r'], None,
            [("hfield", 0), ("river", 0), ("city1", 0), ("city1", 2)])
Declare_Tile('river.monastery',
            [Field(0), River(0, 1, 2), Road(2, 3, 4), River(4, 1, 0)],
            ['r', 'm'], [Monastery(5, [0, 1, 3])],
            [("hfield", 0), ("qfield", 3), ("riverbow", 0),
            ("roadend", 3), ("monastery", 0)])



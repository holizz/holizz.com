#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: constants.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# 
# Do not import anything, or try to execute any code.
#

BASIC_TILE_SIZE = 128
TILE_STATS_WIDTH = 2
SMALL_TILE_SIZE = 24
MAX_PLAYER_NAME_LENGTH = 16
MENU_ICON_SIZE = 64
MENU_ICON_SIZE_B = 32
MENU_RESOLUTION = (800, 600)
MOD_ICON_SIZE = (32, 32)
DEFAULT_PORT = 26000
RAW_CHECKPOINT_MESSAGE = "york checkpoint"
DEMO_RECORDING_BEGINS = "york demo start recording"
RAW_GAME_READY_MESSAGE = "york game ready"
RAW_PROGRESS_MESSAGE = "york please wait"
PROGRESS_BASE = 4096
CHAT_BOX_SIZE = 30
MESSAGE_WINDOW_HEIGHT = 117
EDGE_BEVEL_EFFECT_MARGIN = -4
SIDEBAR_MARGIN = 10
COMPILED = "tilebins"
TGM_VERSION = 2
RTR_VERSION = 1



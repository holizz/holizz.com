#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: magcursor.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# Makes mouse cursor masks from PNG file

import pygame , pickle
from pygame.locals import *


pygame.init()

mask = pygame.image.load("magcursormask.png")
bits = pygame.image.load("magcursor.png")

(w, h) = mask.get_rect().size

mlist = []
blist = []
scan = 128
mout = bout = 0

for y in xrange(h):
    for x in xrange(w):
        m = mask.get_at((x,y))
        b = bits.get_at((x,y))
        if ( m[ 0 ] < 128 ):
            out = 0
        elif ( b[ 0 ] > 128 ):
            out = 1
        else:
            out = 2


        if ( out >= 1 ):
            # Mask on.
            mout |= scan
        if ( out >= 2 ):
            # Bits on.
            bout |= scan

        scan = scan >> 1

        if ( scan == 0 ):
            mlist.append(mout)
            blist.append(bout)
            mout = bout = 0
            scan = 128

for (name, data) in [ ("bits", blist), ("mask", mlist) ]:
    x = 0
    y = 0
    o = ""
    for item in data:
        for i in xrange(8):
            j = ( item >> ( 7 - i )) & 1
            o += "%d" % j
        x += 8 
        if ( x >= w ):
            print "%3d %s" % (y,o)
            o = ""
            x = 0
            y += 1

set_cursor_tuple = ((w, h), (18, 12), blist, mlist)
print "size:",(w,h)
print len(blist),"bytes in mask"

pickle.dump(set_cursor_tuple, file("magcursor.dat", "wb"))



#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: tile_instance.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# There is one Tile_Instance per tile in the stack or in play.
# 

import tile_graphics , tile , library 


class Tile_Instance:
    "Holds almost all state data related to a tile."
    def __init__(self,tile,rules):
        self._tile = tile 
        self._region_number_offset = 0
        self._r = 0
        self._name = tile.Get_Name()
        self._has_meeple = None
        self._ghost_meeple = None
    
    def Get_Name(self):
        return self._tile.Get_Name()

    def Get_Drawing_Info(self,include_meeple=True,use_ghost=False):
        if ( not include_meeple ):
            return ((self.Get_Name(),self.Get_Rotation()),None)
        if ( not use_ghost ):
            return ((self.Get_Name(),self.Get_Rotation()),self._has_meeple)
        return ((self.Get_Name(),self.Get_Rotation()),self._ghost_meeple)

    def Get_Meeple(self):
        return self._has_meeple

    def Get_Ghost_Meeple(self):
        # When a meeple is removed from the tile, it leaves a ghost behind.
        # The ghost appears at the end of the game for scoring purposes.
        return self._ghost_meeple

    def Get_Flags(self):
        return self._tile.Get_Flags()

    def Rotate(self,n = 1):
        # Rotates clockwise n times
        self._r = ( self._r + n ) % 4
        assert 0 <= self._r < 4

    def Get_Rotation(self):
        return self._r

    def Get_Rotational_Symmetry(self):
        return self._tile.Get_Rotational_Symmetry()

    def Set_Region_Offset(self,n):
        self._region_number_offset = n

    def Is_Region_On_This_Tile(self,r):
        r -= self._region_number_offset
        return ( 0 <= r < self.Get_Number_Of_Regions() )

    def Get_Number_Of_Regions(self):
        return self._tile.Get_Number_Of_Regions()

    def Get_Additional_Region_Info(self):
        return [ (type,number + self._region_number_offset) 
                    for (type,number,adj_list) in self._tile.Get_Additional_Region_Info() ]

    def Get_Edge_Regions(self,e):
        return [ ( x + self._region_number_offset ) for x in self._tile.Get_Edge_Regions(( e + 4 - self._r) % 4) ]

    def Get_Edge(self,e):
        return self._tile.Get_Edge((e + 4 - self._r) % 4) 

    def Get_All_Edges(self,rotation=0):
        s = ""
        for i in range(4,8):
            s = s + self._tile.Get_Edge((rotation + i - self._r) % 4 )
        return s

    def Calculate_Region_For_Position(self,graphics_tile,(mx,my)):
        return self._tile.Calculate_Region_For_Position(
                        graphics_tile,(mx,my),self._r) 

    def Translate_To_Graphics_Region(self,graphics_tile,region):
        r2 = region - self._region_number_offset
        return self._tile.Translate_To_Graphics_Region(graphics_tile,r2)

    def Get_Centre_Of_Region(self,graphics_tile,region):
        return self._tile.Get_Centre_Of_Region(graphics_tile,region - self._region_number_offset,self._r)

    def Get_Type_Of_Region(self,region):
        return self._tile.Get_Type_Of_Region(region - self._region_number_offset)

    def Get_Region_Adjacencies(self,region_number):
        return [ ( x + self._region_number_offset ) for x in 
                self._tile.Get_Region_Adjacencies(region_number - self._region_number_offset) ]

    def Remove_Meeple(self):
        assert ( self._has_meeple != None )
        self._ghost_meeple = self._has_meeple.Make_Ghost()
        self._has_meeple.Remove()
        self._has_meeple = None

    def Place_Meeple(self,graphics_tile,region,meeple):
        assert ( self._has_meeple == None )
        assert ( not meeple.Is_Placed() )

        (mx,my) = self.Get_Centre_Of_Region(graphics_tile,region)
        assert ( mx >= 0 )  # must be valid region
        meeple.Place(self,(mx,my),region)
        self._has_meeple = meeple
        
    def Convert_Subregion(self, graphics_tile, region):
        if ( 0 <= region < self.Get_Number_Of_Regions() ):
            return region + self._region_number_offset 
        else:
            return -1

    def __cmp__(self, other):
        if ( other == None ):
            return 1

        # Compare by name first, and if the names are the same,
        # do the usual comparison (object identity).
        x = cmp(self.Get_Name(), other.Get_Name())
        if ( x == 0 ):
            x = cmp(id(self), id(other))
        return x




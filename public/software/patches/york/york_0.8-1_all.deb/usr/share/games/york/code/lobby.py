#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: lobby.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 


# The low-level Lobby management code.
# The Lobby is used to set up a network game. It allows the players to assemble,
# choose their colours and settings, and then ready up and commit to the game.
#
#

import collections
import message_queue, library, extra, thread_mgr, demo_mq, constants

S2C_LOBBY_TEXT = "LOBBY_TEXT"
S2C_LOBBY_SLOT = "LOBBY_SLOT"
S2C_LOBBY_START = "LOBBY_START"
S2C_LOBBY_ASSIGN = "LOBBY_ASSIGN"
S2C_LOBBY_KICK = "YOU SUCK"
S2C_LOBBY_SUBGAME = "LOBBY_SUBGAME_IS"
C2S_LOBBY_QUIT = "LOBBY_QUIT"
C2S_LOBBY_SEL_COLOUR = "LOBBY_SC"
C2S_LOBBY_CHAT = "LOBBY_CHAT "
C2S_LOBBY_READY = "LOBBY_READY"
PS_MSG_SEPARATOR = "/ /"


class Lobby:
    def __init__(self, rules, client_mq, server_mq):

        # Setup
        self.__message_list = collections.deque()
        self.__is_server = ( server_mq != None )
        self.__start_flag = False
        self.__rules = rules
        self.__my_slot_is = None
        self.__kicked_flag = False
        self.__subgame = 0
        self.__resume_mode = False

        class Player_Slot:
            def __init__(self, i):
                self.number = i
                self.id = 0 
                self.name = ""
                self.occupied = False
                self.ready = False
                self.colours = []
                self.dirty = True
                self.resume_original_id = -1

            def To_Msg(self):
                self.colours.sort()
                return PS_MSG_SEPARATOR.join([ self.name, "%d" % self.id,
                        "%d" % self.resume_original_id,
                        "%d" % self.occupied, "%d" % self.ready, ] + 
                        [ str(i) for i in self.colours ])
            
            def From_Msg(self, msg):
                fields = msg.split(PS_MSG_SEPARATOR)
                if (( len(fields) < 3 ) 
                or ( len(fields) > ( rules.Get_Max_Players() + 4 ))):
                    return False
                for i in xrange(1, len(fields)):
                    try:
                        fields[ i ] = int(fields[ i ])
                    except:
                        return False

                def R(orig_data, new_data):
                    if ( orig_data != new_data ):
                        self.dirty = True
                    return new_data

                self.name = R(self.name, 
                        library.Launder_Player_Name(fields[ 0 ]))
                self.id = R(self.id, fields[ 1 ])
                self.resume_original_id = R(self.id, fields[ 2 ])
                self.occupied = R(self.occupied, fields[ 3 ])
                self.ready = R(self.ready, fields[ 4 ])

                new_colours = fields[ 5: ]
                if ( self.colours != new_colours ):
                    self.dirty = True
                    self.colours = new_colours

                return True

        self.__slots = [ Player_Slot(i)
                for i in xrange(rules.Get_Max_Observers()) ]
        self.__colours = [ None
                for i in xrange(rules.Get_Max_Players()) ]
       
        # Validate input message queues
        assert not client_mq.Is_Server()
        if ( self.__is_server ):
            assert server_mq.Is_Server()
            self.__client_mq = client_mq
            self.__main_mq = server_mq
            assert server_mq.Is_Ok()
        else:
            self.__client_mq = client_mq
            self.__main_mq = client_mq

        self.__server_id = None

        # Must be connected before the lobby starts
        assert client_mq.Is_Ok()

    def Get_Client_MQ(self):
        return self.__client_mq

    def Get_Server_MQ(self):
        if ( self.__is_server ):
            return self.__main_mq
        else:
            return None

    def Play_Lobby_Demo(self, stream, resume_mode):
        # Demos begin in the lobby - this allows them to collect the
        # game settings and may also be useful for fixing lobby bugs.
        self.__resume_mode = False

        while True:
            # Wind forward to next checkpoint:
            if ( self.Get_Client_MQ().Demo_Play_Event(stream, None, 
                            demo_mq.DEMO_PLAY_MODE_LOBBY_REPLAY) ):
                return False # demo ends

            # demo data received in this loop.
            m = self.Get_Client_MQ().Wait_And_Receive()
            if ( m == None ):
                return False # broken demo

            (msg, sender_id) = m

            while ( msg != constants.RAW_CHECKPOINT_MESSAGE ):
                self.__server_id = None
                self.Do_Client_Message_Handling(msg, sender_id) 

                if ( self.Client_Starting() ):
                    if ( resume_mode ):
                        # Allow the new players to take their seats -
                        # act as lobby server.
                        self.__start_flag = False
                        for s in self.__slots:
                            if (( s.occupied )
                            and ( len(s.colours) > 0 )):
                                s.resume_original_id = s.id
                            s.ready = False
                            s.occupied = False

                        self.__resume_mode = True
                    return True
                    
                m = self.Get_Client_MQ().Wait_And_Receive()
                if ( m == None ):
                    return False # broken demo
                (msg, sender_id) = m

    def Tick(self):
        # This function should be called repeatedly. It makes
        # the lobby handle messages and other events.
        update = False
        if ( self.__is_server ):
            update = self.Do_Players_Entering_And_Leaving() or update

        m = self.__main_mq.Receive()
        while ( m != None ):
            (msg, sender_id) = m
            if ( self.__is_server ):
                update = ( self.Do_Server_Message_Handling(msg, sender_id) 
                        or update )
            update = self.Do_Client_Message_Handling(msg, sender_id) or update

            m = self.__main_mq.Receive()

        return update

    def Client_Select_Colour(self, colour_number):
        self.__client_mq.Send("%s%d" % (C2S_LOBBY_SEL_COLOUR, colour_number))

    def Client_Set_Ready(self, ready):
        self.__client_mq.Send("%s%d" % (C2S_LOBBY_READY, ready))

    def Client_Chat(self, msg):
        self.__client_mq.Send(C2S_LOBBY_CHAT + msg)

    def Client_Quit(self):
        self.__client_mq.Send(C2S_LOBBY_QUIT)

    def Do_Players_Entering_And_Leaving(self):
        ids_present = set(self.__main_mq.Get_ID_List())
        unoccupied_slots = collections.deque()
        broadcast_update = False
        update = False
        for slot in self.__slots:
            if ( not slot.occupied ):
                unoccupied_slots.append(slot)
            elif ( not ( slot.id in ids_present )):
                # player left
                self.Server_Text_Msg("Player '%s' has left." % slot.name)
                self.Server_Slot_Update(slot)
                if ( not self.__resume_mode ):
                    # colours deallocated
                    for i in slot.colours:
                        self.__colours[ i ] = None
                    slot.colours = []
                slot.occupied = False
                slot.dirty = True
                update = True
            else:
                ids_present -= set([slot.id])

        for id in ids_present:
            new_name = self.__main_mq.Get_Name(id)
            slot = None
            if ( new_name == None ):
                self.Kick_ID(id, "Kicking invalid new player %u." % id)
            elif ( len(unoccupied_slots) != 0 ):
                if ( not self.__resume_mode ):
                    # Player goes into the next available slot.
                    slot = unoccupied_slots.popleft()
                    self.Server_Text_Msg("Player '%s' joins the game." % 
                                                            new_name)
                else:
                    # Player goes into the slot with a matching name
                    # (if any), or becomes an observer.
                    slot = None
                    for possible_slot in unoccupied_slots:
                        if (( possible_slot.resume_original_id > 0 )
                        and ( possible_slot.name == new_name )):
                            slot = possible_slot
                            self.Server_Text_Msg(
                                "Player '%s' rejoins the game." % new_name)
                            break
            
                    if ( slot == None ):
                        # pick observer slot
                        for possible_slot in unoccupied_slots:
                            if ( possible_slot.resume_original_id <= 0 ):
                                slot = possible_slot
                                self.Server_Text_Msg(
                                    "Observer '%s' joins the game." % new_name)
                                break

                    
            if ( slot == None ):
                self.Kick_ID(id,
                    "There is no space for new player '%s'." % new_name)
            else:
                slot.name = new_name
                slot.id = id
                slot.occupied = True
                slot.dirty = True
                update = broadcast_update = True
                self.__main_mq.Send("%s%u %s" % (S2C_LOBBY_ASSIGN, 
                            slot.number, new_name))

                if ( id == self.Get_ID() ):
                    self.__my_slot_is = slot.number

        if ( broadcast_update ):
            self.Do_Broadcast()
        return update

        
    def Kick_ID(self, id, text=None):
        slot = self.Get_Slot_For_Id(id)
        if ( text == None ):
            if ( slot == None ):
                text = "Kicking unknown player with id %u." % id
            else:
                text = "Host kicks player '%s'." % slot.name

        if ( slot != None ):
            slot.dirty = True

        if ( len(text) > 0 ):
            self.__main_mq.Send_To_Only(S2C_LOBBY_KICK, [ id ])
            self.Server_Text_Msg(text)
            # otherwise silent kick - used for quitters

        self.__main_mq.Kick_ID(id)

    def Send_Message(self,t):
        self.__message_list.append(t)

    def Get_Message(self):
        if ( len(self.__message_list) == 0 ):
            return None
        else:
            return self.__message_list.popleft()

    def Server_Text_Msg(self,t):
        self.__main_mq.Send(S2C_LOBBY_TEXT + t)
        self.Send_Message(t)
    
    def Server_Slot_Update(self, slot):
        self.__main_mq.Send(S2C_LOBBY_SLOT + str(slot.number) + 
                    " " + slot.To_Msg())
    
    def Get_Slot_For_Id(self, id):
        for slot in self.__slots:
            if (( slot.id == id ) and slot.occupied ):
                return slot
        return None

    def Server_Start_Game(self):
        absent_players = unready_players = players = 0
        for slot in self.__slots:
            if ( len(slot.colours) != 0 ):
                if ( slot.occupied ):
                    players += 1
                    if ( not slot.ready ):
                        unready_players += 1
                elif ( slot.resume_original_id > 0 ):
                    players += 1
                    unready_players += 1
                    absent_players += 1

        if ( players == 0 ):
            self.Send_Message("Can't start - no players!")
            return
        if ( absent_players > 0 ):
            self.Server_Text_Msg("The game cannot start until all the " +
                    "players have returned.")
            return
        if ( unready_players > 0 ):
            self.Server_Text_Msg("Host is waiting to start - " +
                    "please ready up!")
            return

        self.Force_Server_Start_Game()

    def Force_Server_Start_Game(self):
        # This should only be called from Server_Start_Game()
        # and from test programs.
        print 'Game launching....'
        self.__main_mq.Allow_New_Players(False)
        self.Server_Text_Msg("Game launching.")
        self.__main_mq.Send(constants.DEMO_RECORDING_BEGINS)
        self.Do_Broadcast()
        self.__main_mq.Send(S2C_LOBBY_START)
        self.__main_mq.Send(constants.RAW_CHECKPOINT_MESSAGE)
        self.__start_flag = True

    def Test_Mode_Start_Game(self, id):
        for slot in self.__slots:
            if ( slot.resume_original_id > 0 ):
                slot.ready = True
                slot.occupied = True
                slot.id = id

        self.Force_Server_Start_Game()
        

    def Client_Starting(self):
        return self.__start_flag

    def Client_Kicked(self):
        return self.__kicked_flag

    def Do_Server_Message_Handling(self, msg, sender_id):
        colour_req = colour_drop = False

        # Which player sent this?
        slot = self.Get_Slot_For_Id(sender_id)
        if (( slot == None ) or not slot.occupied ):
            return False
   
        # Switch..
        if ( msg.startswith(C2S_LOBBY_READY) ):
            old = slot.ready
            slot.ready = ( msg[len(C2S_LOBBY_READY)] == '1' )
            self.Server_Slot_Update(slot)
            slot.dirty = True
            return ( old != slot.ready )

        if ( msg.startswith(C2S_LOBBY_CHAT) ):
            t = msg[len(C2S_LOBBY_CHAT):]
            self.Server_Text_Msg(slot.name + ": " + t)
            return False # only a message, not a table update

        if ( msg.startswith(C2S_LOBBY_QUIT) ):
            self.Kick_ID(sender_id, "") # silent kick
            return False

        if ( msg.startswith(C2S_LOBBY_SEL_COLOUR) ):
            if ( self.__resume_mode ):
                return False

            try:
                colour_number = int(msg[ len(C2S_LOBBY_SEL_COLOUR): ])
            except:
                return False

            if ( not ( 0 <= colour_number < self.__rules.Get_Max_Players() )):
                return False

            if ( self.__colours[ colour_number ] == None ):
                # Allocate
                self.__colours[ colour_number ] = slot
                slot.colours.append(colour_number)
            elif ( self.__colours[ colour_number ] == slot ):
                # Deallocate
                self.__colours[ colour_number ] = None
                slot.colours = [ c for c in slot.colours
                                    if ( c != colour_number ) ]
            else:
                # Not allocated to you.
                return False

            slot.dirty = True
            self.Server_Slot_Update(slot)
            return True

        return False

    def Do_Broadcast(self):
        for slot in self.__slots:
            self.Server_Slot_Update(slot)
        self.Set_Subgame(self.__subgame)
        
    def Do_Client_Message_Handling(self, msg, sender_id):

        if ( self.__server_id == None ):
            self.__server_id = sender_id
        else:
            if ( self.__server_id != sender_id ):
                return False

        if ( msg.startswith(S2C_LOBBY_TEXT) ):
            t = msg[len(S2C_LOBBY_TEXT):]
            self.Send_Message(t)
            return False
        if ( msg.startswith(S2C_LOBBY_START) ):
            self.__start_flag = True
            return False
        if ( msg.startswith(S2C_LOBBY_SUBGAME) ):
            try:
                n = int(msg[ len(S2C_LOBBY_SUBGAME): ])
            except:
                return False
            self.__subgame = n
            return True
        if ( msg.startswith(S2C_LOBBY_KICK) ):
            self.__kicked_flag = True
            return False
        if ( msg.startswith(S2C_LOBBY_ASSIGN) ):
            l = msg[len(S2C_LOBBY_ASSIGN):].split(' ', 1)
            if ( len(l) != 2 ):
                return False
            try:
                n = int(l[ 0 ])
            except:
                return False
            if ( not ( 0 <= n < len(self.__slots) )):
                return False
            self.__my_slot_is = n
            return True

        if ( msg.startswith(S2C_LOBBY_SLOT) ):
            l = msg[len(S2C_LOBBY_SLOT):].split(' ', 1)
            if ( len(l) != 2 ):
                return False
            try:
                n = int(l[ 0 ])
            except:
                return False
            if ( not ( 0 <= n < len(self.__slots) )):
                return False
            update = self.__slots[ n ].From_Msg(l[ 1 ])
            self.Update_Colours()
            return update
        return False

    def Update_Colours(self):
        self.__colours = [ None 
                    for i in xrange(self.__rules.Get_Max_Players()) ]

        for slot in self.__slots:
            for colour in slot.colours:
                assert 0 <= colour < self.__rules.Get_Max_Players()
                self.__colours[ colour ] = slot

    def Get_Game_Information(self):

        # For game_logic_driver: a Game_Information_Record is
        # passed from the lobby to the game.
        class Game_Information_Record:
            pass

        gi = Game_Information_Record()
        gi.player_names = []
        gi.player_is_ai = []
        gi.player_ids = []
        gi.subgame = self.__subgame
        gi.id_to_col_and_name = dict()

        # Do observers:
        for slot in self.__slots:
            if ( slot != None ):
                gi.id_to_col_and_name[ slot.id ] = (slot.name,
                        library.colours.observer_colour)

        # Do players:
        assert self.__start_flag
        for (i, slot) in enumerate(self.__colours):
            if ( slot == None ):
                # Empty slot
                gi.player_ids.append(None)
                gi.player_names.append(None)
            else:
                assert len(slot.colours) > 0

                if (( len(slot.colours) > 1 )
                and ( i != slot.colours[ 0 ] )):
                    name_suffix = "_%u" % i
                else:
                    name_suffix = ""
                gi.player_ids.append(slot.id)
                gi.player_names.append(slot.name + name_suffix)
                gi.id_to_col_and_name[ slot.id ] = (slot.name,
                        library.Get_Colour_For_Player(i, True))

            gi.player_is_ai.append(False)

        return gi

    def Get_Available_Colours(self):
        return [ ( c == None ) for c in self.__colours ]

    def Get_Slots(self):
        # Used by GUI
        return self.__slots

    def Get_ID(self):
        return self.__client_mq.Get_ID()

    def Is_Server(self):
        return self.__is_server

    def Is_Ok(self):
        return self.__client_mq.Is_Ok() and self.__main_mq.Is_Ok()

    def Get_My_Slot(self):
        if ( self.__my_slot_is == None ):
            return None
        else:
            return self.__slots[ self.__my_slot_is ]

    def Server_Quit(self):
        for slot in self.__slots:
            if ( slot.occupied ):
                self.Kick_ID(slot.id, "Server quit")

    def Get_Subgame(self):
        return self.__subgame

    def Set_Subgame(self, select_num):
        if ( not self.__resume_mode ):
            for (num, name) in self.__rules.Get_Subgame_List():
                if ( select_num == num ):
                    ok = True
                    break
            assert ok
            if ( select_num != self.__subgame ):
                self.Server_Text_Msg("Game type changed to %s." % name)
            self.__subgame = select_num
        self.__main_mq.Send("%s%d" % (S2C_LOBBY_SUBGAME, self.__subgame))

    def Is_Resume(self):
        return self.__resume_mode

        


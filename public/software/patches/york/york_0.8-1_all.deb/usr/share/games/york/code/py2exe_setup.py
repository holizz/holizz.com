#!/usr/bin/env python
#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: py2exe_setup.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 

def Make_EXE():
    from distutils.core import setup

    import sys, os

    sys.path.insert(0, '..')

    import py2exe, glob, York

    York.Paths(os.path.join(os.getcwd(), '..'))

    if ( len(sys.argv) < 2 ):
        sys.argv.append("py2exe")
        sys.argv.append("-b")
        sys.argv.append("1")

    # windows or console
    setup(windows=[{"script": "../York.py",
            "icon_resources": [(1,"..\\resource_builder\\ui\\icon.ico")]}],
            #options={"py2exe":{"compressed": 1, "optimize": 2}},
            console=[{"script": "../Tile_Tool.py"}],
            zipfile="York.bin",
            data_files=[])
                #("code\\theme", glob.glob("..\\code\\theme\\*.*")),
                #("data\\audio", glob.glob("..\\data\\audio\\*.*"))])


if ( __name__ == "__main__" ):
    Make_EXE()


#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: tile_graphics.py,v 1.2 2006/08/09 20:34:43 jack Exp jack $
#
# Tile drawing code - separated from tile logic. 
#

import pygame , pickle , os
import library , tile_graphics_masks , tile , resources


# Constructor may raise TGM_Exception on load error.
from tile_graphics_masks import TGM_Exception

        
class Tile_Graphics:
    "Handles the rendering of one sort of tile."
    def __init__(self, name, rules, enable_compiler=False):
        self.__name = name
        self.__rules = rules
        self.__tile_db = self.__rules.Get_Tile_DB()
        imgname = self.__tile_db.Get_Image_Filename(self.__name)

        self.__gm = rules.Get_Graphics_Module()

        # Read image..
        self.__orig_img = resources.Get_Resource_Image(imgname).convert()
        self.__gm.Preprocess_Tile(self.__orig_img, name, rules)

        # Highlighting controls:
        self.__highlight_margin = [180,255,60]
        self.__masks = None

        # Other setup:
        self.__Load_Masks(self.__name, enable_compiler)
        self.__sz = 0
        self.__store_empty = False
        self.Flush()
        self.Scale(library.BASIC_TILE_SIZE)


    def Draw_One(self, view, rectangle, rotation):
        # 'One-off' drawing procedure that works at any scale you want.
        view.blit(pygame.transform.scale(self.__Make(rotation, -1, False), 
                rectangle.size), rectangle.topleft)


    def Ready(self):
        self.__Make(0, -1, True)


    def Scale(self,sz):
        if ( self.__sz != sz ):
            self.__sz = sz
            self.Flush()

    def Flush(self):
        if ( not self.__store_empty ):
            self.__store = dict()
            self.__store_empty = True

    def Get_Status(self):
        
        out = [ "tile %s, %u regions, memory map:\n" % (self.__name, 
                            self.__masks.Get_Num_Regions()) ]
        count = 0
        for g_region in xrange(-1, self.__masks.Get_Num_Regions()):
            for rotation in xrange(4):
                key = (rotation, g_region)
                yes = self.__store.has_key(key)
                out.append('%u' % int(yes))
                if ( yes ):
                    count += 1

            out.append(', ')

        out.append('  total %u\n' % count)
        return ''.join(out)

    def Draw(self,view,sx,sy,r):
        return self.Draw_Region(view,sx,sy,r,-1,(0,0,0),0)

    def Get_Size(self):
        return self.__sz

    def Draw_Region(self,view,sx,sy,rotation,
                    graphics_region,highlight_colour,highlight_alpha):

        assert 0 <= rotation < 4
        assert -1 <= graphics_region < self.__masks.Get_Num_Regions()
        assert self.__masks != None
        
        surf = self.__Make(rotation, graphics_region, True)

        # Manage region highlighting
        if (( graphics_region >= 0 )
        and ( surf.get_palette()[len(self.__highlight_margin)+1] != highlight_colour )):
            new_palette = [(0,0,0)]
            for scale in self.__highlight_margin:
                [r,g,b] = [ (( x * scale ) / 256 ) for x in list(highlight_colour) ]
                new_palette.append((r,g,b))
            new_palette.append(highlight_colour)
            surf.set_palette(new_palette)

        if ( graphics_region >= 0 ):
            surf.set_alpha(highlight_alpha)

        #print "Splat(%d,%d) sz %d" % (sx,sy,self.__sz)
        view.blit(surf,(sx,sy))
        return self.__sz

    def __Make(self,rotation, graphics_region, remember):
        key = (rotation, graphics_region)
        if ( self.__store.has_key(key) ):
            return self.__store[key]

        sz = self.__sz
        if (( rotation == 0 ) and ( graphics_region == -1 )):
            # Make unrotated base image.
            out = pygame.transform.scale(self.__orig_img, (sz, sz))
            self.__gm.Tile_Rescaled(out, self.__name, self.__rules)

        elif ( rotation == 0 ):
            # Make unrotated image with highlighted region
            out = pygame.transform.scale(
                    self.__masks.Get_Graphics_Region_Mask(
                            graphics_region), (sz, sz))
        else:
            # Make rotated image, possibly with highlighted region
            out = pygame.transform.rotate(self.__Make(0,
                    graphics_region, False),rotation * -90)

        if ( remember ):
            self.__store[ key ] = out
            self.__store_empty = False
            if ( graphics_region == -1 ):
                self.__gm.Tile_Finalise(out, self.__name, self.__rules)

        return out

    def Get_Graphics_Regions_For_Edge(self,e):
        return self.__masks.Get_Graphics_Regions_For_Edge(e)

    def Get_Graphics_Region_For_Point(self,mx,my):
        return self.__masks.Get_Graphics_Region_For_Point(mx,my)

    def Get_Centre_Of_Graphics_Region(self,gr):
        return self.__masks.Get_Centre_Of_Graphics_Region(gr)

    def __Load_Masks(self, name, enable_compiler):
        if ( enable_compiler ):
            self.__Mask_Compiler(name)
            return

        tm = tile_graphics_masks.Tile_Graphics_Masks()
        tm.Load(name)
        assert tm.Is_Ok()

        self.__masks = tm

    def __Mask_Compiler(self, name):

        fname = self.__tile_db.Get_Mask_Filename(name)

        print "Compiling mask for tile",name,"mask:",fname

        tm = tile_graphics_masks.Tile_Graphics_Masks()
        orig = resources.Get_Resource_Image(fname)
        tm.Build_From(orig, self.__highlight_margin)

        print "Testing tile",name

        # And now for some independant testing, from the 
        # Tile_With_Edges_And_Regions class
        self.__masks = tm
        t = tile.Tile_With_Edges_And_Regions(name, self.__rules)
        t.Translate_To_Graphics_Region(self,0)

        tm.Save(name)

        assert tm.Is_Ok()
        self.__masks = tm




#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: game_ui.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# The widget that contains the game tiles, the scoreboard, or the
# remaining tile display. Appears in top right of screen.
#

import pygame , math , time , sys , traceback

import game_logic_driver , library , tile_cache , scoresheet
import board_graphics , place_menu , tile_graphics , resources
import remaining_tiles , constants , demo_mq

from pygame.locals import *
from pgu import gui



[ MODE_NORMAL , MODE_SELECT_ZOOM , MODE_FORCE_ZOOM , MODE_MENU , 
    MODE_CHAT , MODE_SCOREBOARD , MODE_REMAINING_TILES ] = xrange(7)
ALTERNATE_VIEW_MODES = [ MODE_SCOREBOARD , MODE_REMAINING_TILES ]

class Game_User_Interface(gui.Container):

    def __init__(self, (gw, gh), clock,
                (rules, game_info, client_mq, server_mq), 
                gui_msg_fn, cache_load_progress_fn, demo_load_progress_fn,
                demo_playback_stream,
                **params):
        params[ 'width' ] = gw
        params[ 'height' ] = gh
        gui.Container.__init__(self, **params)


        # Children instantiated:
        self.__scoreboard_widget = None
        self.__remaining_tiles_widget = None
        self.__game_widget = Surface_Widget((gw, gh), None)
        self.__current_widget = self.__game_widget
        self.add(self.__current_widget, 0, 0)

        # UI setup:
        self.__running = True
        self.__mousemove = None
        self.__scroll_start = None
        self.__rules = rules
        self.__game_info = game_info
        self.__gui_msg_fn = gui_msg_fn
        self.__demo_playback_stream = demo_playback_stream
        self.__mq = client_mq
        self.__sidebar = None
        self.__pgu_update = False

        self.__scoring_fx = []
        self.__flashing_fx = []
        self.__fx_refresh = False
        self.__zoom_centre = (0,0)
        self.__mode = MODE_NORMAL
        self.__mode_change = True

        # Init backing store for game
        self.__surface = self.__game_widget.Get_Surface()

        # Create cache
        self.__big_cache = cache = tile_cache.Tile_Cache(rules) # zoom mode
        self.__little_cache = cache2 = tile_cache.Tile_Cache(rules) # overview

        # Create game
        gld_class = rules.Get_Game_Logic_Driver_Class()

        self.__game = gld_class(rules, game_info, gui_msg_fn,
                    demo_load_progress_fn, cache, client_mq, False)

        # Do precaching
        tile_bag = self.__game.Get_Tile_Bag()
        for (i, ti) in enumerate(tile_bag):
            name = ti.Get_Name()
            cache.Get(name)
            cache2.Get(name)
            cache_load_progress_fn(i + 1, len(tile_bag) + 1)

        # Master game startup
        self.__server_mq = server_mq
        if (( self.__server_mq != None )
        and ( demo_playback_stream == None )):
            # Server started
            self.__master_game = gld_class(
                    rules, game_info, gui_msg_fn, demo_load_progress_fn,
                    cache, server_mq, True)
        else:
            self.__master_game = None

        self.__board_overview_rect = self.__surface.get_rect()
        self.__zoom_window_rect = self.__surface.get_rect().inflate(-50, -50)
        self.__zoom_window_visible = False
        self.__zoom_window_visible_delayed = False

        self.__scoreboard_surface = None
        self.__remaining_tiles_surface = None
        self.__board_overview = None
        self.__zoom_window = None

        # All ready.
        cache_load_progress_fn(len(tile_bag) + 1, len(tile_bag) + 1)

    def Register_Sidebar(self, sidebar):
        assert self.__sidebar == None
        assert sidebar != None
        self.__sidebar = sidebar
        self.__zoom_window = place_menu.Place_Menu(
                self.__surface.subsurface(self.__zoom_window_rect),
                self.__big_cache, self.__game,
                self.__gui_msg_fn, self.__sidebar, 
                library.colours.zoom_window_bg)

        self.__board_overview = board_graphics.Board_Graphics(
                self.__surface,
                self.__little_cache, self.__game,
                self.__gui_msg_fn, self.__sidebar, 
                library.colours.game_window_bg)

    def Resume_Game_From_Demo(self):
        assert self.__demo_playback_stream != None
        assert self.__server_mq != None
        assert self.__master_game == None

        def Broadcast((msg, sender_id)):
            self.__server_mq.Send(msg)

        self.__mq.Demo_Play_Event(self.__demo_playback_stream,
                    Broadcast, demo_mq.DEMO_PLAY_MODE_RESUME_GAME)

        while (( not self.__game.Is_Ready() )
        and ( not self.__game.Is_Game_Over() )):
            self.__game.Tick()

        if ( self.__game.Is_Game_Over() ):
            return False # didn't work...

        self.__demo_playback_stream = None
        self.__master_game = self.__game.Slave_To_Master(self.__server_mq)
        return True

    def Send_Ready_For_Demo_Playback(self):
        if (( self.__demo_playback_stream != None )
        and ( self.__server_mq == None )):
            self.__mq.Poke_Event((constants.RAW_GAME_READY_MESSAGE, 0))

    def Send_Ready_If_Master(self):
        if ( self.__server_mq != None ):
            self.__server_mq.Send(constants.RAW_GAME_READY_MESSAGE)

    def Demo_Next_Move(self, slow_play):
        if ( self.__demo_playback_stream == None ):
            return False

        end_stream = self.__mq.Demo_Play_Event(self.__demo_playback_stream, 
                            None, demo_mq.DEMO_PLAY_MODE_VIEWING_ONLY)

        # Catch up to demo events
        if ( end_stream or ( not slow_play )):
            while ( self.__mq.Get_Inbox_Size() != 0 ):
                self.__game.Tick()

        # Handle end of demo stream.
        if ( end_stream ):
            self.__demo_playback_stream = None
            self.__gui_msg_fn("The recording has ended.")
            return False # end demo

        # checkpoint reached
        return True

    def Tick(self):
        if ( self.__master_game != None ):
            self.__master_game.Tick()
        self.__game.Tick()

        self.__sidebar.Tick()
        (self.__scoring_fx, 
                self.__flashing_fx) = self.__sidebar.Get_Next_Effect()

    def Update_Scoreboard(self):
        if (( self.__scoreboard_surface == None )
        or ( self.__scoreboard_widget == None )): 

            s = scoresheet.Draw_All_Records(self.__rules, 
                    self.__game.Get_Player_Objects(),
                    self.__game.Get_Player_Names(), 
                    self.__board_overview_rect.size)
            self.__scoreboard_surface = s 
            self.__scoreboard_widget = Scroll_Surface_Widget(
                    self.__board_overview_rect.size, s,
                    background=library.colours.score_sheet_bg)

    def Update_Remaining_Tiles(self):
        if (( self.__remaining_tiles_surface == None )
        or ( self.__remaining_tiles_widget == None )):

            s = remaining_tiles.Draw_Remaining_Tiles(
                    self.__big_cache,
                    self.__game.Get_Tile_Bag(),
                    self.__board_overview_rect.size)
            self.__remaining_tiles_surface = s 
            self.__remaining_tiles_widget = Scroll_Surface_Widget(
                    self.__board_overview_rect.size, s,
                    background=library.colours.tile_sheet_bg)

    def Update_Game(self, force_full_update):
        if ( self.__game.Is_Muted() ):
            # Game events are muted while playing demos over the network.
            return

        gcf = self.__sidebar.Get_Game_Change_Flag() 

        if ( self.__mode_change ):
            # invalidate scoreboard etc.
            self.__scoreboard_surface = None
            self.__remaining_tiles_surface = None

        if ( self.__fx_refresh or gcf 
        or force_full_update or self.__mode_change ):

            #print 'Fx refresh',self.__fx_refresh,'GCF',gcf,'FFU',force_full_update,
            #print 'SFX',len(self.__scoring_fx),'FFX',len(self.__flashing_fx)

            if (( self.__zoom_window_visible )
            and ( not self.__zoom_window_visible_delayed )):
                # Zoom window cache is flushed on every appearance
                # to save memory.. this is optional and might slow the game
                # down. But so does swapping...
                print 'Flush!'
                self.__big_cache.Flush()

            self.__zoom_window_visible_delayed = self.__zoom_window_visible

            # Refresh and redraw...
            self.__board_overview.Refresh()
            if ( self.__zoom_window_visible ):
                self.__zoom_window.Refresh()

            self.__sidebar.Draw()

            self.__board_overview.Draw()
            self.__board_overview.Scroll_And_Zoom(None, True)
            self.__board_overview.Draw_FX(self.__scoring_fx, 
                                    self.__flashing_fx)

            auto_zoom = ( self.__sidebar.Get_Zoom_Centre() != None )
            if ( auto_zoom ):
                if ( self.__mode in [ MODE_MENU,
                            MODE_CHAT ] ):
                    pass # No mode forcing available
                else:
                    self.Set_Mode(MODE_NORMAL)

                self.__zoom_centre = self.__sidebar.Get_Zoom_Centre()

            self.__zoom_window_visible = ( auto_zoom 
                    or ( self.__mode == MODE_FORCE_ZOOM ))

            if ( self.__zoom_window_visible ):
                self.__zoom_window.Scroll_And_Zoom(
                                        self.__zoom_centre, False)
                self.__zoom_window.Draw()
                self.__zoom_window.Draw_FX(self.__scoring_fx, 
                                        self.__flashing_fx)
                pygame.draw.rect(self.__surface, 
                        (0,0,0), self.__zoom_window_rect, 2)

            self.__game_widget.Dirty()
    
        elif ( self.__zoom_window_visible ):
            if ( not ( self.__mode in ALTERNATE_VIEW_MODES )):
                self.__zoom_window.Draw_Menu()
                self.__game_widget.Dirty()

        self.__fx_refresh = (
                ( len(self.__scoring_fx) != 0 ) 
                or ( len(self.__flashing_fx) != 0 ) )
        self.__mode_change = False


    def __Set_View_To(self, widget):
        if ( widget != self.__current_widget ):
            self.remove(self.__current_widget)
            self.__current_widget = widget
            self.add(self.__current_widget, 0, 0)

    def Draw(self, force_full_update):
        self.Update_Game(force_full_update)

        if ( self.__mode in [ MODE_NORMAL , MODE_SELECT_ZOOM , 
                        MODE_FORCE_ZOOM , MODE_MENU , MODE_CHAT ] ):
            self.__Set_View_To(self.__game_widget)

        elif ( self.__mode == MODE_SCOREBOARD ):
            self.Update_Scoreboard()
            self.__Set_View_To(self.__scoreboard_widget)

        elif ( self.__mode == MODE_REMAINING_TILES ):
            self.Update_Remaining_Tiles()
            self.__Set_View_To(self.__remaining_tiles_widget)

    def event(self,e):
        gui.Container.event(self, e)
        if ( e.type == MOUSEMOTION ):
            self.__Mouse_Event(False, e.pos)
        elif ( e.type == MOUSEBUTTONDOWN ):
            self.__Mouse_Event(True, e.pos)
    
    def __Mouse_Event(self, clicked, pos):
        def Correct_Pos((x1,y1), r):
            (x2,y2) = r.topleft
            return ((x1 - x2), (y1 - y2))

        if ( clicked ):
            if ( self.__mode == MODE_SELECT_ZOOM ):
                # Zoom in on selected point (if it's valid)
                if ( self.__board_overview_rect.collidepoint(pos) ):
                    (sx, sy) = Correct_Pos(pos, self.__board_overview_rect)
                    self.__zoom_centre = self.__board_overview.Zoom_Helper((sx, sy))
                    self.Set_Mode(MODE_FORCE_ZOOM)
                else:
                    self.Set_Mode(MODE_NORMAL)
                return

            elif ( self.__mode == MODE_MENU ):
                # You clicked on the main screen by mistake.
                # I'll ignore it.
                return

        # Otherwise... normal handling.

        if (( self.__zoom_window_visible )
        and ( self.__zoom_window_rect.collidepoint(pos) )):
            if ( clicked and ( self.__mode == MODE_FORCE_ZOOM )):
                # Unzoom
                self.Set_Mode(MODE_NORMAL)

            elif ( not ( self.__mode in ALTERNATE_VIEW_MODES )):
                cpos = Correct_Pos(pos, self.__zoom_window_rect)
                self.__zoom_window.Mouse_Move_Event(cpos)
                if ( clicked ):
                    self.__zoom_window.Click_Event(cpos)

        elif ( self.__board_overview_rect.collidepoint(pos) ): 
            if ( not ( self.__mode in ALTERNATE_VIEW_MODES )):
                cpos = Correct_Pos(pos, self.__board_overview_rect)
                self.__board_overview.Mouse_Move_Event(cpos)
                if ( clicked ):
                    self.__board_overview.Click_Event(cpos)

    def Clear_Up(self):
        self.__game.Stop()

    def Exit_Condition(self):
        return not self.__running

    def Set_Mode(self, mode_is):
        self.__mode = mode_is
        self.__mode_change = True

    def Get_Game(self):
        return self.__game

    def Get_Mode(self):
        return self.__mode

    def Get_Cache(self):
        return self.__big_cache

    def Test_Get_Player_Objects(self):
        return self.__game.Get_Player_Objects()

    def Is_Game_Over(self):
        return self.__game.Is_Game_Over()



# Children of the game ui:
class Surface_Widget(gui.Widget):
    def __init__(self, (gw, gh), surface, **params):
        params[ 'width' ] = gw
        params[ 'height' ] = gh
        gui.Widget.__init__(self, **params)

        if ( surface == None ):
            surface = pygame.Surface((gw, gh))

        self.__size = (gw, gh)
        self.__surface = surface
        self.__pgu_update = True

    def Get_Surface(self):
        return self.__surface

    def Dirty(self):
        self.__pgu_update = True

    def paint(self,s):
        s.blit(self.__surface, (0, 0))
        self.__pgu_update = False

    def update(self,s):
        if ( not self.__pgu_update ):
            return []
        self.__pgu_update = False
        s.blit(self.__surface, (0, 0))
        return [ self.__surface.get_rect() ]

    def resize(self,width=None,height=None):
        return self.__size

class Scroll_Surface_Widget(gui.ScrollArea):
    def __init__(self, (gw, gh), surf, **params):
        self.__contents = Surface_Widget((gw, 
                    surf.get_rect().height), surf)
        gui.ScrollArea.__init__(self, self.__contents,
                    gw, gh, False, **params)
    
    def Get_Surface(self):
        return self.__contents.Get_Surface()

    def Dirty(self):
        self.__contents.Dirty()



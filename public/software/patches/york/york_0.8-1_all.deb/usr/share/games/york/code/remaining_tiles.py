#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: remaining_tiles.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# Remaining tiles display builder.
# 


import pygame
from pygame.locals import *
import library, extra, resources



def Draw_Remaining_Tiles(cache, tile_bag, (width, min_height)):
    
    # Flatten the tile bag.
    flattened_bag = []
    last_name = None
    count = 0
    for ti in tile_bag:
        name = ti.Get_Name()
        if ( name == last_name ):
            # You get runs of tiles from the bag, all with the same name.
            count += 1
        else:
            if ( last_name != None ):
                flattened_bag.append((last_name, count))
            last_name = name
            count = 1

    if ( last_name != None ):
        flattened_bag.append((last_name, count))
   
    # Begin drawing
    sz = len(flattened_bag)
    columns = 3
    rows = ( sz + columns - 1 ) / columns
    margin = cache.Get_Size() / 4
    record_height = cache.Get_Size() + ( margin * 2 )
    record_width = ( width - ( margin * 2 )) / columns 
    height = ( record_height * rows ) + 100
    height = max(height, min_height)

    font = resources.Get_Font(16)

    surf = pygame.Surface((width, height))
    surf.set_colorkey(None)
    surf.fill(library.colours.tile_sheet_bg)

    x = y = margin
    xc = 0
    for (name, count) in flattened_bag:
        assert name != None
        tile_graphs = cache.Get(name)
        tile_graphs.Draw(surf, x, y, 0)

        s = font.render("x %u" % count,
                    True, library.colours.tile_sheet_fg)
        r = s.get_rect()
        r.center = (0, y + ( cache.Get_Size() / 2 ))
        r.left = x + cache.Get_Size() + margin
        surf.blit(s, r.topleft)

        xc += 1 
        if ( xc >= columns ):
            y += record_height
            x = margin
            xc = 0
        else:
            x += record_width

    if ( xc > 0 ):
        y += record_height
        
    s = font.render("%u tiles remaining in bag." % len(tile_bag),
                True, library.colours.tile_sheet_fg)
    surf.blit(s, (margin, y))

    return surf




#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: demo_mq.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 

import threading , os , time , sys
import library , extra , client , resources , message_queue , constants
import config


DEMO_COMMENT = '# '
DEMO_MESSAGE_PACKET = '$msg'
DEMO_DEBUG_PACKET = '$dbg'
DEMO_END_PACKET = '$end'
DEMO_VERSION = '1'

DEMO_PLAY_MODE_VIEWING_ONLY = 1
DEMO_PLAY_MODE_LOBBY_REPLAY = 2
DEMO_PLAY_MODE_RESUME_GAME = 3

class Demo_MQ(client.Client):
    def __init__(self, demo_stream):
        client.Client.__init__(self)
        self.__stream_lock = threading.Semaphore()
        self.__demo_stream = demo_stream
        self.__record_enable = ( self.__demo_stream != None )
        self.__record = False
        self.__play = False
        self.__checkpoints_recorded = 0
        self.__quiet = not ( '--denoisy' in sys.argv )

        # Generate demo header in record mode
        if ( self.__record_enable ):
            demo_header = [ 
                    'York demo recording. York version %s.' % 
                                    library.Version() ,
                    'Here is some optional information about your system.',
                    'If you are publishing this demo on the Internet',
                    'you may wish to remove this information using',
                    'a text editor. This will not affect demo playback.' ,
                    extra.Get_System_Info() ,
                    '' ]

            # mod name on first line, version on second
            self.__demo_stream.write('%s\n%s\n' % (
                    resources.Get_Mod_Name(), DEMO_VERSION))
            # then header (comments)
            for s in demo_header:
                self.__demo_stream.write('%s%s\n' % (DEMO_COMMENT, s))





    def Demo_Play_Event(self, stream, to_function, demo_play_mode,
                progress_function=None):

        assert demo_play_mode in [
                DEMO_PLAY_MODE_VIEWING_ONLY,
                DEMO_PLAY_MODE_LOBBY_REPLAY,
                DEMO_PLAY_MODE_RESUME_GAME ]

        if ( to_function == None ):
            to_function = self.Poke_Event

        self.__play = True

        def Demo_Execute(packet_type, packet_data):
            if ( packet_type.startswith(DEMO_MESSAGE_PACKET) ):
                try:
                    sender_id = int(packet_type[ len(DEMO_MESSAGE_PACKET): ])
                except:
                    raise IOError("Demo stream message coding error.")

                msg = packet_data
                msg = extra.Launder_Message(msg)
                if ( not self.__quiet ):
                    print '[ds]',sender_id,msg

                if ( not msg.startswith(constants.RAW_PROGRESS_MESSAGE) ):
                    to_function((msg, sender_id))
                return True

            elif ( packet_type.startswith(DEMO_DEBUG_PACKET) ):
                if ( not self.__quiet ):
                    print '[demo]',packet_data
                return True

            elif ( packet_type.startswith(DEMO_COMMENT) ):
                # One-line packet. Not valid.
                return False

            elif ( packet_type.startswith(DEMO_END_PACKET) ):
                # Valid but ignored. EOF is End of demo.
                return True

            # invalid
            return False

        def Is_Checkpoint(packet_type, packet_data):
            return (( packet_type.startswith(DEMO_MESSAGE_PACKET) )
                and ( packet_data == constants.RAW_CHECKPOINT_MESSAGE ))

        if (( demo_play_mode == DEMO_PLAY_MODE_VIEWING_ONLY )
        or ( demo_play_mode == DEMO_PLAY_MODE_LOBBY_REPLAY )):
            # Play to next checkpoint (and return False)
            # or end of demo (and return True).
            packet_type = ""
            while True:
                packet_data = stream.readline()

                if ( len(packet_data) == 0 ):
                    return True # end of demo

                packet_data = packet_data.strip()

                if ( Is_Checkpoint(packet_type, packet_data) ):
                    return False

                if ( Demo_Execute(packet_type, packet_data) ): # regular demo packet
                    packet_type = ""
                else:
                    packet_type = packet_data

        elif ( demo_play_mode == DEMO_PLAY_MODE_RESUME_GAME ):
            # Play until the final checkpoint, then send the READY
            # message followed by the checkpoint, then stop. This requires
            # read-ahead - otherwise we do not know which checkpoint is the
            # last one. Returns True iff the ready message was sent
            packet_stream = []
            last_checkpoint = None
            packet_type = ""
            while True:
                packet_data = stream.readline()

                if ( len(packet_data) == 0 ):
                    break

                packet_data = packet_data.strip()

                if ( Is_Checkpoint(packet_type, packet_data) ):
                    last_checkpoint = len(packet_stream)

                packet_stream.append(packet_data)
                packet_type = packet_data

            if ( last_checkpoint == None ):
                # Demo too short
                return False

            packet_type = ""
            interval = 0
            for (i, packet_data) in enumerate(
                                    packet_stream[ : last_checkpoint ]):

                if ( Demo_Execute(packet_type, packet_data) ):
                    packet_type = ""
                else:
                    packet_type = packet_data

                if ( interval < 0 ):
                    interval = 10
                    msg = '%s %u' % (constants.RAW_PROGRESS_MESSAGE ,
                            ( i * constants.PROGRESS_BASE ) / last_checkpoint)
                    to_function((msg, -1))
                else:
                    interval -= 1

            # We are now just before the final checkpoint message. Send ready.
            to_function((constants.RAW_GAME_READY_MESSAGE, 0))
            # Then checkpoint
            to_function((constants.RAW_CHECKPOINT_MESSAGE, 0))
            return True

           
    def Demo_Hook(self, msg_and_sender_id):
        if ( msg_and_sender_id != None ):
            (msg, sender_id) = msg_and_sender_id

            self.__stream_lock.acquire()

            if ( msg == constants.DEMO_RECORDING_BEGINS ):
                self.__record = self.__record_enable
                msg = None

            elif ( msg == constants.RAW_GAME_READY_MESSAGE ):
                # This must not go in the demo file.
                msg = None

            elif ( self.__record ):
                self.__demo_stream.write('%s%u\n%s\n' % (
                                DEMO_MESSAGE_PACKET, sender_id, msg))
                if ( msg == constants.RAW_CHECKPOINT_MESSAGE ):
                    self.__checkpoints_recorded += 1

            self.__stream_lock.release()

    def Record_Control(self, active):
        self.__record = self.__record_enable and active

    def Close(self):
        self.__stream_lock.acquire()
        assert self.__demo_stream != None
        self.__demo_stream.write('%s\n# demo ends.\n\n' % DEMO_END_PACKET)
        self.__demo_stream.close()
        self.__demo_stream = None
        self.__record = False
        self.__record_enable = False
        self.__stream_lock.release()

    def Get_Demo_Size(self):
        self.__stream_lock.acquire()
        cp = self.__checkpoints_recorded
        self.__stream_lock.release()
        return cp

    def Debug_Message(self, msg):
        if ( len(msg) != 0 ):
            self.__stream_lock.acquire()
            if ( self.__record_enable ):
                self.__demo_stream.write('%s\n.%s\n' % (
                                DEMO_DEBUG_PACKET, msg))
                self.__demo_stream.flush()

            self.__stream_lock.release()

    def Get_ID(self):
        x = client.Client.Get_ID(self) 
        if (( x == None ) and ( self.__play )):
            return 4 # Fake play id
        else:
            return x


def Open_Demo(file_name):
    file_name = os.path.join(config.Get_Recordings_Dir(), file_name)
    fd = file(file_name, "rt")
    mod_name = library.Launder_Message(fd.readline().strip())
    if ( len(mod_name) == 0 ):
        raise IOError("Demo format is incorrect.")
    version = library.Launder_Message(fd.readline().strip())
    if ( version != DEMO_VERSION ):
        raise IOError("Demo version is incorrect.")

    return (fd, mod_name)

def New_Demo_File():
    fn = "york_recording_%04u%02u%02u_%02u%02u%02u.sav" % tuple(
            time.localtime()[:6])
    return file(os.path.join(config.Get_Recordings_Dir(), fn), "wt")

def Get_Demo_List():
    demo_list = []
    for demo_file_name in os.listdir(config.Get_Recordings_Dir()):
        try:
            (fd, mod_name) = Open_Demo(demo_file_name)
            s = os.fstat(fd.fileno())
        except IOError, r:
            fd = mod_name = s = None
       
        if ( fd != None ):
            fd.close()

        if (( mod_name != None )
        and ( s != None )
        and ( len(mod_name) > 0 )):
            demo_list.append((demo_file_name, mod_name, s.st_size / 1024))

    demo_list.sort()
    return demo_list



#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# 
# 
#
# The rules object is subclassed for the River Expansion.
# New rules:-
# - New type of edge (river edge)
# - Stack begins with river tiles
# - You can't place the river tiles in a U-turn.




class River_Expansion_Rules(rules.Basic_Rules):

    def Identify_Edge(self, regions):
        if ( regions == ['F','V','F'] ):
            return 'V'
        else:
            return rules.Basic_Rules.Identify_Edge(self, regions)

    
    def Get_Possible_Rotations(self, tile_instance, (tx, ty), board_logic):

        out = rules.Basic_Rules.Get_Possible_Rotations(
                        self, tile_instance, (tx, ty), board_logic)
        if ( len(out) == 0 ):
            return out

        if ( not self.Is_River(tile_instance.Get_Flags()) ):
            return out

        # Put the river anywhere you want if there are no
        # tiles down..
        if ( len(board_logic.Get_Tile_List()) == 0 ):
            return out

        # Must connect to existing river.
        existing_edge = None
        existing_tile = None
        existing_pos = None

        for (x1, y1, e1) in [ (tx, ty + 1, 0), (tx - 1, ty, 1),
                                (tx, ty - 1, 2), (tx + 1, ty, 3) ]:
            t1 = board_logic.Get_Tile_At(x1, y1)
            if (( t1 != None )
            and ( t1.Get_Edge(e1) == 'V' )):
                assert ( existing_edge == None )
                existing_edge = e1
                existing_tile = t1
                existing_pos = (x1, y1)

        if ( existing_edge == None ):
            # No connection to existing river
            return []

        # No Immediate U-Turns Rule:
        
        # Is the new tile a corner piece?
        new_edge = None

        for e0 in xrange(4):
            if ( tile_instance.Get_Edge(e0) == 'V' ):
                if ( tile_instance.Get_Edge(e0 + 1) == 'V' ):
                    new_edge = e0
                    break
        
        if ( new_edge == None ):
            # New tile is not a corner piece, u-turn rule is irrelevant
            return out

        dbg_uturns = False

        if ( dbg_uturns ):
            print 'new tile is a corner piece: river edges %u and %u' % (
                        new_edge, new_edge + 1)
            print 'existing edge', existing_edge

        connection_edge = existing_edge + 2

        # Is existing tile a corner piece?
        if ( existing_tile.Get_Edge(existing_edge + 3) == 'V' ):
            # left turn, so new tile must be a right turn
            next_edge = connection_edge + 3
            if ( dbg_uturns ):
                print 'existing tile is a left turn'

        elif ( existing_tile.Get_Edge(existing_edge + 1) == 'V' ):
            # right turn, so new tile must be a left turn
            next_edge = connection_edge + 1
            if ( dbg_uturns ):
                print 'existing tile is a right turn'

        else:
            # straight or end piece, u-turn rule is irrelevant
            return out

        # connection_edge, next_edge are correct
        # new_edge is the lowest numbered river edge on the new tile
        # how many times should the new tile be rotated so that
        # new_edge and new_edge+1 are equal to connection_edge
        # and next_edge?

        connection_edge %= 4
        next_edge %= 4
        permitted_rotation = None

        for i in xrange(4):
            new_edge_plus_1 = ( new_edge + 1 ) % 4

            if (( new_edge in (connection_edge, next_edge) )
            and ( new_edge_plus_1 in (connection_edge, next_edge) )):
                permitted_rotation = i
                break
            
            new_edge = new_edge_plus_1

        if ( dbg_uturns ):
            print 'connection edge on new tile:', connection_edge
            print 'next free edge on new tile:', next_edge
            print 'permitted rotation is', permitted_rotation

        if ( permitted_rotation in out ):
            return [ permitted_rotation ]
        else:
            if ( dbg_uturns ):
                print 'that rotation is not available'
            return []




    def Name_For_Region_Type(self, rt):
        if ( rt == 'V' ):
            return "River"
        else:
            return rules.Basic_Rules.Name_For_Region_Type(self, rt)

    def Is_River(self, tile_flags):
        return (( tile_flags != None )
            and ( 'r' in tile_flags ))

    def Get_Subgame_List(self):
        # 0 is the default subgame. It should always be present.
        return [ (0, "Normal (84 tiles)"),
                (2, "Double (156 tiles)")]

    def Build_Stack(self, subgame):
        rules.Basic_Rules.Build_Stack(self, subgame)
        tdb = self.Get_Tile_DB()
        add = tdb.Add_Tile

        add('river.end', 1)
        add('river.straight', 2)
        add('river.city.road', 1)
        add('river.road.straight', 1)
        add('river.2cities', 1)
        add('river.monastery', 1)
        add('river.curve', 2)
        add('river.road.curve', 1)
        add('river.city.curve', 1)
        tdb.Shuffle_Tiles(10)
        add('river.start', 1)

        return tdb.Get_Stack()


Register_Mod("River Expansion", River_Expansion_Rules)




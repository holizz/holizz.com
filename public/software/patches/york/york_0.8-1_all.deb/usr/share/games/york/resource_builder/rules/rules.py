#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# 
# 
#
# Initialisation code for the basic game.
#
# Game modifications can include any code here. The standard
# procedure for modifications should involve subclassing the
# Basic_Rules object. Helpfully, the rules module is already in
# the global namespace when this module is executed.
#
# Changes to the tileset should be made in the tileset.py file.
#
# If you want to include code in other Python modules, then you
# can get them out of your mod's TAR file using the mod object.

pass





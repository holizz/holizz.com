#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: default_colours.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# 
# 

# The colour theme of the game.
# Modifications may change this. I suggest that you import the
# entire module and then redefine the constants that you want to
# change, i.e.
#   from default_colours import *
#   chat_box_bg = (100,0,100) # or whatever..
# Colours are RGB triplets. Each item is an integer in range 0 to 255.
       

# Background colours
chat_box_bg = (0,0,0)
game_menu_bg = (0,0,40)
game_window_bg = (40,0,0)
lobby_name_bg = (0,0,0)
lobby_bg = (130, 125, 120)
lobby_list_bg = (110, 110, 105)
meeple_set_bg = (100, 90, 95)
meeple_bg = (100, 100, 95)
place_menu_bg = (60,80,60)
sel_screen_bg = (120,125,130)
zoom_window_bg = (30,0,0)
score_sheet_cell_bg = (200, 200, 200)
score_sheet_bg = (30, 0, 0)
tile_sheet_bg = (30, 0, 0)
message_surface = (60, 60, 65)
sidebar_bg = (100, 95, 95)
sidebar_scorebox_bg = (90, 80, 85)
progress_bar_bg = (90, 95, 90)
section_name_bg = (150, 150, 220)


# Foreground colours
chat_box_fg = (200,200,200)
icon_name_fg = (230,230,230)
lobby_name_fg = (255,255,0)
lobby_name_resume_fg = (255,0,0)
place_menu_caption_fg = (255,255,0)
popup_box_fg = (255,255,0)
region_stats_fg = (200,200,200)
tile_stats_fg = (200,200,200)
sel_screen_fg = (0, 0, 0)
ready_colour = (0,255,0)
slot_name_fg = (200, 200, 200)
lobby_header_fg = (0, 0, 0)
score_sheet_fg = (230, 230, 230)
tile_sheet_fg = (230, 230, 230)
score_sheet_text = (0, 0, 0)
progress_bar_fg = (0, 0, 0)

# Special colours
floating_score = (255,255,255)
highlight_menu_colour = (255,255,0)
place_menu_highlight = (255,255,0)
placeable_location_colour = (0,255,0)
sidebar_menu_highlight = (255,255,0)
title_colour = (255,255,0)
turn_announcer = (255,255,255)
region_valid_meeple = (0,255,0)
region_invalid_meeple = (255,128,0)
region_not_empty = (255,0,0)
observer_colour = (0,128,200)

# alpha values
message_alpha = 192

# gamma values
message_edge_gamma = 20
sidebar_edge_gamma = 20

# Player colours
# Set the maximum number of players in your mod rules
# These are: Red, green, blue, yellow, black, grey
player_colour = [(255,0,0),(0,255,0),(0,0,255),
        (255,255,0),(20,20,20), (128,128,128)]

# Different colours for use in chat
player_chat_colour = [(255,0,0),(0,255,0),(120,120,255),
        (255,255,0),(0,0,0), (148,148,148)]
        



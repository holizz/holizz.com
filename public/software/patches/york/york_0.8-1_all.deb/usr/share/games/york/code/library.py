#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: library.py,v 1.2 2006/08/09 20:03:21 jack Exp $
# 
# 
# Library functions may be called from anywhere in the code.
# There are also some fundamental constants in here which may change
# between versions. Modifications should use this at their own risk.
# 



import pygame , gzip , os
from pygame.locals import *
from constants import *

import default_colours

colours = default_colours


def Version():
    return "alpha 8" 

COPYRIGHTS = [
    "York version %s: http://york.sf.net/" % Version(),
    "Code copyright (C) Jack Whitham, 2006.",
    "Photographs copyright (C) James Wells, 2006.",
    "PGU (C) Phil Hassey, 2005-06.",
    "Thanks to acidd_uk, jillyanthrax,",
    "gorkeh, newsbot3 and many others." ]
    
def Get_Colour_For_Player(player, chat=False):
    assert 0 <= player 
    player %= len(colours.player_colour)
    if ( chat ):
        return colours.player_chat_colour[ player ]
    else:
        return colours.player_colour[ player ]

        
def Get_Sample_Player_Name():
    return "".join(["X" for i in range(0,MAX_PLAYER_NAME_LENGTH + 2)])

def Filter_Message(msg):
    # Message data may have come straight off the network. As a precaution
    # against injection of malicious data into the data stream, we apply
    # a number of restrictions on the contents of a message. Even with
    # these restrictions, data passed from player to player is considered
    # "untrusted". No pickles or executable code of any sort are ever
    # moved across the network.
    if (( msg == None ) or not ( type(msg) == str )):
        return ""
    if ( len(msg) == 0 ):
        return ""
    if ( len(msg) > 200 ):
        return ""

    removals = [ i for (i, ch) in enumerate(msg)
                    if not ( 32 <= ord(ch) <= 127 ) ]
    for i in reversed(removals):
        msg = msg[ 0:i ] + '?' + msg[ i + 2: ]
    return msg
        
def Launder_Message(msg):
    # Even more severe than filtering.
    return Filter_Message(msg.strip())


def Launder_Player_Name(name):
    name = Launder_Message(name).title()
    maxlen = MAX_PLAYER_NAME_LENGTH
    if ( len(name) > maxlen ):
        name = name[0:maxlen]
    name2 = ""
    for i in name:
        if ( i.isalnum() or i in "_-[](){}@$" ):
            name2 += i # Note, / not allowed
        else:
            name2 += " "
    return name2.strip()

def Edge_Expansion_Effect(mask,margin_size):
    msz = mask.get_rect().width
    assert mask.get_rect().height == msz
    max = margin_size

    output = pygame.Surface((msz,msz),0,8)
    output.set_palette([(i,i,i) for i in range(0,margin_size + 1)])
    output.fill(0)

    # First - threshold the input image to pick up edges
    for y in range(0,msz):
        for x in range(0,msz):
            (r,g,b,a) = mask.get_at((x,y))
            if ( r > 128 ):
                output.set_at((x,y),max)

    # Then add the fuzzy border
    for i in range(0,4):
        for y in range(0,msz):
            fade = 0
            for x in range(0,msz):
                (r,g,b,a) = output.get_at((x,y))
                if ( r > fade ):
                    fade = r - 1
                elif (( r < fade ) and ( fade > 0 )):
                    output.set_at((x,y),fade)
                    fade -= 1

        output = pygame.transform.rotate(output,90)

    output.set_colorkey((0,0,0))
    return output 

def Partial_Edge_Bevel_Effect(surface, edge, colour, margin):
    outer = surface.get_rect()
    inner = outer.inflate(margin, margin)

    if ( edge == 0 ):
        poly = [outer.topleft, outer.topright, 
                    inner.topright, inner.topleft]
    elif ( edge == 1 ):
        poly = [outer.topright, inner.topright, 
                    inner.bottomright, outer.bottomright]
    elif ( edge == 2 ):
        poly = [outer.bottomleft, inner.bottomleft, 
                    inner.bottomright, outer.bottomright]
    elif ( edge == 3 ):
        poly = [outer.topleft, inner.topleft, 
                    inner.bottomleft, outer.bottomleft]
    else:   
        assert False
    pygame.draw.polygon(surface, colour, poly)

def Gamma_Colour((r, g, b), gamma_factor):
    def G(x):
        x += gamma_factor
        if ( x < 0 ): return 0
        if ( x > 255 ): return 255
        return x

    return (G(r), G(g), G(b))


def Edge_Bevel_Effect(surface, bg_colour, gamma_factor):
    surface.fill(bg_colour)
    
    def Partial(gamma, edge):
        gamma *= gamma_factor
        gamma /= 8
        Partial_Edge_Bevel_Effect(surface, edge, 
                Gamma_Colour(bg_colour, gamma),
                        EDGE_BEVEL_EFFECT_MARGIN)

    Partial(8, 0)
    Partial(6, 3)
    Partial(-4, 1)
    Partial(-6, 2)
    
def RM_Minus_R(begin):
    try:
        for (root, dirs, files) in os.walk(begin, topdown=False):
            for name in files:
                os.remove(os.path.join(root, name))
            for name in dirs:
                os.rmdir(os.path.join(root, name))
        os.rmdir(begin)
    except OSError:
        # Couldn't delete. Probably already deleted.
        pass
   

def Test_Mode_Draw(surf, clock):
    import extra, resources, random

    surf_rect = surf.get_rect()
    (w, h) = surf_rect.size
    sz = h / 20
    img_list = extra.Make_Meeple_Images(sz, resources.Get_Rules())
    text_surf = resources.Get_Font(20).render(
            "If you can read this, the selected mode works!",
            True, (255, 255, 255))
    text_rect = text_surf.get_rect()
    text_rect.center = surf_rect.center
    meeple_count = 20
    
    class M:
        def __init__(self, initial):
            self.r = Rect(random.randint(0, w), h - 2, sz, sz)
            self.dx = random.randint(-20, 20)
            self.dy = - random.randint(35, 40)
            self.me = img_list[ random.randint(0, len(img_list) - 1) ]
            if ( initial ):
                self.dy = 0
                self.r.y = 0

        def Do(self):
            self.r.x += self.dx
            self.r.y += self.dy
            surf.blit(self.me, self.r.topleft)
            self.dy += 2
            return surf_rect.colliderect(self.r)

    meeple_list = [ M(True) for i in xrange(meeple_count) ]
   
    frames = 0
    while True:
        surf.fill((0, 0, 40))
        for i in xrange(meeple_count):
            if ( not meeple_list[ i ].Do() ):
                meeple_list[ i ] = M(False)
      
        if (( Wait_Key_Mouse()
        and ( frames > 10 ))
        or ( frames > 100 )):
            return

        surf.blit(text_surf, text_rect.topleft)
        pygame.display.flip()
        clock.tick(40)
        frames += 1

def Wait_Key_Mouse():
    while True:
        e = pygame.event.poll()

        if ( e.type == NOEVENT ):
            return False
        elif (( e.type == KEYUP )
        or ( e.type == QUIT )
        or ( e.type == MOUSEBUTTONUP )):
            return True

def Wait(ms):
    while ( ms > 0 ):
        e = pygame.event.poll()
        if ( e.type == NOEVENT ):
            ms -= pygame.time.wait(50)


#!/usr/bin/python2.4
#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: autogen.py,v 1.2 2006/08/09 20:16:28 jack Exp $
# 
#
# Tileset autogenerator. Requires a number of Xfig files,
# and access to the tileset.py file (which is part of the game rules).
#
# The autogenerator requires the fig2dev program and ImageMagick.
#
# You can skip tileset autogeneration, and use (for example) tile
# images, by setting autogen=False in the Make_Data_File options.
# 

import pygame, os, random, sys
from pygame.locals import *

import library, resources

__parts_cache = dict()

def Find_Margins(img, coord_fn, sz):
    i1 = i2 = None

    # The black lines in the margins of the Xfig drawings
    # are used to auto-crop the image. 

    black = False
    for i in xrange(sz):
        red = img.get_at(coord_fn(i))[ 0 ]
        if ( red < 128 ):
            black = True
        elif ( black ):
            i1 = i
            break

    black = False
    for i in reversed(xrange(sz)):
        red = img.get_at(coord_fn(i))[ 0 ]
        if ( red < 128 ):
            black = True
        elif ( black ):
            i2 = i
            break

    assert ( i1 != None )
    assert ( i2 != None )
    assert ( i2 > i1 )
    return (i1, i2)


def Get_Image(name, rotation, flat_colour):
    global __parts_cache
    key = (name, rotation, flat_colour)
    if ( __parts_cache.has_key( key ) ):
        return __parts_cache[ key ]

    colour_key = (255,255,255)

    if ( rotation != 0 ):
        img = Get_Image(name, 0, flat_colour)
        if ( img == None ):
            return None
        __parts_cache[ key ] = img = pygame.transform.rotate(img,
                    rotation * -90)
        return img

    elif ( flat_colour != None ):
        img = Get_Image(name, 0, None)
        if ( img == None ):
            return None

        # Turn it into a mask with the specified flat_colour.
        img = img.copy()
        ckey = list(img.get_at((0, 0)))
        ckey[ 0:3 ] = list(colour_key)
        ckey = tuple(ckey)
        (w, h) = img.get_rect().size
        for y in xrange(h):
            start = None
            for x in xrange(w):
                if ( ckey == img.get_at((x, y)) ):
                    if ( start != None ):
                        pygame.draw.line(img,
                            flat_colour, (start, y), (x - 1, y))
                        start = None
                else:
                    if ( start == None ):
                        start = x
            if ( start != None ):
                pygame.draw.line(img,
                    flat_colour, (start, y), (w - 1, y))
                    
        __parts_cache[ key ] = img
        return img

    else:
        # Is the .fig available?
        f1 = resources.Get_Override_File('autogen/%s.fig' % name)
        if ( f1 == None ):
            return None
        f2 = file('temp.fig', 'wb')
        f2.write(f1.read())
        f2.close()
        f1.close()

        # Convert to PNG
        os.system("fig2dev -L png temp.fig >temp.png")
        # Convert to Surface
        img = pygame.image.load("temp.png").convert()
        os.unlink("temp.png")
        os.unlink("temp.fig")
        # Crop margins
        (x1, x2) = Find_Margins(img, lambda i: (i, 0), img.get_rect().width)
        (y1, y2) = Find_Margins(img, lambda i: (0, i), img.get_rect().height)
        img = img.subsurface(Rect(x1, y1, x2 - x1, y2 - y1))
        # Apply colour key (white is background)
        img.set_colorkey(colour_key)

        __parts_cache[ key ] = img
        return img

def Get_Base(flat_colour):
    img = Get_Image("fields", 0, flat_colour)
    if ( img == None ):
        return None
    return img.copy()

def Mix_Image(base, name, rotation, flat_colour):
    img = Get_Image(name, rotation, flat_colour)
    if ( img == None ):
        return base
    assert ( img.get_rect().size == base.get_rect().size )
    base.blit(img, (0,0))
    return base

def Make_Tile(staging_area, screen, tile_name, flags, autogen_data):

    sz = library.BASIC_TILE_SIZE

    screen.fill((0,0,0))
    FLAT_COLOUR_TABLE = [ (255,0,0), (0,255,0),
            (0,0,255), (255,0,255), (255,255,0), (0,255,255) ]

    FLAT_COLOUR_TABLE += [ (r/2, g/2, b/2) for
            (r,g,b) in FLAT_COLOUR_TABLE ]
    
    # Make tile
    for is_mask in [ False, True ]:

        def FC(colour):
            if ( is_mask ):
                if ( colour < len(FLAT_COLOUR_TABLE) ):
                    return FLAT_COLOUR_TABLE[ colour ]
                else:
                    return (colour, colour, colour)
            else:
                return None

        colour = 0
        img = Get_Base(FC(colour))
        for (name, rotation) in autogen_data:
            colour += 1
            img = Mix_Image(img, name, rotation, FC(colour))

            if (( name.find('road') >= 0 )
            and ( not is_mask )):
                # dotted line feature merged in for roads
                name += 'line'
                img = Mix_Image(img, name, rotation, FC(colour))

        if (( flags != None ) and ( 's' in flags ) and not is_mask ):
            # Bonus shield
            img = Mix_Image(img, "bonus", 0, None)

        # Resize
        img = pygame.transform.scale(img, (sz, sz))
       

        # Output as BMP
        pygame.image.save(img, "temp.bmp")
        if ( is_mask ):
            screen.blit(img, (30,30))
        else:
            screen.blit(img, (0,0))
        pygame.display.flip()

        # To PNG!
        if ( is_mask ):
            subdir = "tilemasks"
        else:
            subdir = "tilepics"

        out = os.path.join(staging_area, subdir, "%s.png" % tile_name)
        os.system("convert temp.bmp " + out)
        os.unlink("temp.bmp")




#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: sidebar.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# Sidebar module. Controls the sidebar part of the UI. 
# 

import math , pygame
from pygame.locals import *
from pgu import gui

import popup , meeple_graphics , library , resources , constants


EXPIRES_AT = 32 # effect duration (frames)
EXPIRE_FLASH_PERIOD = 16 # in frames

class Sidebar(gui.Widget):
    def __init__(self, (sw, sh), game, cache,
                gui_msg_fn, rules, **params):
        params[ 'width' ] = sw
        params[ 'height' ] = sh
        gui.Widget.__init__(self, **params)

        self.__pgu_update = True
        self.__gui_msg_fn = gui_msg_fn
        self.__refresh = True
        self.__display_menu = None
        self.__zoom_centre = None
        self.__last_fn = None
        self.__game = game
        self.__cache = cache
        self.__rules = rules

        # backing store
        self.__s = pygame.Surface((sw, sh))

        self.__font = resources.Get_Font(12)


        # Design special effects!
        # The effect that appears is a damped oscillation (sine wave)
        self.__effects = []
        self.__effects_surf = None

        def D_Osc(i):
            period = EXPIRE_FLASH_PERIOD
            x = int(math.cos((float(i) * ( 2.0 / float(period) ) * math.pi)) *
                    (( float( EXPIRES_AT - i ) * 250.0 ) / 
                    float(EXPIRES_AT) ))
            assert x < 256
            if ( x < 0 ): return 0
            return x

        self.__fade_table = [ D_Osc(i) for i in xrange(EXPIRES_AT) ]

        # Scoring effects are separate:
        self.__fx_colour = [ i for i in range(250,10,-5) ] 
        self.__fx_queue = [ [] for i in range(0,len(self.__fx_colour)) ]

        self.__meeples = meeple_graphics.Meeple(
                        self.__cache.Get_Size() / 2,
                        rules.Get_Max_Players())
        self.__info = None
        self.__prepared_length = None
    
    # Special effect features:
    # centrally controlled by the sidebar.
    # Actual effects are drawn by window graphics controllers.

    def __Get_Effect_Info(self):
        return [ (tx,ty,c,self.__fade_table[ expiry ])
                    for ((tx,ty,c),expiry,can_expire) in self.__effects ]

    def Not_AFK(self):
        # The user is here! Effects can expire.
        self.__effects = [ (data,expiry,True) 
                for (data,expiry,can_expire) in self.__effects ]

    def __Expire_Effects(self):
        n = len(self.__effects)
        c = 5 # artificial ceiling on number of effects to avoid Madness and Confusion
        if ( n > c ):  
            self.__effects = self.__effects[-c:]

        l = []
        for (data,expiry,can_expire) in self.__effects:
            expiry += 1 
            if ( not can_expire ):
                expiry = expiry % EXPIRE_FLASH_PERIOD
                l.append((data,expiry,can_expire))
            elif ( expiry < EXPIRES_AT ):
                l.append((data,expiry,can_expire))
        self.__effects = l


    def Add_Effects(self,(tx,ty),player_colour):
        self.__effects.append(((tx,ty,player_colour),0,False))


    def Get_Next_Effect(self):
        scoring_fx = []
        if ( len(self.__fx_queue) != 0 ):
            next = [ ((effect_draw_list,score,level), self.__fx_colour[ level ])
                for (effect_draw_list,score,level) in self.__fx_queue[ 0 ] ]
            self.__fx_queue.pop(0)
            self.__fx_queue.append([])
            scoring_fx = next

        flashing_fx = self.__Get_Effect_Info()
        return (scoring_fx, flashing_fx)




    # Regular pulse
    def Tick(self):
        assert self.__game != None
        self.__Expire_Effects()
        self.__Menu_Update()

        update_flag = False
        if ( self.__game.Get_Update_Flag() ):
            #print 'GCF true due to __game.Update_Flag()'
            self.__refresh = True
            update_flag = True
        
        elif ( self.__game.Have_Statistics_Changed() ):
            #print 'GCF true due to Stats Change'
            self.__refresh = True
        
        fx_list = self.__game.Get_Special_Effects()

        new_tile_list = self.__game.Get_New_Tiles()

        if (( not update_flag )
        and ( len(new_tile_list) == 0 )
        and ( len(fx_list) == 0 )): 
            pass
        else:
            # Update necessary!
            for ((tx,ty),(tn,r),player_num,finalised) in new_tile_list:
                c = library.Get_Colour_For_Player(player_num)
                # New tiles flash on area2
                if ( self.__game.Not_Local_Player(player_num) ):
                    self.Add_Effects((tx,ty),c)

            for (fx,score) in fx_list:
                for i in range(0,len(self.__fx_queue)):
                    self.__fx_queue[i].append((fx,score,i))
            #print 'GCF true due to Special Effects'
            self.__refresh = True


    # The multipurpose region (area 2) may contain any of the following:...
    def Draw_Nothing(self):
        if ( self.__info == None ):
            return
        me = self.Draw_Nothing
        if ( self.__last_fn == me ):
            # Repeated sequential calls have no effect.
            # This is done to prevent constant refresh during popup
            # activity.
            return 
        self.__last_fn = me
        self.__info.Draw_Nothing()
        #print 'GCF true due to Nothing'
        self.__refresh = True

    def Draw_Tooltip(self, text):
        if ( self.__info == None ):
            return
        me = (self.Draw_Tooltip, text)
        if ( self.__last_fn == me ):
            return # See above
        self.__info.Draw_Tooltip(text)

    def Draw_Region_Stats(self, stats_display, empty_text="Empty "):
        if ( self.__info == None ):
            return
        me = (self.Draw_Region_Stats, stats_display)
        if ( self.__last_fn == me ):
            return # See above
        self.__last_fn = me
        self.__info.Draw_Region_Stats(stats_display, empty_text)
        #print 'GCF true due to Region Stats Update'
        self.__refresh = True

    def Draw_Tile_Stats(self,example_tiles,tiles_remaining):
        if ( self.__info == None ):
            return
        me = (self.Draw_Tile_Stats, example_tiles, tiles_remaining)
        if ( self.__last_fn == me ):
            return # See above
        self.__last_fn = me
        self.__info.Draw_Tile_Stats(example_tiles,tiles_remaining)
        #print 'GCF true due to Tile Stats Update'
        self.__refresh = True

    def __Menu_Update(self):
        dm = self.__game.Get_Display_Menu()

        if ( dm != self.__display_menu ):
            #print 'GCF true due to Menu_Update'
            self.__refresh = True
            self.__display_menu = dm

    def Get_Zoom_Centre(self):
        if ( self.__display_menu == None ): # for now
            # No zoom window.
            pass
        else:
            pd = self.__game.Get_Preview_Drawing()
            if ( pd != None ):
                ((tx,ty),(di,meeple)) = pd
                self.__zoom_centre = (tx,ty)
            return self.__zoom_centre
        return None

    # For UI controller
    def Get_Game_Change_Flag(self):
        return self.__refresh

    def Prepare_Drawing_Surfaces(self, hud_info):
        master = self.__s 
        assert master != None

        margin = constants.SIDEBAR_MARGIN

        half_margin = margin / 2 
        (w, h) = master.get_rect().size

        (x, font_height) = self.__font.size("Test")
        (meeple_height, x) = self.__meeples.Get_Size()
        tile_sz = self.__cache.Get_Size()
    
        # Current tile drawing area:
        r1 = Rect(half_margin, half_margin, w - margin, tile_sz + margin)
        self.__tile_surface = master.subsurface(r1)
        self.__tile_rect = Rect(0, 0, tile_sz, tile_sz)
        self.__tile_rect.center = self.__tile_surface.get_rect().center

        # Game status area:
        r1.top = r1.bottom + margin
        r1.height = font_height
        self.__status_surface = master.subsurface(r1)

        # Score summary area:
        r1.top = r1.bottom + margin
        score_size = meeple_height + font_height
        r1.height = ( len(hud_info) * score_size ) + ( margin * 2 )
        self.__score_summary_surface = master.subsurface(r1)

        # Information area:
        r1.top = r1.bottom + margin
        r1.height = ( h - r1.top ) - margin
        self.__information_surface = master.subsurface(r1)
        r1 = r1.inflate(margin * -2, margin * -2)

        self.__info = popup.Popup(self.__meeples, 
                    self.__rules, self.__cache, 
                    library.colours.sidebar_scorebox_bg,
                    r1.size)
        self.__all_bordered_surfaces = [
                self.__information_surface, self.__score_summary_surface,
                self.__tile_surface ]


    # Global drawing function
    def Draw(self):
        assert self.__game != None

        self.__pgu_update = True
        margin = constants.SIDEBAR_MARGIN

        # Get game information
        hud_info = self.__game.Get_Player_HUD_Info()
        if ( len(hud_info) != self.__prepared_length ):
            # Drawing surface sizes have changed: recalculate.
            self.Prepare_Drawing_Surfaces(hud_info)
            self.__prepared_length = len(hud_info)

        # Clear drawing area
        library.Edge_Bevel_Effect(self.__s,
                library.colours.sidebar_bg, 
                library.colours.sidebar_edge_gamma)

        for s in self.__all_bordered_surfaces:
            library.Edge_Bevel_Effect(s,
                    library.colours.sidebar_scorebox_bg, 
                    - library.colours.sidebar_edge_gamma)

        # Draw current tile:
        ctname = self.__game.Get_Current_Tile_Name()
        if ( ctname != None ):
            r = self.__tile_rect
            tile_graphs = self.__cache.Get(ctname)
            tile_graphs.Draw(self.__tile_surface,r.left,r.top,0)

        # Draw game status:
        current_name = None # Derive current player name first
        for (name, number, score, meeples, info) in hud_info:
            if ( number == self.__game.Get_Current_Player() ):
                current_name = name

        if ( current_name != None ):
            num_left = self.__game.Get_Num_Remaining_Tiles()
            if ( num_left == 1 ):
                plural = ""
            else:
                plural = "s"
            txt = "%s's turn - %u tile%s left" % (current_name ,
                                    num_left, plural) 

            c = library.colours.turn_announcer
            s = self.__font.render(txt, True, c)
            r = s.get_rect()
            r.center = self.__status_surface.get_rect().center
            self.__status_surface.blit(s, r.topleft)

        # Draw score summary:
        (mh, mw) = self.__meeples.Get_Size()

        r = self.__score_summary_surface.get_rect()
        x = ( constants.EDGE_BEVEL_EFFECT_MARGIN + 2 )
        r = r.inflate(-x, -x)
        self.__score_summary_surface.set_clip(r)
        y = margin
        for (name, number, score, meeples, info) in hud_info:
            current = ( number == self.__game.Get_Current_Player() )

            c = library.Get_Colour_For_Player(number, True)

            # Don't try to make info into anything else. 
            assert type(info) == str
            txt = name + " " + info
            s = self.__font.render(txt, True, c)
            self.__score_summary_surface.blit(s, (margin, y))
            y += s.get_rect().height

            x = ( mw * 3 ) / 2
            y += mh / 2
            highlight = current

            for m in meeples:
                if ( not m.Is_Placed () ):
                    # Eventually we will examine the meeple type too,
                    # when new meeple types are added,
                    self.__meeples.Draw_Meeple((x,y),number,highlight,
                            self.__score_summary_surface)
                    x += mw

            y += mh / 2
        self.__score_summary_surface.set_clip(
                self.__score_summary_surface.get_rect())

        # Draw multifunction area:
        self.__info.Render(self.__information_surface, (margin, margin))


    def paint(self,s):
        s.blit(self.__s, (0, 0))
        self.__pgu_update = False

    def update(self,s):
        if ( not self.__pgu_update ):
            return []
        self.__pgu_update = False
        s.blit(self.__s, (0, 0))
        return [ self.__s.get_rect() ]

    def resize(self,width=None,height=None):
        return self.__s.get_rect().size





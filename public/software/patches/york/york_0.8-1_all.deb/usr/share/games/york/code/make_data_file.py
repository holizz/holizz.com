#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: make_data_file.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 

import os, sys, pygame, tarfile
import startup, autogen, fig2png, tile_compiler, library, resources
import constants, extra


def Make_Data_File(**params):
    data_file_name = params.get('data_file_name', 'default.dat')
    root_dir = params.get('mod_root', None)
    base_flag = params.get('base', False)
    do_autogen = params.get('autogen', True)
    do_tileset = do_autogen or params.get('use_default_tiles', False)
    add_mod = params.get('add_mod', None)
    dont_cleanup = params.get('dont_cleanup', False)


    pygame.init()
    pygame.font.init()
    screen = pygame.display.set_mode((320, 240))
    pygame.display.set_caption("Data File Builder")

    resources.Initialise(True)
    if ( add_mod != None ):
        rc = resources.Add_Mod(add_mod, False)
        assert rc
    if ( root_dir == None ):
        print 'mod_root parameter must be given.'
        return
    
    startup.Check_Version(False)
    root_dir = os.path.abspath(root_dir)
    staging_area = "STAGING_AREA"
    staging_area = os.path.join(root_dir, staging_area)

    print ''
    print 'York data file maker. Copyright (C) Jack Whitham 2006.'
    print 'Building for York version', library.Version()
    print 'Parameters:'
    for (k, v) in params.iteritems():
        print '   %s = %s' % (k,v)

    data_file_name = os.path.join(root_dir, data_file_name)
    rules_dir = os.path.join(root_dir, 'rules')
    df = tarfile.open(data_file_name, 'w:')

    print '   output =', data_file_name
    print '   staging area =', staging_area
    print ''

    # Prepare staging area
    os.chdir(root_dir)

    def Clean_Staging():
        library.RM_Minus_R(staging_area)

    Clean_Staging()
    os.mkdir(staging_area)
    os.mkdir(os.path.join(staging_area, "tilepics"))
    os.mkdir(os.path.join(staging_area, "tilemasks"))

    # Autogen UI images (if this is the base mod)
    if ( base_flag ):
        os.chdir(os.path.join(root_dir, "ui"))
        fig2png.Fig2Png()
        os.chdir(root_dir)
        df.add('ui')

        # Base mod also contains its own Make.py script and README.
        df.add('Make.py')
        df.add('README')

    # Add rules
    try:
        os.chdir(rules_dir)
    except:
        print 'A rules subdirectory must exist, and contain (at a minimum) info.txt.'
        print 'Create the rules dir at', rules_dir
        return

    if ( not os.path.exists('info.txt') ):
        print 'There is no info.txt file for this mod. info.txt is required.'
        print 'Put info.txt in', rules_dir
        return
        
    do_rules = os.path.exists('rules.py')
    tileset_py_exists = os.path.exists('tileset.py')
    do_tileset = do_tileset or tileset_py_exists

    if ( not do_rules ):
        print 'rules.py does not exist, so this is a tileset-only modification.'

    if ( not do_tileset ):
        print 'tileset.py does not exist, and I\'ve not been told to use the default.'
        if ( not do_rules ):
            print 'I am confused. What am I doing?'
            return
        
    df.add('.')
    os.chdir(root_dir)

    # Load initial version, get rules
    df.close()

    def Setup():
        resources.Initialise(True)
        if ( add_mod != None ):
            rc = resources.Add_Mod(add_mod, False)
            assert rc
        rc = resources.Add_Mod(data_file_name, not do_rules)
        assert rc 
        return resources.Get_Rules()

    rules = Setup()

    # If new tiles are defined:
    if ( do_tileset ):
        if ( tileset_py_exists ):
            # Use new tileset
            tileset_file_list = [ resources.Get_Resource_File('tileset.py') ]
        else:
            # Use all tilesets from loaded resource files.
            tileset_file_list = resources.Get_All_Resource_Files('tileset.py')

        # Compile tileset files:
        tileset_programs = []
        for tileset_file in tileset_file_list:
            assert tileset_file != None
            tileset_code = tileset_file.read()
            tileset_file.close()
            tileset_programs.append(compile(tileset_code, 
                        'tileset.py', 'exec'))
        

        print '%d tileset files in use.' % len(tileset_programs)

        if ( do_autogen ):
            os.chdir(root_dir)

            # The autogen part of the work.
            tile_compiler.Tile_Compiler(staging_area, 
                        tileset_programs, rules, True)

            # Add autogen source and output files 
            df = tarfile.open(data_file_name, 'a:')
            df.add('autogen')
            os.chdir(staging_area)
            df.add('tilepics')
            df.add('tilemasks')
        else:
            print 'Using prebuilt image files'

            # Add prebuilt tile image files
            df = tarfile.open(data_file_name, 'a:')
            os.chdir(root_dir)
            df.add('tilepics')
            df.add('tilemasks')

        # Reload this intermediate version
        df.close()
        rules = Setup()

        # Now do tile compilation
        os.chdir(root_dir)
        tile_compiler.Tile_Compiler(staging_area, 
                    tileset_programs, rules, False)

        os.chdir(staging_area)
        df = tarfile.open(data_file_name, 'a:')
        df.add(constants.COMPILED)
        df.close()

    os.chdir(root_dir)
    print ''
    print 'Build complete. MD5 sum:'
    print resources.Get_MD5(data_file_name)

    if ( not dont_cleanup ):
        Clean_Staging()



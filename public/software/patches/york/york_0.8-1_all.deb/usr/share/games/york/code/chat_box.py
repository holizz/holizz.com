#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: chat_box.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# Constructs a little window for entering chat messages.
# 


import library
from pgu import gui

from constants import CHAT_BOX_SIZE


def Make_Chat_Box((sw, sh), chat_options_clicked, send_chat_clicked):
    h = CHAT_BOX_SIZE
    chat_container = gui.Container(width=sw, height=h, valign=1, align=0)
    chat_table = gui.Table(width=sw, height=h,
                background=library.colours.chat_box_bg)
    chat_table.tr()
    if ( chat_options_clicked != None ):
        opt_button = gui.Button("Options")
        opt_button.connect(gui.CLICK, chat_options_clicked, None)
        chat_table.td(opt_button)
        chat_table.td(gui.Spacer(10,1))
    send_button = gui.Button("Send Message")
    send_button.connect(gui.CLICK, send_chat_clicked, None)
    chat_table.td(send_button)
    chat_table.td(gui.Spacer(10,1))
    chat_box = gui.input.Input("", valign=0, align=-1,
            color=library.colours.chat_box_fg, 
            background=library.colours.chat_box_bg, size=60)
    chat_table.td(chat_box)

    chat_container.add(chat_table, 0, 0)

    return (chat_box, chat_container)

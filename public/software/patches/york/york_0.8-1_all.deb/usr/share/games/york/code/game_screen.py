#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: game_screen.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# Container for in-game GUI.
# 


import pygame
import library , tile_graphics , sidebar , support , constants , resources
import game_ui , rules , extra , sound , chat_box , gui_base , message_window
import config , options_gui

from pygame.locals import *
from pgu import gui


# Greetings! You have stumbled upon a todo list..
# 
# Done (at least partly):
#
# User interface and game screen to be merged.
# All components to become PGU widgets.
# This permits scrolling score/tile remaining widget and other
# funky things.
# I've done game_ui (mostly)
# There's this to do, and Sidebar. Sidebar needs to not require the
# game object during startup as Sidebar gets started before the game ui.
# The menu buttons are now real menu buttons.
# Quite a few textures are going to disappear. Think the theme should
# look more professional.
# game_ui may also need a rethink, might have to become a container widget
# to support scrolling of scoreboard and tile list 
# Remaining tiles widget
# Safe detection of network failure conditions.
# Does the scoreboard work properly?
# Progress bar.
# Updates to in-game menu buttons (to fit theme).
# Lobby screen - cosmetic improvements, change of colour theme,
#   weird message box behaviour stands out. (fixed?)
#
# make message window scrollable too! :)
# Percentages! 
# Option dialog
# 
# Todo:
# Ensure correct operation of stacked demos.
# Demo playback - weird behaviour when resuming from a demo (clicking
#   doesn't work properly)
# Introduce Synchronisation screen for use before game begins.
#   Demos should be downloaded during synchronisation.
# Number keys for entering IPs [windows bug]
# Zoom - tick button in zoom window doesn't work. (attempted fix x2)
# Blue on grey is very hard to read. (different set of chat colours)
# First letter of chat seems to get eaten. (??)
# The don't place a meeple button looks like it DOES place a meeple.
#  -- perhaps make these bigger, to also achieve: (attempted resize)
# Rotating tile button... mouse over.
# Hide disabled buttons
# Scoreboard icon needs fixing
# How do Observers show up in game?
# Version checking on connection - with correct error messages.
# Support for game locking: games locked during play and on request in lobby.
# Master server.
# In game host options such as Kick.
# Turn time limit.
# Drawing on board :) Pencil button.
# Finish up.



class Game_Screen(gui_base.Base_GUI):
    def __init__(self, (sw, sh)):
        self.__screen_size = (sw, sh)
        self.__running = True
        self.__full_exit = False
        self.__game_ui = None
        self.__demo_mode = False
        self.__chatbox_focus_hack = 0
        self.__og = options_gui.Options_Generator()
        self.__og.Add_Omnipresent_Options()
        self.__test_mode = False
        self.__mq = None
        gui_base.Base_GUI.__init__(self)

    def Enable_Test_Mode(self):
        self.__test_mode = True

    def Full_Setup(self):
        (sw, sh) = self.__screen_size
        screen_c = gui.Container(width=sw, height=sh,
                background=library.colours.sidebar_bg)

        sidebar_width = ( sw - sh )
        assert sidebar_width > 50
        sidebar_height = ( sh * 13 ) / 16
        ycross = sh - constants.MESSAGE_WINDOW_HEIGHT

        self.__menu_dlg = self.Make_Menu_Dialog()

        game_area_rect = Rect(sidebar_width, 0, sw - sidebar_width, ycross)
        sidebar_rect = Rect(0, 0, sidebar_width, sh)
        self.__game_area_rect = game_area_rect

        self.__sidebar_size = (sidebar_width, sidebar_height)
        self.__sidebar_container = gui.Container(
                width=sidebar_width, height=sidebar_height)
        self.__sidebar = None
        self.__sidebar_buttons = b_t = gui.Table(align=0, valign=0,
                width=sidebar_width, height=sh - sidebar_height)
        b_t.tr()

        def Mode_Change(new_mode): # Mode_Change is a factory
            def Apply_Change(*args): self.Set_Mode_From_Click(new_mode)
            return Apply_Change

        def Demo_Advance(*args):
            self.__game_ui.Demo_Next_Move(False)

        def Hover(widget, text):
            def Hovering(*args):
                if (( self.__sidebar != None )
                and ( not widget.disabled )):
                    self.__sidebar.Draw_Tooltip(text)
            widget.connect(gui.ENTER, Hovering)

        (z_b, c_b, s_b) = support.Picture_Buttons2Table(b_t, 
            [( "ui/zoom.png", Mode_Change(game_ui.MODE_SELECT_ZOOM) ),
            ( "ui/chat.png", 
                    Mode_Change(game_ui.MODE_CHAT) ),
            ( "ui/score.png", 
                    Mode_Change(game_ui.MODE_SCOREBOARD) ) ])
        Hover(z_b, "Zoom in")
        Hover(c_b, "Send chat message")
        Hover(s_b, "See scoreboard")

        b_t.tr()
        (r_b, m_b, n_b) = support.Picture_Buttons2Table(b_t, 
            [( "ui/remain.png",
                    Mode_Change(game_ui.MODE_REMAINING_TILES) ),
            ( "ui/menu.png",
                    Mode_Change(game_ui.MODE_MENU)),
            ( "ui/nextturn.png",
                    Demo_Advance)])
        Hover(r_b, "See remaining tiles")
        Hover(m_b, "Open game menu")
        Hover(n_b, "Advance recording\nby one turn")

        self.__disable_during_demo = [ c_b ]
        self.__disable_during_play = [ n_b ]

        self.__game_area = gui.Container(width=sw - sidebar_width,
                height=ycross)
        (self.__chat_box, self.__chat_c) = chat_box.Make_Chat_Box(
                (( sw - 2 ) - sidebar_width, constants.CHAT_BOX_SIZE), 
                None, self.Send_Chat_Message)
        self.__message_widget = message_window.Message_Window(
                (sw - sidebar_width, constants.MESSAGE_WINDOW_HEIGHT), 
                100000000, True)

        Hover(self.__message_widget, 
                "Messages from other\n"
                "players and the game\n" +
                "appear in this box.")

        screen_c.add(self.__sidebar_container, 0, 0)
        screen_c.add(self.__game_area, sidebar_width, 0)
        screen_c.add(self.__message_widget, sidebar_width, ycross)
        screen_c.add(self.__sidebar_buttons, 0, sidebar_height)

        # Chat box not added to screen at this stage - it is only
        # added when it is visible
        self.__chat_box_location = (sidebar_width + 1, ycross + 1)
        self.__chat_box_visible = False
        self.__screen_c = screen_c

        # Get mouse cursors
        self.__normal_mouse = pygame.mouse.get_cursor()
        self.__zoom_mouse = resources.Depickle("ui/magcursor.dat")
        self.__Set_Mouse(self.__normal_mouse)


        return screen_c


    def Run(self, surf, clock,
            (rules, game_info, client_mq, server_mq),
            demo_playback_stream, resume_from_demo):

        print 'Run called!'
        assert self.__game_ui == None # ensure run only once
        assert self.__sidebar == None
        assert self.__game_area_rect != None

        #self.Set_Updates_Mode(gui_base.UPDATES_MANUAL)
        self.__running = True
        self.__game_info = game_info
        self.__demo_mode = False
        self.__mq = client_mq

        support.Init_Progress_Bar(surf, "Loading tiles...")

        def Load_Progress_Function(x, of_y):
            support.Draw_Progress_Bar(surf, x, of_y)

        try:
            self.__game_ui = game_ui.Game_User_Interface(
                    self.__game_area_rect.size, 
                    clock, (rules, game_info, client_mq, server_mq),
                    self.Message, Load_Progress_Function,
                    Load_Progress_Function,
                    demo_playback_stream)

            support.Init_Progress_Bar(surf, "Loading interface...")

            self.__game = self.__game_ui.Get_Game()
            self.__game_area.add(self.__game_ui, 0, 0)
            self.__sidebar = sidebar.Sidebar(
                    self.__sidebar_size, self.__game, 
                    self.__game_ui.Get_Cache(),
                    self.Message, rules)

            Load_Progress_Function(1, 3)
            self.__sidebar_container.add(self.__sidebar, 0, 0)
            Load_Progress_Function(2, 3)
            self.__game_ui.Register_Sidebar(self.__sidebar)

            support.Init_Progress_Bar(surf, "Preparing game...")


            demo = False
            resume_failed = False
            if ( demo_playback_stream != None ):
                if ( resume_from_demo ):
                    if ( not self.__game_ui.Resume_Game_From_Demo() ):
                        resume_failed = True
                    # The demo has finished now.. we are no longer
                    # in demo mode.
                else:
                    self.__game_ui.Demo_Next_Move(False)
                    self.__game_ui.Demo_Next_Move(False)
                    demo = True
                    self.__game_ui.Send_Ready_If_Master()
                    self.__game_ui.Send_Ready_For_Demo_Playback()
            else:
                self.__game_ui.Send_Ready_If_Master()
            self.__demo_mode = demo

            self.Message("York version %s. Modification: %s" %
                    (library.Version(), resources.Get_Mod_Name()))
            if ( not demo ):
                self.Message("Press Enter to send chat messages.")
            if ( resume_failed ):
                self.Message("Sorry - game resume has failed! This is probably " +
                    "due to a bug in the game, damage to the recording, or " +
                    "playback of a recording from a different version.")

            # Disable menu buttons as appropriate for play mode.
            if ( demo ):
                for b in self.__disable_during_demo:
                    b.disabled = True
            else:
                for b in self.__disable_during_play:
                    b.disabled = True

        except tile_graphics.TGM_Exception, m:
            # XXX More user-friendly exit?
            print "The data file needs recompiling!"
            print str(m)
            raise m

        pygame.mouse.set_visible(True)
        gui_base.Base_Game_Screen.Run(self, surf, clock)
        return not self.__full_exit 

    
    def Tick(self):
        if ( self.__test_mode ):
            self.__game_ui.Demo_Next_Move(False)

        self.__game_ui.Tick()
        self.__game_ui.Draw(False)

        if ( self.__test_mode ):
            if ( self.__game.Is_Game_Over() ):
                self.__Exit()
        


    def Draw_Foreground(self, surf):
        gui_base.Base_GUI.Draw_Foreground(self, surf)

        # focus() must be done after drawing
        if ( self.__chat_box_visible and self.Is_Chatbox_On_Screen() ):
            if ( self.__chatbox_focus_hack == 2 ):
                self.__chat_box.focus()
            self.__chatbox_focus_hack += 1
        else:
            self.__chatbox_focus_hack = 0


    def Clear_Up(self):
        self.__game_ui.Clear_Up()

    def Exit_Condition(self):
        return ( not self.__running ) or self.__game_ui.Exit_Condition()

    def __Set_Mouse(self, set_cursor_data):
        (a,b,c,d) = set_cursor_data
        pygame.mouse.set_cursor(a,b,c,d)
        pygame.mouse.set_visible(True)

    def Set_Mode_From_Click(self, new_mode):
        if ( self.__game_ui.Get_Mode() == new_mode ):
            # already there. go to normal mode.
            self.Set_Mode(game_ui.MODE_NORMAL)
        else:
            self.Set_Mode(new_mode)

    def Set_Mode(self, new_mode):
        if ( self.__game_ui.Get_Mode() != new_mode ):
            if ( self.__game_ui.Get_Mode() == game_ui.MODE_SELECT_ZOOM ):
                self.__Set_Mouse(self.__zoom_mouse)
            else:
                self.__Set_Mouse(self.__normal_mouse)

            self.__game_ui.Set_Mode(new_mode)

            if ( self.Is_Chatbox_On_Screen() ):
                self.Chat_Box_Popup(True)
            else:
                self.Chat_Box_Popup(False)

            if ( self.Is_Menu_On_Screen() ):
                self.__menu_dlg.open()
            else:
                self.__menu_dlg.close()


    def Is_Menu_On_Screen(self):
        return ( self.__game_ui.Get_Mode() == game_ui.MODE_MENU )

    def Is_Chatbox_On_Screen(self):
        return ( self.__game_ui.Get_Mode() == game_ui.MODE_CHAT )

    def Send_Chat_Message(self, *args):
        if (( len(self.__chat_box.value) > 0 )
        and self.Is_Chatbox_On_Screen() ):
            self.__game.Send_Chat_Message(self.__chat_box.value)
            self.__chat_box.value = ""
            self.__chat_box.repaint()
        self.Set_Mode(game_ui.MODE_NORMAL)

    def Event(self,e):
        if ( self.Is_Menu_On_Screen() ):
            if ( e.type == KEYDOWN ):
                if ( e.key == K_ESCAPE ):
                    self.Set_Mode(game_ui.MODE_NORMAL)
                    return

        elif ( self.Is_Chatbox_On_Screen() ):
            if ( e.type == KEYDOWN ):
                if ( e.key == K_RETURN ):
                    self.Send_Chat_Message()
                    return

        if ( e.type == KEYDOWN ):
            if ( e.key == K_ESCAPE ):
                self.Set_Mode(game_ui.MODE_MENU)
                # Don't let ESCAPE be handled elsewhere!
                # It means cancel, i.e. close game.
                return
            elif ( e.key == K_RETURN ):
                self.Set_Mode(game_ui.MODE_CHAT)
            elif ( e.key == K_SPACE ):
                self.__game_ui.Demo_Next_Move(False)

        gui_base.Base_GUI.Event(self, e)

    def Message(self, msg, colour=(255, 255, 255)):
        self.__message_widget.Message(msg, colour)
        self.__message_widget.repaint()

    def Chat_Box_Popup(self, shown):
        shown = shown and not self.__demo_mode
        if ( self.__chat_box_visible != shown ):
            print 'chat box state change',shown
            if ( shown ):
                (x, y) = self.__chat_box_location
                self.__screen_c.add(self.__chat_c, x, y)
            else:
                self.__screen_c.remove(self.__chat_c)
                self.__message_widget.repaint()

            self.__chat_box_visible = shown


    def Quit(self,value=None):
        self.__Exit()

    def __Exit(self, arg=None):
        self.__running = False

    def __Full_Exit(self, arg=None):
        self.__Exit()
        self.__full_exit = True

    def __Close_Menu(self, *args):
        self.__og.Press_Apply()
        self.__menu_dlg.close()
        self.Set_Mode(game_ui.MODE_NORMAL)

    def Make_Menu_Dialog(self):
        margin = 15
        menu_table = gui.Table(align=0, valign=0)
        menu_table.tr()
        menu_table.td(gui.Label("York", cls="h1"))
        menu_table.tr()
        menu_table.td(gui.Label(resources.Get_Mod_Name()))

        def Spacer():
            menu_table.tr()
            menu_table.td(gui.Spacer(width=1, height=margin))

        def Make_Button(text, function):
            Spacer()
            menu_table.tr()
            b = gui.Button(text)
            b.connect(gui.CLICK, function, None)
            menu_table.td(b)
     
        Spacer()
        menu_table.tr()
        menu_table.td(self.__og.Get_Table())

        Make_Button("Return to Game", self.__Close_Menu)
        Make_Button("Exit to Menu", self.__Exit)
        Make_Button("Exit to " + extra.Get_OS(), self.__Full_Exit)

        container = gui.Table() #width=w, height=h)
        container.tr()
        container.td(gui.Spacer(width=margin, height=1), rowspan=3)
        container.td(gui.Spacer(width=1, height=margin))
        container.td(gui.Spacer(width=margin, height=1), rowspan=3)
        container.tr()
        container.td(menu_table)
        container.tr()
        container.td(gui.Spacer(width=1, height=margin))

        return gui.Dialog(gui.Label("Game Menu"), container)

    def Test_Get_Player_Objects(self):
        return self.__game_ui.Test_Get_Player_Objects()



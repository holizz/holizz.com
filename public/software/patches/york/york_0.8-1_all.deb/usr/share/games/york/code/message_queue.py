#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: message_queue.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# Message_Queue is the thread-safe internal mail system for this game.
# Each Client and Server is a type of Message_Queue. 

import threading , time , random , collections
import library , extra


END_OF_TURN_MESSAGE = "eot marker"
KICK_MESSAGE = "low level kick"

class Message_Queue:
    def __init__(self):
        self._lock = threading.Semaphore()
        self._change_lock = threading.Condition()
        self._change_flag = 0
        self._queue_out = dict()
        self._master_inbox = collections.deque()
        self._allow_new_players = True

        self.__id_records = dict()
        self.__id_set = set([])

    class ID_Record:
        pass


    # These functions access the message queues that are bound
    # to particular network connections. They are called from the
    # Connection_Servlet class.
    def Net_Add(self,sender_id,msg):
        msg = extra.Launder_Message(msg)
        if (( msg == "" ) or ( msg == None )):
            return

        self._lock.acquire()
        if ( not self._queue_out.has_key( sender_id ) ):
            print "Discarded message from unknown sender",sender_id
        else:
            self._master_inbox.append((msg,sender_id))
            self.Signal_Change()
        self._lock.release()

    def Net_Remove(self,receiver_id):
        msg = None
        self._lock.acquire()
        if ( not self._queue_out.has_key( receiver_id ) ):
            # Already kicked. Repeat message.
            msg = KICK_MESSAGE
        else:
            q = self._queue_out[ receiver_id ]
            if ( len(q) != 0 ):
                msg = q.popleft()
                if ( msg == KICK_MESSAGE ):
                    self.__IM_Remove_ID(receiver_id)

        self._lock.release()
        return msg

    # Bypasses normal id checks and laundry. 
    # Used by demo playback engine.
    def Poke_Event(self, (msg, sender_id)):
        self._lock.acquire()
        self._master_inbox.append((msg, sender_id))
        self._lock.release()
        self.Signal_Change()

    # Internal message functions. These are called from Connection_Servlet -
    # they manipulate the message queue in ways that must not be accessible
    # across the network.
    def IM_Remove_ID(self,host_id):
        self._lock.acquire()
        self.__IM_Remove_ID(host_id)
        self._lock.release()

    def IM_Register_ID(self, host_id, info, user_name):
        ok = False
        name = user_name = library.Launder_Player_Name(user_name)
        self._lock.acquire()
        if ((( not self.Is_Server() ) or self._allow_new_players )
        and ( not self.__id_records.has_key( host_id ) )):
            ok = True
            self._queue_out[ host_id ] = collections.deque()

            # Generation of unique name:
            hit = True
            added = 1
            while hit:
                name = user_name
                if ( added > 1 ):
                    name += "%u" % added
                hit = False
                for id in self.__id_set:
                    idr = self.__id_records[ id ]
                    if ( idr.user_name == name ):
                        hit = True
                        added += 1
                        break
           
            self.__id_set |= set([host_id])
            self.__id_records[ host_id ] = idr = self.ID_Record()

            idr.id = host_id
            idr.info = info
            idr.user_name = name

            self.Signal_Change()
        print 'Register ID: %u %s ok=%u svr=%u' % (host_id, name, ok,
                self.Is_Server())
        self._lock.release()
        return ok

    def __IM_Remove_ID(self,host_id):
        if ( self._queue_out.has_key ( host_id ) ):
            if ( self.__id_records.has_key( host_id ) ):
                del self.__id_records[ host_id ]
                self.__id_set -= set([ host_id ])
            del self._queue_out[ host_id ]

            self.Signal_Change()
        else:
            print "Can't remove unknown ID",host_id,"-- nothing happens"

    # These functions access the global message queue.
    def Send(self,msg,not_to=set([])):
        self._lock.acquire()
        for id in self.__id_set - not_to:
            self._queue_out[ id ].append(msg)
        self._lock.release()

    def Send_To_Only(self,msg,to):
        self._lock.acquire()
        for id in to:
            if ( self._queue_out.has_key( id ) ):
                self._queue_out[ id ].append(msg)
        self._lock.release()

    def Receive(self):
        self._lock.acquire()
        if ( len(self._master_inbox) == 0 ):
            msg_and_sender_id = None
        else:
            msg_and_sender_id = self._master_inbox.popleft()
        self._lock.release()
        self.Demo_Hook(msg_and_sender_id)
        return msg_and_sender_id

    def Wait_And_Receive(self):
        r = self.Receive()
        if ( r != None ):
            return r

        # No message? Wait for one.
        self.__Wait_Event()

        return self.Receive()

    def Demo_Hook(self, msg_and_sender_id):
        # Subclassable!
        pass

    def Demo_Play_Event(self, *args):
        # Also subclassable. Returns False if there is more demo to play.
        return True

    # These functions only work correctly for the message queue on the server.
    def Get_ID_List(self):
        assert self.Is_Server()
        self._lock.acquire()
        p = [ id for id in self.__id_set ]
        self._lock.release()
        return p

    def Allow_New_Players(self,ok):
        assert self.Is_Server()
        self._lock.acquire()
        self._allow_new_players = ok
        self._lock.release()

    def Kick_ID(self,id):
        assert self.Is_Server()
        self.Send_To_Only(KICK_MESSAGE, [ id ])

    def Is_Open(self):
        # This has no meaning for a client
        assert self.Is_Server()
        self._lock.acquire()
        a = self._allow_new_players
        self._lock.release()
        return a

    def Get_ID_Record(self, id):
        assert self.Is_Server()
        idr = None
        self._lock.acquire()
        if ( self.__id_records.has_key( id ) ):
            idr = self.__id_records[ id ]
        self._lock.release()
        # Note: id records are immutable once created,
        # so it is possible for them to leave the critical section.
        return idr

    def Get_Name(self, id):
        idr = self.Get_ID_Record(id)
        if ( idr == None ):
            return "? UnknownID"
        else:
            return idr.user_name

    # This function only works correctly for a client.
    def Wait_For_Establish(self):
        assert not self.Is_Server()
        if ( (( self.Get_ID() == None )
            or ( self.Get_ID() <= 0 ))
        and ( self.Is_Ok() )):
            # wait for a connection
            self.__Wait_Event()
            return True # still waiting
        else:
            return False # stop!
       

    # This is used to interrupt Wait_And_Receive from another thread.
    def Signal_Change(self):
        self._change_lock.acquire()
        self._change_flag = 1
        self._change_lock.notify()
        self._change_lock.release()

    def __Wait_Event(self):
        self._change_lock.acquire()
        while ( not self._change_flag ):
            self._change_lock.wait()
        self._change_flag = 0
        self._change_lock.release()

    # Used for internal sanity checking
    def Is_Server(self):
        return 0

    # Defined by descendants
    def Get_ID(self):
        return None

    def Stop(self):
        pass

    def Get_State(self):
        return None

    def Is_Empty(self):
        assert False, "please do not call this function again"

    def Get_Inbox_Size(self):
        if ( not self.Is_Ok() ):
            return True

        self._lock.acquire()
        c = len(self._master_inbox)
        self._lock.release()
        return c



#!/usr/bin/python2.4
#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# 
# 
# Top-level data file maker for York. Builds 'base.dat' from source.
# If you want to build a data file for a modification, you use a subset
# of the same process, provided by Make_Data_File. See example modifications
# for details.

import os, sys

base = os.path.abspath(os.path.join(os.getcwd(), '..'))
sys.path.insert(0, base)

try:
    import York
except:
    print 'Run Make.py from the resource builder directory.'
    sys.exit(0)

York.Paths(base)

import make_data_file

os.chdir(base)

if ( __name__ == "__main__" ):
    make_data_file.Make_Data_File(data_file_name='base.dat', 
                base=True, mod_root=os.path.join(base, 'resource_builder'))


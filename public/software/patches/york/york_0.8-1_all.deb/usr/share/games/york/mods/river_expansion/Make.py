#!/usr/bin/python2.4
#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# 
# 
# Sample data file maker for 'River Expansion' mod.

import os, sys

# base finds the main York directory.
base = os.path.abspath(os.path.join(os.getcwd(), '..', '..'))
sys.path.insert(0, base)
mod_dir = os.getcwd()

try:
    import York
except:
    print 'Run Make.py from the mod directory.'
    sys.exit(0)

York.Paths(base)

import make_data_file

os.chdir(base)

if ( __name__ == "__main__" ):
    make_data_file.Make_Data_File(data_file_name='river_expansion.dat', 
                mod_root=mod_dir)


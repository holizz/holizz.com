#!/usr/bin/python2.4
# Main program. Run this in order to play. Please see README.txt
# for more information.
# 
# York is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
#

def Paths(base):
    import sys, os

    base = os.path.abspath(base)
    sys.path.insert(0, os.path.join(base, 'pgu-0.10.3'))
    sys.path.insert(0, os.path.join(base, 'code'))


if ( __name__ == "__main__" ):
    import sys, os

    Paths(os.path.dirname(sys.argv[ 0 ]))


    try:
        import startup
    except:
        print "Please run the program from the game directory."
        sys.exit(1)

    startup.Main()


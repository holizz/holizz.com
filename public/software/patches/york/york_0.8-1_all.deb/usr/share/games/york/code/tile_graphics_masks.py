#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: tile_graphics_masks.py,v 1.1 2006/08/09 19:59:13 jack Exp jack $
# 
# Tile graphics masks. These are used for region highlighting. Calculating the
# masks is a slow process, so they are compiled and stored within the game data
# files. This module contains code to compile the masks (used offline) and load 
# them (used during the game). Compiled masks are mixtures of PNG data and
# pickled information.
# 


import pygame , pickle , os
import library , resources , extra

from constants import COMPILED
from constants import TGM_VERSION


class TGM_Pickle:
    pass

class TGM_Exception(Exception):
    pass


class Tile_Graphics_Masks:
    def __init__(self):
        self._graphics_region_mask = []
        self._region_table = None
        self._region_centre = None
        self._graphics_region_edge = None
        self.__initial_palette = [(0,0,0)] + [ 
                        (255,255,255) for i in range(1,256) ]
    
    def Is_Ok(self):
        return self.Get_Num_Regions() != 0


    def Load(self, name):
        # Invalidate class during load
        self._graphics_region_mask = []

        # Get pickled header data:
        v = None
        try:
            dat = resources.Depickle("%s/%s.tgm" % (COMPILED, name))
            v = dat.version
        except Exception, x:
            raise TGM_Exception(
                'TGM file for tile %s not loaded. More:\n%s' % 
                        (name, str(x)))

        if ( not self.__Is_Compatible(v) ):
            raise TGM_Exception(
                'TGM file for tile %s is incompatible version (%u).' %
                        (name, str(v)))

        self._region_table = dat.region_table
        self._region_centre = dat.region_centre
        self._graphics_region_edge = dat.graphics_region_edge
        grm = []
        msz = library.BASIC_TILE_SIZE

        # Load masks (now in PNG format).
        for i in xrange(dat.num_bitmaps):
            fname = "%s/%s.%u.png" % (COMPILED, name, i)
            try:
                # Note: bypass image caching - not needed here.
                n1 = pygame.image.load(resources.Get_Resource_File(fname))
            except Exception, x:
                raise TGM_Exception(
                    'Tile graphics mask %s load error. More:\n%s' %
                            (fname, str(x)))

            if ( n1.get_rect().width != msz ):
                raise TGM_Exception(
                    'Tile graphics mask %s size error (%u, not %u).' %
                            (fname, n1.get_rect().width, msz))

            n1.set_colorkey((0,0,0))
           
            # Turn mask into a native 8 bit surface:
            n = pygame.Surface((msz, msz), 0, 8)
            n.set_palette(self.__initial_palette)
            n.fill((0, 0, 0))
            n.blit(n1, (0, 0))
            n.set_colorkey((0,0,0))
            grm.append(n)

        self._graphics_region_mask = grm
        return True

    def __Is_Compatible(self, other_version):
        return ( other_version == TGM_VERSION )

    def Save(self, name):
        path = COMPILED
        for (i, surf) in enumerate(self._graphics_region_mask):
            # Save in BMP format then convert
            fname = os.path.join(path, "%s.%u.png" % (name, i))
            print "Writing mask:", fname
            surf.set_palette(self.__initial_palette)
            pygame.image.save(surf, "tmp.bmp")
            extra.Convert('tmp.bmp', fname, '')
            os.unlink('tmp.bmp')

        fname = os.path.join(path, "%s.tgm" % name)
        print "Writing header:",fname
        header = file(fname, "wb")
        dat = TGM_Pickle()
        dat.version = TGM_VERSION
        dat.region_table = self._region_table
        dat.region_centre = self._region_centre
        dat.graphics_region_edge = self._graphics_region_edge
        dat.name = name
        dat.num_bitmaps = len(self._graphics_region_mask)
        pickle.dump(dat, header)
        header.close()
        print "Done image",name


    def Get_Num_Regions(self):
        return len(self._graphics_region_mask)

    def Get_Graphics_Region_Mask(self,gr):
        return self._graphics_region_mask[gr]

    def Get_Graphics_Regions_For_Edge(self,e):
        return self._graphics_region_edge[e]

    def Get_Graphics_Region_For_Point(self,mx,my):
        st = len(self._region_table)
        [x,y] = [ ((i * st) / library.BASIC_TILE_SIZE) for i in [mx,my] ]

        assert 0 <= x < st
        assert 0 <= y < st

        return self._region_table[y][x]

    def Get_Centre_Of_Graphics_Region(self,gr):
        return self._region_centre[gr]



    def Build_From(self,mask_surface,highlight_margin):
       
        print "Building region masks..."

        msz = library.BASIC_TILE_SIZE
        sample = 2
        reduced_range = range(msz/4,msz-(msz/4))
        mask_surface = pygame.transform.scale(mask_surface, 
                            (msz, msz))  # XXX .convert(8)

        region = dict ()
        region_array = dict ()
        counter = dict ()
        region_number = dict ()
        colour_list = []

        # Examination of mask data
        print "Examine data:"
        for y in range(0,msz):
            for x in range(0,msz):
                colour = mask_surface.get_at((x,y))
                if ( not counter.has_key(colour) ):
                    counter[ colour ] = 0
                    n = pygame.Surface((msz,msz),0,8)
                    n.fill(0)
                    n.set_palette(self.__initial_palette)
                    n.set_colorkey((0,0,0))
                    region[ colour ] = n
                    colour_list.append(colour)
                counter[ colour ] += 1
                region[ colour ].set_at((x,y),1)

        # Elimination of minor colours (introduced as noise during masking)
        #threshold = ( msz * msz ) / 100
        mask_list = []
        for colour in colour_list:
            #if ( counter[ colour ] > threshold ):
                region_number[ colour ] = len(mask_list)
                mask_list.append(region[ colour ])

        print "Edging effect...."

        # Apply region edging effect (optional, just a matter of vanity)
        mask_list = [ 
            library.Edge_Expansion_Effect(mask,len(highlight_margin)) 
            for mask in mask_list ]

        print "Edge detection...."
        # Edge computations
        self._graphics_region_edge = []
        edges = []
        edges.append([ mask_surface.get_at((x,0)) for x in reduced_range ])
        edges.append([ mask_surface.get_at((msz-1,x)) for x in reduced_range ])
        edges.append([ mask_surface.get_at((msz-(1+x),msz-1)) for x in reduced_range ])
        edges.append([ mask_surface.get_at((0,msz-(1+x))) for x in reduced_range ])
        for edge in edges:
            colour = edge.pop(0)
            edge_rle = []
            while len(edge) != 0:
                next = edge.pop(0)
                if ( next != colour ):
                    edge_rle.append(colour)
                    colour = next
            edge_rle.append(colour)

            edge_rle_2 = []
            for colour in edge_rle:
                if (region_number.has_key(colour)):
                    edge_rle_2.append(region_number[colour])
            self._graphics_region_edge.append(edge_rle_2)

        print "Lookup table...."
        # Simplification of mask area to a quick lookup table
        self._region_table = []
        rc = [ [0,0,0] for i in mask_list ]
        for y in range(0,msz,sample):
            line = []
            last = -1
            for x in range(0,msz,sample):
                colour = mask_surface.get_at((x,y))
                if ( region_number.has_key(colour) ):
                    last = region_number[ colour ]
                line.append(last)
                if ( last != -1 ):
                    rc[ last ][ 0 ] += x
                    rc[ last ][ 1 ] += y
                    rc[ last ][ 2 ] += 1
            self._region_table.append(line)
    
        # Centre of each region is identified by mean average over 
        # the set of points occupied by the region
        self._region_centre = []
        for (reg_num, [x, y, count]) in enumerate(rc):
            if ( count == 0 ):
                count = 1
            # Get the centre:
            (x, y) = avg_centre = (int(x / count), int(y / count))

            # But that centre might be inside another region!
            # If that happens, move in all four directions simultaneously
            # until we reach the correct region..

            ok = False
            for i in xrange(0, msz, sample):
                for (xi, yi) in [ (x + i, y), (x - i, y),
                                (x, y - i), (x, y + i) ]:
                    if (( 0 <= xi < msz )
                    and ( 0 <= yi < msz )
                    and ( self.Get_Graphics_Region_For_Point(xi, yi) 
                                    == reg_num )):
                        (x, y) = (xi, yi)
                        ok = True
                        break

                if ( ok ):
                    break

            if ( not ok ):
                # We couldn't find a good place for the region centre.
                # We'll have to use the default.
                (x, y) = avg_centre
            
            self._region_centre.append((x, y))

        print "Complete"
        # Finished
        self._graphics_region_mask = mask_list
    




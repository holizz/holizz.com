# 
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: whitelist.py,v 1.2 2006/08/09 21:25:46 jack Exp $
#

# Modifications whose MD5 sums are listed in the whitelist are
# always trusted by the game. These are all official mods distributed
# by myself.

def Make_Whitelist():
    return set([ "d03503720ef7a67aa180032365e74a1d", # base.dat 
            "b13351cec4c1ec82e1812e84e8b5cb4a" # river expansion
            ])



#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: gui_base.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# Container for all game screens. Acts as an interface between PGU and York.
# If anything here replicates something in PGU, it is because I
# have an incomplete understanding of PGU.
# 

import pygame, threading, time, os, collections, sys, traceback
import library, rules, extra, chat_box, resources, main
import message_window

from pygame.locals import *
from pgu import gui

MSG_FADE_TIME = 2


[ UPDATES_MANUAL, UPDATES_TRIGGERED , 
        UPDATES_TRIGGERED_AFTER_EVENTS ] = range(3)


class Base_Game_Screen:
    def __init__(self):
        self.__updates_mode = UPDATES_MANUAL
                
    def Message(self, msg, colour=(200,200,200)):
        print 'Unhandled message:',msg

    def General_Update(self):
        self.__general_update = True

    def Set_Updates_Mode(self, um):
        self.__updates_mode = um

    def Run(self,surf,clock):
        devparm = ( "--deframe" in sys.argv )
        last_tick = None
        self.General_Update()
        self.Draw_Background(surf)
        # Note: Draw_Background calling logic changed.
        

        while not self.Exit_Condition():
            self.Tick()

            if (( self.__updates_mode == UPDATES_MANUAL )
            or ( self.__general_update )):
                self.Draw_Foreground(surf)
                self.__general_update = False

            if ( devparm ):
                # Frame rate 'VU' meter
                tick = time.time()
                if ( last_tick != None ):
                    pygame.draw.rect(surf, (0, 0, 0), Rect(0, 0, 550, 5))
                    for x in xrange(50, 550, 50):
                        pygame.draw.line(surf, (0, 255, 0), (x, 0), (x, 5))

                    x = int((tick - last_tick) * 1000.0)
                    assert x >= 0
                    if ( x > 550 ):
                        x = 550
                    pygame.draw.rect(surf, (120, 0, 0), Rect(0, 0, x, 5))
                    pygame.draw.rect(surf, (255, 255, 0), Rect(x, 0, 5, 5))

                last_tick = tick
            pygame.display.flip()
            clock.tick(40)

            if ( self.__updates_mode == UPDATES_TRIGGERED_AFTER_EVENTS ):
                e = pygame.event.wait()
            else:
                e = pygame.event.poll()

            while ( e.type != NOEVENT ):
                self.Event(e)
                e = pygame.event.poll()

        self.Clear_Up()

    def Clear_Up(self):
        pass

    # Override these functions as necessary:
    def Draw_Background(self,surf):
        main.Draw_Menu_Back(surf, False)

    def Draw_Foreground(self,surf):
        pass

    def Event(self,e):
        pass

    def Tick(self):
        pass

    def Exit_Condition(self):
        return True

class PGU_Theme(gui.Theme):
    def decorate(self, widget, level):
        if ( level == True ):
            #widget.style.color = library.colours.pgu_fg
            #widget.style.background = library.colours.pgu_bg
            pass
        gui.Theme.decorate(self, widget, level)


class Base_App(gui.App):
    def __init__(self,qf,**params):

        # gui/york contains override settings for the PGU theme.

        params.setdefault('theme', PGU_Theme([
            os.path.join("gui", "york"), 
            os.path.join("gui", "gray")]))
        gui.App.__init__(self, **params)
        self.__qf = qf

    def quit(self,value=None):
        # Don't actually quit! Just signal an exit.
        self.__qf(value)

class Base_GUI(Base_Game_Screen):
    def __init__(self,**params):
        Base_Game_Screen.__init__(self)
        self.__app = Base_App(self.Quit,**params)
        self.__app.connect(gui.QUIT,self.__app.quit,None)
        self.__app.init(self.Full_Setup())

    def Full_Setup(self):
        [title,ok,cancel] = self.Get_Strings()

        container1 = gui.Container(align=0,valign=0,
                    width=self.MENU_WIDTH,height=self.MENU_HEIGHT)
        container2 = gui.Container(align=0,valign=0)

        container2.resize(height=self.MENU_MAIN_AREA_HEIGHT)

        table1 = gui.Table(align=0,valign=0)
        table1.tr()
        table1.td(gui.Label(title,cls="h1",color=library.colours.title_colour),colspan=3)
        table1.tr()
        table1.td(gui.Spacer(width=self.MENU_WIDTH,height=5),colspan=3)
        table1.tr()
        table1.td(container2,colspan=3,align=0,valign=0,height=self.MENU_MAIN_AREA_HEIGHT)
        table1.tr()
        table1.td(gui.Spacer(width=self.MENU_WIDTH,height=5),colspan=3)
        table1.tr()

        if (( ok != None ) and ( len(ok) != 0 )):
            b = gui.Button(ok,
                width=self.MENU_BUTTON_SIZE,height=self.MENU_BUTTON_SIZE)
            b.connect(gui.CLICK,self.__Press_Ok,None)
            self._ok_button = b
        else:
            b = gui.Spacer(width=self.MENU_BUTTON_SIZE,height=self.MENU_BUTTON_SIZE)
            self._ok_button = None

        table1.td(b,align=-1)
        table1.td(gui.Spacer(width=1,height=1))

        if ( cancel != None ):
            b = gui.Button(cancel,
                width=self.MENU_BUTTON_SIZE,height=self.MENU_BUTTON_SIZE)
            b.connect(gui.CLICK,self.__Press_Cancel,None)
            table1.td(b,align=1)
            table1.tr()

        self.__quit_flag = 0
        self.__rc = self.SEL_NONE
        container1.add(table1,0,0)

        self.Setup(container2)
        return container1

    SEL_NONE = -1
    SEL_QUIT = -2
    SEL_OK = -3

    MENU_WIDTH = 400
    MENU_HEIGHT = 200
    MENU_BUTTON_SIZE = 50
    MENU_MAIN_AREA_HEIGHT = 120
    SPACER_HEIGHT = MENU_HEIGHT/8
    LEFT_WIDTH = MENU_WIDTH / 2
    RIGHT_WIDTH = MENU_WIDTH / 3

    def Run(self,surf,clock):
        self.__quit_flag = 0
        self.__rc = self.SEL_NONE
        Base_Game_Screen.Run(self,surf,clock)
        return self.__rc

    def Quit(self,value=None):
        self.Set_Return_Code(self.SEL_QUIT)

    def Get_Form(self):
        assert self.__quit_flag == 0
        return self.__form

    def Set_Return_Code(self,rc):
        self.__rc = rc
        self.__quit_flag = 1

    def Connect_Click(self,button,value):
        button.connect(gui.CLICK,self.Set_Return_Code,value)

    def Set_Ok_Button_Label(self,l):
        self._ok_button.value = l
        self._ok_button.repaint()

    def __Press_Ok(self,v):
        self.Press_Ok()

    def __Press_Cancel(self,v):
        self.Press_Cancel()



    # Override these functions as necessary:
    def Press_Ok(self, args=None):
        self.General_Update()
        self.Set_Return_Code(self.SEL_OK)

    def Press_Cancel(self, args=None):
        self.General_Update()
        self.Set_Return_Code(self.SEL_QUIT)

    def Get_Strings(self):
        return ["Title","Ok","Cancel"]

    def Setup(self,container):
        pass

    def Draw_Background(self,surf):
        Base_Game_Screen.Draw_Background(self, surf)
        #self.__app.paint(surf)

    def Draw_Foreground(self,surf):
        self.__app.paint(surf)

    def Event(self,e):
        if (( e.type is QUIT )
        or ( e.type is KEYDOWN and e.key == K_ESCAPE )):
            self.Quit()
        self.__app.event(e)

    def Exit_Condition(self):
        return self.__quit_flag



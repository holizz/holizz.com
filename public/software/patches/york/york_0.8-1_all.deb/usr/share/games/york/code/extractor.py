#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: extractor.py,v 1.2 2006/08/09 20:16:28 jack Exp $

import pygame, os, sys
from pygame.locals import *

import library, extra, make_data_file, config, resources
import default_setup # For py2exe

from extra import Convert

TILE_SIZE = 128 # Fixed - interdependency with resolution and co-ordinates.
STAR_SIZE = 32
DEFAULT_RESOLUTION = 170
URL = "http://york.sf.net/othertiles.html"
TITLE = 'Carcassonne -> York Tile Converter'
SCREEN = None
WORK_DIR = "tiletool"




def Boilerplate():
    print ''
    print TITLE
    print 'See', URL, 'for instructions.'
    print ''


def Run_Ghostscript(pdf_file, resolution):
    if ( not os.path.exists(pdf_file) ):
        print ""
        print "Source file '%s' not found." % pdf_file
        print "Please ensure that you have followed all of the instructions on the web page"
        print "at", URL, "- there are some additional files you"
        print "need to download."
        print ""

        if ( not ( '--force' in sys.argv )):
            print "If you can't get hold of all of the files for some reason, run this program"
            print "from a command prompt with the parameter --force, i.e."
            print "   %s --force" % sys.argv[ 0 ]
            print "If you do this, an incomplete (but working) set of tiles will be built."
            sys.exit(0)

        return False

    gs = "gs"
    if ( extra.Is_Windows() ):
        gs = "win\\gs8.54\\bin\\gswin32 -Iwin\\gs8.54\\lib;win\\fonts"

    of = os.path.join(WORK_DIR, "tmp%d.png")
    rc = os.system("%s -dNOPAUSE -sDEVICE=png16m -sOutputFile=%s " % (gs, of) +
            "-dBATCH -r%d %s" % (resolution, pdf_file))

    if ( rc != 0 ):
        print ""
        print "The ghostscript program appears to have failed."
        if ( not extra.Is_Windows() ):
            print "Ensure that GNU Ghostscript is installed."

        sys.exit(0)

    return True

def Load_PNG(number):
    return pygame.image.load(
            os.path.join(WORK_DIR, "tmp%d.png" % number)).convert()


def Do_Tile(big_surf, (x, y), name, rotation, star_compensate):
    global SCREEN

    print 'working on', name

    common = os.path.join(WORK_DIR, "tilepics", "%s." % name)
    bmp_name = common + "bmp"
    jpg_name = common + "jpg"

    #edge_surf = pygame.Surface((TILE_SIZE, TILE_SIZE))
    #library.Edge_Bevel_Effect(edge_surf, (120, 140, 120), 120)

    tile_surf = pygame.Surface((TILE_SIZE, TILE_SIZE))
    r = Rect(x, y, TILE_SIZE, TILE_SIZE)
    tile_surf.blit(big_surf, (0, 0), r)

    if ( star_compensate ):
        sr = Rect(0, 0, STAR_SIZE, STAR_SIZE)
        sr.bottomleft = (0, TILE_SIZE)
        sx = TILE_SIZE - ( STAR_SIZE + 1 )
        sy = sr.top

        star_surf = pygame.Surface((STAR_SIZE, STAR_SIZE))
        star_surf.blit(tile_surf, (0, 0), sr)
        tile_surf.blit(star_surf, (sx, sy))
    
    if ( rotation != 0 ):
        assert 0 < rotation <= 3
        tile_surf = pygame.transform.rotate(tile_surf, rotation * -90)

    #edge_surf.set_alpha(200)
    #out_surf = tile_surf.copy()
    #out_surf.blit(edge_surf, (0, 0))
    #i2 = -library.EDGE_BEVEL_EFFECT_MARGIN
    #i = i2 / 2
    #out_surf.blit(tile_surf, (i, i), Rect(i, i, TILE_SIZE - i2, TILE_SIZE - i2))
    out_surf = tile_surf

    SCREEN.blit(out_surf, (0, 0))
    pygame.display.flip()
    pygame.image.save(out_surf, bmp_name)

    Convert(bmp_name, jpg_name, '')
    os.unlink(bmp_name)

def Beiblatt():
    # Magic numbers, preset for this PDF.
    x_grid = [ 25, 191, 357, 522, 688, 854, 1020, 1186 ]
    y_grid = [ 1045, 1300, 1555 ]

    if ( not Run_Ghostscript("beiblatt.pdf", 162) ):
        return

    beiblatt = Load_PNG(1)

    def Do_Grid_Tile((x, y), name, rotation, star_compensate):
        Do_Tile(beiblatt, (x_grid[ x ], y_grid[ y ]),
                    name, rotation, star_compensate)

    Do_Grid_Tile((0, 0), "basic.monastery.road", 0, False)
    Do_Grid_Tile((1, 0), "basic.monastery", 0, False)
    Do_Grid_Tile((2, 0), "basic.squarecity", 0, False)
    Do_Grid_Tile((3, 0), "basic.city.straightroad", 0, False)
    Do_Grid_Tile((4, 0), "basic.city", 0, True)
    Do_Grid_Tile((5, 0), "basic.cityspan.bonus", 0, False)
    Do_Grid_Tile((6, 0), "basic.cityspan", 0, False)
    Do_Grid_Tile((7, 0), "basic.2citiesopposite", 1, False)
    
    Do_Grid_Tile((0, 1), "basic.2citiescorner", 0, False)
    Do_Grid_Tile((1, 1), "basic.city.curveroad2", 0, False)
    Do_Grid_Tile((2, 1), "basic.city.curveroad1", 0, False)
    Do_Grid_Tile((3, 1), "basic.city.tjunction", 0, False)
    Do_Grid_Tile((4, 1), "basic.citytriangle.bonus", 1, False)
    Do_Grid_Tile((5, 1), "basic.citytriangle", 1, False)
    Do_Grid_Tile((6, 1), "basic.2citiescorner.curveroad1.bonus", 1, False)
    Do_Grid_Tile((7, 1), "basic.2citiescorner.curveroad1", 1, False)

    Do_Grid_Tile((0, 2), "basic.bigcity.bonus", 0, False)
    Do_Grid_Tile((1, 2), "basic.bigcity", 0, False)
    Do_Grid_Tile((2, 2), "basic.bigcity.road.bonus", 0, False)
    Do_Grid_Tile((3, 2), "basic.bigcity.road", 0, False)
    Do_Grid_Tile((4, 2), "basic.straightroad", 1, True)
    Do_Grid_Tile((5, 2), "basic.curveroad", 0, True)
    Do_Grid_Tile((6, 2), "basic.tjunction", 0, True)
    Do_Grid_Tile((7, 2), "basic.crossroads", 0, False)

    (w, h) = library.MOD_ICON_SIZE
    Convert(os.path.join(WORK_DIR, 'tilepics', 'basic.monastery.jpg'), 
            os.path.join(WORK_DIR, 'rules', 'icon.png'),
                '-scale %dx%d' % (w, h))

def Karten_Fluss():
    x_grid = [ 97, 245, 395, 544 ]
    y_grid = [ 52, 201, 350 ]

    if ( not Run_Ghostscript("karten_fluss.pdf", 91) ):
        return 
    karten_fluss = Load_PNG(1)

    def Do_Grid_Tile((x, y), name, rotation):
        Do_Tile(karten_fluss, (x_grid[ x ], y_grid[ y ]),
                    name, rotation, False)

    Do_Grid_Tile((0, 0), "river.city.road", 2)
    Do_Grid_Tile((1, 0), "river.2cities", 0)
    Do_Grid_Tile((2, 0), "river.straight", 0)
    Do_Grid_Tile((3, 0), "river.start", 0)

    Do_Grid_Tile((0, 1), "river.monastery", 1)
    Do_Grid_Tile((1, 1), "river.straight.alt", 0)
    Do_Grid_Tile((2, 1), "river.curve", 0)
    Do_Grid_Tile((3, 1), "river.end", 2)

    Do_Grid_Tile((0, 2), "river.city.curve", 0)
    Do_Grid_Tile((1, 2), "river.road.curve", 2)
    Do_Grid_Tile((2, 2), "river.curve.alt", 2)
    Do_Grid_Tile((3, 2), "river.road.straight", 0)


def Extract():
    global SCREEN
    pygame.init()
    pygame.font.init()
    SCREEN = pygame.display.set_mode((320, 240))
    pygame.display.set_caption(TITLE)

    config.Initialise()
    resources.Initialise()
    library.RM_Minus_R(os.path.join(WORK_DIR, "tilepics"))
    os.mkdir(os.path.join(WORK_DIR, "tilepics"))
    Beiblatt()
    Karten_Fluss()


def Main_Managed():
    Boilerplate()
    Extract()
    mod_dir = os.path.join(os.getcwd(), WORK_DIR)
    make_data_file.Make_Data_File(
            data_file_name=os.path.join(
                resources.BASE_DIR, 'carcassonne.dat'), 
            mod_root=mod_dir, autogen=False, use_default_tiles=True,
            add_mod=os.path.join(
                resources.BASE_DIR, 'river_expansion.dat'))

def Main():
    error_msg = extra.Run_Managed(Main_Managed,
        [ "", "", "Exception in %s." % sys.argv[ 0 ] ], False)

    pygame.display.quit()
    pygame.quit()

    print error_msg

    if ( extra.Is_Windows() ):
        print ''
        print 'Program terminated - please press Enter.'
        sys.stdin.readline()


if ( __name__ == "__main__" ):
    Main()




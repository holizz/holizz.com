#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: client.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 

import socket , threading , time , message_queue
import server


class Client(message_queue.Message_Queue):
    def __init__(self):
        message_queue.Message_Queue.__init__(self)
        self._ok = 1
        self._conn = None

    # Connect via TCP
    def Connect(self, hostname, port, user_name, password):
        assert user_name != None
        assert password != None
        self._ok = 0
        out = None
        try:
            c = socket.socket ( socket.AF_INET, socket.SOCK_STREAM )
            c.settimeout(10) # connection timeout
            c.connect((hostname, port))
            self._ok = 1
        except socket.error, msg:
            out = msg
        
        if ( self._ok ):
            self._conn = server.Connection_Servlet((c, (hostname, port)),
                        "UNKNOWN", user_name, password, self)

        return out


    def Get_State(self):
        if ( self._conn != None ):
            return self._conn.Get_State()
        else:
            return server.STATE_DISCONNECTED

    def Is_Ok(self):
        if ( self._conn != None ):
            return self._ok and self._conn.Is_Ok()
        else:
            return self._ok 

    def Stop(self):
        if ( self._conn != None ):
            self._conn.Stop()
            self._conn = None

    def Get_ID(self):
        if ( self._conn == None ):
            return None
        return self._conn.Get_ID()

    def Get_Mod_Name(self):
        return self._conn.Get_Mod_Name()




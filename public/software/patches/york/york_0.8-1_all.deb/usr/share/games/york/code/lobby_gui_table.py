#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: lobby_gui_table.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# The lobby table widget. Originally the table was generated using PGU
# but I found that updates were too slow, so I moved the implementation
# to a custom widget.
#

import pygame
import resources, library, extra
from pygame.locals import *
from pgu import gui



class Players_Table(gui.Widget):
    def __init__(self, rules, is_master, click_fn, (w, h), **params):
        gui.Widget.__init__(self, **params)
        self.__is_master = is_master
        self.__surface = pygame.Surface((w, h))
        self.__surface.fill(library.colours.lobby_list_bg)
        self.__updates = [ self.__surface.get_rect() ]
        self.__click_fn = click_fn
        self.__my_id = None

        # Precomputed coordinates
        self.__row_height = h / ( rules.Get_Max_Observers() + 1 )
        self.__y_margin = ( h - ( self.__row_height * 
                        ( rules.Get_Max_Observers() + 1 ))) / 2
        # Headings
        self.__column_info = []
        x = self.__y_margin
        for (percent, heading, fn) in [ 
                    (5, "", self.__Kick_Button),
                    (49, "Player Name", self.__Player_Name),
                    (89, "Meeple Colours", self.__Meeples),
                    (100, "Status", self.__Status) ]:
            x1 = x
            x2 = min( w - self.__y_margin, (( percent * w ) / 100 ) )
            x = x2 + self.__y_margin
            self.__column_info.append((x1, x2, heading, fn))

        self.__Draw_Heading()

        # Meeple images are built
        self.__meeple_sz = (( self.__row_height * 7 ) / 8 ) 
        self.__meeple_images = extra.Make_Meeple_Images(self.__meeple_sz, rules)


        # Initial display
        for i in xrange(rules.Get_Max_Observers()):
            self.Redraw_Row(i, None, None)


    def __Get_Box(self, x1, x2, y1):
        return Rect(x1, y1, x2 - x1, self.__row_height - 1 )

    def __Draw_Blocks(self, row_number):
        y1 = ( self.__row_height * ( row_number + 1 ) ) + self.__y_margin
        for (x1, x2, heading, fn) in self.__column_info:
            pygame.draw.rect(self.__surface, 
                    library.colours.meeple_bg, self.__Get_Box(x1, x2, y1))
        return y1
        
    def __Draw_Heading(self):
        y1 = self.__Draw_Blocks(-1)
        for (x1, x2, heading, fn) in self.__column_info:
            self.__Text_Box(10, heading, library.colours.lobby_header_fg,
                    self.__Get_Box(x1, x2, y1))

    def __Text_Box(self, sz, text, colour, box):
        s = resources.Get_Font(sz).render(text, True, colour)
        r = s.get_rect()
        r.center = box.center
        self.__surface.blit(s, r.topleft)

    def __Kick_Button(self, box, row_number, model_slot):
        if (( self.__is_master )
        and ( model_slot != None )
        and ( model_slot.occupied )
        and ( model_slot.id != self.__my_id )
        and ( row_number > 0 )):
            self.__Text_Box(12, "Kick", 
                    library.colours.lobby_header_fg, box)

    def __Player_Name(self, box, row_number, model_slot):
        if (( model_slot != None )
        and ( model_slot.occupied )):
            self.__Text_Box(15, model_slot.name,
                    library.colours.lobby_name_fg, box)
        elif (( model_slot != None )
        and ( model_slot.resume_original_id > 0 )):
            self.__Text_Box(15, model_slot.name,
                    library.colours.lobby_name_resume_fg, box)
        else:
            self.__Text_Box(12, "Open", 
                    library.colours.lobby_header_fg, box)

    def __Meeples(self, box, row_number, model_slot):
        if (( model_slot != None )
        and (( model_slot.occupied )
        or ( model_slot.resume_original_id > 0 ))):
            for i in model_slot.colours:
                (x, y) = box.topleft
                x += i * self.__meeple_sz
                self.__surface.blit(self.__meeple_images[ i ], (x, y))

    def __Status(self, box, row_number, model_slot):
        if ( model_slot != None ):
            if ( model_slot.occupied ):
                if ( model_slot.ready ):
                    self.__Text_Box(12, "Ready", 
                        library.colours.ready_colour, box)
                else:
                    self.__Text_Box(8, "Not Ready", 
                        library.colours.lobby_header_fg, box)
            elif ( model_slot.resume_original_id > 0 ):
                self.__Text_Box(12, "Waiting",
                    library.colours.lobby_name_resume_fg, box)

    def Redraw_Row(self, row_number, model_slot, my_id):
        self.__my_id = my_id
        y1 = self.__Draw_Blocks(row_number)
        for (x1, x2, heading, fn) in self.__column_info:
            box = self.__Get_Box(x1, x2, y1)
            fn(box, row_number, model_slot)
            self.__updates.append(box)
        self.repaint()


    def paint(self,s):
        s.blit(self.__surface, (0, 0))
        self.__updates = []

    def update(self,s):
        u = self.__updates
        self.__updates = []
        s.blit(self.__surface, (0, 0))
        return u

    def event(self, e):
        if ( e.type == MOUSEBUTTONDOWN ):
            (x, y) = e.pos
            (kickx1, kickx2, heading, fn) = self.__column_info[ 0 ]
            if ( kickx1 <= x <= kickx2 ):
                y /= self.__row_height
                y -= 1
                if ( y >= 0 ):
                    self.__click_fn(y)

    def resize(self,width=None,height=None):
        # Width and height are fixed
        return self.__surface.get_rect().size


# Colour selection table

class Colours_Table(gui.Widget):
    def __init__(self, rules, modulus, select_fn, (w, h), **params):
        gui.Widget.__init__(self, **params)
        self.__surface = pygame.Surface((w, h))
        self.__surface.fill(library.colours.meeple_set_bg)
        self.__updates = [ self.__surface.get_rect() ]
        self.__select_fn = select_fn

        meeple_sz = w / modulus
        self.__meeple_images = extra.Make_Meeple_Images(meeple_sz, rules)

        self.__rectangle = []

        x = y = xi = 0
        for i in xrange(rules.Get_Max_Players()):
            r = Rect(x, y, meeple_sz, meeple_sz)
            self.__rectangle.append(r)
            x += meeple_sz
            xi += 1
            if ( xi >= modulus ):
                x = xi = 0
                y += meeple_sz

        self.__state = [ False for i in xrange(rules.Get_Max_Players()) ]

        for i in xrange(rules.Get_Max_Players()):
            self.State_Change(i, True)

    def State_Change(self, colour, available):
        if ( available == self.__state[ colour ] ):
            return # no need to redraw

        self.__state[ colour ] = available
        r = self.__rectangle[ colour ]
        if ( available ):
            self.__surface.blit(self.__meeple_images[ colour ], r.topleft)
        else:
            for y in xrange(r.top, r.bottom, 2):
                pygame.draw.line(self.__surface, 
                        library.colours.meeple_set_bg,
                        (r.left, y), (r.right, y))

    def paint(self,s):
        s.blit(self.__surface, (0, 0))
        self.__updates = []

    def update(self,s):
        u = self.__updates
        self.__updates = []
        s.blit(self.__surface, (0, 0))
        return u

    def event(self, e):
        if ( e.type == MOUSEBUTTONDOWN ):
            for (colour, rect) in enumerate(self.__rectangle):
                if ( rect.collidepoint(e.pos) ):
                    self.__select_fn(colour)
                    break

    def resize(self,width=None,height=None):
        return self.__surface.get_rect().size

    




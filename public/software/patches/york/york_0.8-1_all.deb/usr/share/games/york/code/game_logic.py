#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: game_logic.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# Game Logic. High-level rules enforcement. Also the highest level of the UI.
#

import library , tile , tile_graphics , tile_instance , board_logic , pickle , copy


class Game_Logic:
    """
    Board_Logic <--- Game_Logic <--- Game_Logic_Driver <--- Board_Graphics <---- Main Loop
                     YOU ARE HERE

    This class provides a high-level "Moves" interface to the board. All of the functions
    are moves that a player might take, or accessors for the current board state. Some
    minimal management of turn order also takes place here.
    """
    
    def __init__(self,rules,num_players):
        # Danger. Multiple copies of the rules object may exist within the program.
        self._rules = rules
        #self._debug_info = []

        # General reset of all sorts of things.
        self._board_logic = board_logic.Board_Logic(self._rules)
        self._player_objects = [ self._rules.Get_Player(i) 
                    for i in xrange(num_players) ]

        self._poss_placement_set = set([])
        self._current_tile = None
        self._current_tile_pos = (0,0)
        self._next_meeple = None
        self._sfx = []
        self._current_player = 0
        self._final_region_info = dict()
        self._new_tile_list = []
        self._timecode = 0

        # Game objects get passed to external rules functions
        class G: pass
        self._game_objs = game_objs = G()
        game_objs.player_objects = self._player_objects
        game_objs.board_logic = self._board_logic
        game_objs.game_logic = self

    # The given tile is set up as the next tile.
    # Call before Place_Tile(). 
    # Returns False if the given tile is not placeable.
    def Set_Tile(self,tile):
        self._current_tile = tile
        self._poss_placement_set = self._board_logic.Get_Set_Of_Possible_Placements(self._current_tile)
        return ( len(self._poss_placement_set) != 0 )

    def Set_Current_Player(self,p):
        self._current_player = p

    def Set_Turn_Number(self, tn):
        assert tn >= self._timecode
        self._timecode = tn

    # Place and Choose functions modify game state.
    # Do not call them with Cancel choices.
    # Do call them in the correct order.
    # Each returns None, or a tuple (choice_type, valid_choice_list).
    # None means "invalid - repeat the choice".
    def Place_Tile(self, cache, choice, (tx,ty), subregion):
        # Can it be placed here? Get an initial rotation.
        if ( self.__Apply_Initial_Rotation((tx,ty)) == None ):
            return None

        self._current_tile_pos = (tx,ty)
        # What other rotations are permitted?
        ar = self._board_logic.Get_Set_Of_Allowed_Rotations(self._current_tile,(tx,ty))
        if ( len(ar) > 1 ):
            ar = list(ar)
            ar.sort()
            return ('r', ar + [-1]) 
        else:
            # Rotation choice forced.
            return self.Choose_Rotation(cache, ar.pop(), (tx,ty), subregion)

    def Choose_Rotation(self,cache,choice,(tx,ty),subregion):
        if ( choice == None ):
            return None

        (tx, ty) = self._current_tile_pos
        ar = self._board_logic.Get_Set_Of_Allowed_Rotations(
                        self._current_tile,(tx,ty))
        if ( len(ar) == 0 ):
            return None

        # Validate choice
        if (( 0 <= choice )
        and ( choice in ar )):
            self._current_tile.Rotate(choice)
        else:
            return None

        (self._closures, placeable_regions) = self._board_logic.Place_Tile(
                            self._current_tile,self._current_tile_pos)

        self.__New_Tile(False)

        self._placeable_regions = [ 
                (self._board_logic.Find_Region_Owner(r), r) 
                        for r in placeable_regions ]
        self._next_meeple = None
        for i in self._player_objects[ self._current_player ].meeples:
            if not i.Is_Placed():
                self._next_meeple = i
        self._can_place_meeple = (( self._next_meeple != None ) 
                    and ( len(self._placeable_regions) > 0 ))

        # Here we will someday offer a choice of meeple types,
        # normal,super,builder,pig, etc.
        if ( self._can_place_meeple ):
            return ('m', [1,-1])
        else:
            return ('c', [1,-1])

    def Convert_Minor_XY_To_Subregion(self,
                cache, (tx, ty), (mx, my)):
        # Minor XY now abstracted from tile representation -
        # so different players can use different tile images.
        tile = self._board_logic.Get_Tile_At(tx,ty)
        if ( tile != None ):
            gt = cache.Get(tile.Get_Name())
            return tile.Calculate_Region_For_Position(gt, (mx, my))
        return -1

    def Place_Meeple_And_Confirm(self,cache,
                        choice,(tx,ty),subregion,scoring_msg_fn):

        if (( choice == None ) and ( self._can_place_meeple )):
            # User didn't click on the menu - did he click on a valid region?
            choice_menu = None
            selection = None
            tile = self._board_logic.Get_Tile_At(tx,ty)
            if ( tile != None ):
                gt = cache.Get(tile.Get_Name())

                selection = tile.Convert_Subregion(gt, subregion)
                if ( selection != -1 ):
                    selection = self._board_logic.Find_Region_Owner(selection)

                    # Note: If a region X includes a region Y on the most 
                    # recently placed tile, then the owner of all items 
                    # in X will be Y, due to the ordering imposed in the 
                    # _Region_Merge function.

                    if (( not self._current_tile.Is_Region_On_This_Tile(
                                        selection) )
                    or ( not self._board_logic.Can_Place_In_Region(
                                        selection) )):
                        selection = -1

                if ( selection != -1 ):
                    gt = cache.Get(self._current_tile.Get_Name())
                    self._board_logic.Place_Meeple(self._current_tile,
                            self._current_tile_pos,gt,selection,self._next_meeple)
                            # XXX PRINT TYPE OF MEEPLE TO MSG FUNCTION
                    self._can_place_meeple = 0
                    # Now repeat this state to get final confirmation of intentions.
                    return ('c', [1,-1])
        elif ( choice == 1 ):
            # Don't place a meeple. The turn ends.
            # Score closed regions and commit.
            for closed_region in self._closures:
                self.Score_Region(scoring_msg_fn, cache, closed_region, True)
            self._rules.Commit_Placement(
                        self._game_objs, self._current_tile,
                        self._current_tile_pos)

            self._closures = []

            self.__New_Tile(True) # finalise tile placement
            self._current_tile = None
            return ('!',[])
        else: # try again please.
            pass

        return None

    # Mouse-over functions return:
    # * a preview tile (appears at (tx,ty))
    # * a highlighted region (a tuple: (region_number, draw_list, region_type))
    # * a preview meeple (a tuple: ((tx,ty),region))
    # Any of these may be None.
    def Mouse_Over_Place_Tile(self,cache,choice,(tx,ty),subregion):
        (tile,hregion,mpos) = self.__Mouse_Move(cache,choice,(tx,ty),subregion)

        preview = None
        # A preview tile...
        if ( tile == None ):
            # rotate to a sensible angle for preview
            r = self.__Apply_Initial_Rotation((tx,ty))
            if ( r != None ):
                preview = ((tx,ty),self._current_tile.Get_Drawing_Info())
                self._current_tile.Rotate(4 - r) # rotate back
        return (preview,hregion,None)

    def Mouse_Over_Rotate_Tile(self,cache,choice,(tx,ty),subregion):
        (tile,hregion,mpos) = self.__Mouse_Move(cache,choice,(tx,ty),subregion)
       
        preview = None
        if (( choice != None ) and ( 0 <= choice )):
            preview = (self._current_tile_pos,self._current_tile.Get_Drawing_Info())
        return (preview,hregion,None)

    def Mouse_Over_Place_Meeple(self,cache,choice,(tx,ty),subregion):
        (tile,hregion,mpos) = self.__Mouse_Move(cache,choice,(tx,ty),subregion)
        if ( mpos == None ):
            # don't highlight regions that we can't place in.
            # Is that what you want???
            hregion = None  
        return (None,hregion,mpos)

    def Mouse_Over_Default(self,cache,choice,(tx,ty),subregion):
        (tile,hregion,mpos) = self.__Mouse_Move(cache,choice,(tx,ty),subregion)
        return (None, hregion, None)

    # Call this function to get the final scores.
    def End_Game(self,cache,scoring_msg_fn):
        for r in self._board_logic.Get_Occupied_Regions():
            self.Score_Region(scoring_msg_fn, cache, r, False)
        self._rules.Score_Final(self._game_objs, cache, 
                            scoring_msg_fn, self._timecode)
        self._current_tile = None

        # Player objects are notified.
        for po in self._player_objects:
            po.End_Game()

        # The winning score and a list of winners is returned
        score_list = [ (i, po.score) 
                    for (i, po) in enumerate(self._player_objects) ]
        score_list.sort(cmp=lambda (a,x),(b,y): cmp(y,x))
        (n,top_score) = score_list[ 0 ]
        return (top_score, [ n for (n,s) in score_list if ( s == top_score ) ])


    # Score a region. The region may be complete (end of turn)
    # or incomplete (end of game).

    def Score_Region(self, scoring_msg_fn, cache, region, is_closed):
        game_objs = self._game_objs

        # shares: each item is [number of meeples, player]
        shares = [ [0,i] for i in xrange(len(game_objs.player_objects)) ]

        for meeple in game_objs.board_logic.Get_Meeples_In_Region(region):
            shares[ meeple.Get_Player() ][ 0 ] += 1
        shares.sort(cmp=lambda x,y: cmp(y[0],x[0]))
        # shares is now sorted in descending order of meeples

        must_match = shares[0][0]
        if ( must_match == 0 ):
            return   # region had no meeples

        tiles_in_region = game_objs.board_logic.Get_Tiles_In_Region(region)
        assert len(tiles_in_region) > 0 
        (((tx,ty),tile),subregion) = tiles_in_region[ 0 ]
        href = (tx, ty)

        # determine region type
        type = tile.Get_Type_Of_Region(subregion)

        if ( not self._rules.Is_Closeable(type) ):
            if ( is_closed ):
                # non-closeable region (fields) not scored until the end
                return 0 

            self._rules.Prepare_Field_Style_Scoring(game_objs, 
                                region, type, shares)
            return 0

        # Remove duplicates from the list of tiles in the region.
        duplicate_removal = set()
        tiles_in_region_2 = []
        
        for (((tx,ty),tile),subregion) in tiles_in_region:
            if ( not ( (tx, ty) in duplicate_removal )):
                tiles_in_region_2.append(tile)
                duplicate_removal.add((tx, ty))

        assert len(tiles_in_region_2) > 0

        # Score the region.
        sc = self._rules.Compute_Region_Score(game_objs, 
                    href, tiles_in_region_2, region, type, is_closed)

        if ( sc == 0 ):
            return

        assert sc > 0

        # Standard scoring procedure..
        self.Add_Scoring_Special_Effect(cache, region, sc)
        game_objs.board_logic.Empty_Region(region)

        rname = self._rules.Name_For_Region_Type(type) 
        if ( not is_closed ):
            rname = rname + " (unfinished)"
        scoretext = "scores %u for %s" % (sc, rname)

        scorer_list = []
        for [num_meeples, player] in shares:
            if ( num_meeples != must_match ):
                break
            game_objs.player_objects[ player ].Score(self._timecode, 
                            type, sc, href, scoretext)
            scorer_list.append(player)

        if ( len(scorer_list) == 1 ):
            scoring_msg_fn(rname,scorer_list,"scores ",sc)
        else:
            scoring_msg_fn(rname,scorer_list,"score ",sc)

        # Region finalised.
        game_objs.game_logic.Add_Final_Region_Information(
                    region,type,type,scorer_list,sc)





    # Special effects list - these are lists of events triggered by scoring.
    def Get_Special_Effects(self):
        o = self._sfx
        self._sfx = []
        return o

    # Private functions:
    def __Mouse_Move(self,cache,choice,(tx,ty),subregion):
        # Mouse motion does not change the game state, but it does change
        # whatever is highlighted.
        change = 0
        tile = self._board_logic.Get_Tile_At(tx,ty)
        mpos = None  # preview meeple position
        hregion = None # highlighted region
        if (( tile != None )
        and ( choice == None )):
            gt = cache.Get(tile.Get_Name())
            subregion = tile.Convert_Subregion(gt, subregion)
            if ( subregion != -1 ):
                new_region_type = tile.Get_Type_Of_Region(subregion)
                owner = self._board_logic.Find_Region_Owner(subregion)

                #self._debug_info = [new_region_type, subregion, owner]

                if (( self._current_tile != None )
                and ( self._current_tile.Is_Region_On_This_Tile(owner) )
                and ( self._board_logic.Can_Place_In_Region(owner) )):

                    # Region is empty, and a meeple could be placed in it,
                    # as one part of it is in the tile we just placed.
                    # Preview meeple calculations:
                    gt = cache.Get(self._current_tile.Get_Name())
                    mpos = (self._current_tile_pos,
                        self._current_tile.Get_Centre_Of_Region(gt,owner))

                # WARNING: __Region_Draw_List may be quite slow. Consider
                # using some sort of caching mechanism.
                hregion = (owner,
                        self.__Region_Draw_List(cache,owner),new_region_type)
        return (tile,hregion,mpos)

    
    # Called from scoring functions. Finalises the information
    # stored for a region, namely who scored for it and how much.
    def Add_Final_Region_Information(self,
                region, region_type, score_region_type, scorer_list, points):
        if ( not self._final_region_info.has_key(region) ):
            self._final_region_info[ region ] = []
        self._final_region_info[ region ].append(
                    (region_type,score_region_type,scorer_list,points))
       
    # Called from scoring functions. A special effect is added to
    # show the scoring taking place.
    def Add_Scoring_Special_Effect(self,cache,region,score):
        self._sfx.append((self.__Region_Draw_List(cache,region),score))


    def __Region_Draw_List(self,cache,region):
        out = []
        for (((tx,ty),tile),r) in self._board_logic.Get_Tiles_In_Region(region):
            gt = cache.Get(tile.Get_Name())
            include_meeple = 0
            m = tile.Get_Meeple()
            if ( m != None ):
                include_meeple = ( m.Get_Region() == r )

            graphics_region = tile.Translate_To_Graphics_Region(gt,r)
            out.append( ((tx,ty),tile.Get_Drawing_Info(include_meeple),graphics_region) )
        return out

    def __New_Tile(self,finalised):
        self._new_tile_list.append((self._current_tile_pos,
                    (self._current_tile.Get_Name(),
                     self._current_tile.Get_Rotation()),self._current_player,
                     finalised))

    def __Apply_Initial_Rotation(self, (tx,ty)):
        ar = self._board_logic.Get_Set_Of_Allowed_Rotations(self._current_tile,(tx,ty))
        if ( len(ar) != 0 ):
            r = min(ar)
            self._current_tile.Rotate(r)
            return r
        return None # no valid rotation.

    # Accessors to allow read access to internal game state.
    def Get_Probabilities(self, tile_bag):
        return self._board_logic.Compute_Probabilities(tile_bag)

    def Get_Tile_Draw_List(self,draw_ghosts=False):
        return [ ((tx,ty),tile.Get_Drawing_Info(True,draw_ghosts)) 
                for ((tx,ty),tile) in self._board_logic.Get_Tile_List() ]

    def Get_Ghost_Meeples(self):
        return [ ((tx,ty),tile.Get_Ghost_Meeple()) 
                for ((tx,ty),tile) in self._board_logic.Get_Tile_List() ]

    def Get_Player_HUD_Info(self):
        return [ po.Get_HUD_Info() for po in self._player_objects ]

    def Get_Current_Player(self):
        return self._current_player

    def Get_Current_Tile_Name(self):
        if ( self._current_tile == None ):
            return None
        else:
            return self._current_tile.Get_Name()

    def Get_Set_Of_Possible_Placements(self):
        return self._poss_placement_set
        
    def Is_Region_Empty(self,r):
        return len(self._board_logic.Get_Meeples_In_Region(r)) == 0

    def Get_Region_Statistics(self,r):
        if ( self._final_region_info.has_key( r ) ):
            # Region has been finalised - all scoring data is available.
            return self._final_region_info[ r ]
        else:
            # Region not finished - maybe some temporary data can be generated?
            tiles_in_region = self._board_logic.Get_Tiles_In_Region(r)
            if ( len(tiles_in_region) > 0 ):
                (((tx,ty),tile),subregion) = tiles_in_region[ 0 ]
                # determine region type
                rtype = tile.Get_Type_Of_Region(subregion)
                slist = [ meeple.Get_Player() for meeple in self._board_logic.Get_Meeples_In_Region(r) ]
                return [(rtype,rtype,slist,-1)]
        return None

    def Get_New_Tiles(self):
        o = self._new_tile_list
        self._new_tile_list = []
        return o

    def Final_Score(self, txt):
        self._player_objects[ self._current_player ].Score(
                self._timecode + 1, None, 0, (0, 0), txt)

    def Get_Player_Objects(self):
        return self._player_objects




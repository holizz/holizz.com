#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# 
#


from default_setup import *


#
#
# Distribution and tile layout comes from:
# http://www.cse.buffalo.edu/faculty/alphonce/Courses/Spring2004/cse116/Projects/Stage1/CarcassonneTiles/TileSet.jpg
# (the images are generated separately)
#
# Row 1
Declare_Tile('basic.city',
            [City(0),Field(1),Field(1),Field(1)],
            None, None,
            [("city1", 0)])
Declare_Tile('basic.2citiescorner',
            [City(0),City(1),Field(2),Field(2)],
            None, None,
            [("city1", 0), ("city1", 1)])
Declare_Tile('basic.2citiesopposite',
            [City(0),Field(1),City(2),Field(1)],
            None, None,
            [("city1", 0), ("city1", 2)])
Declare_Tile('basic.citytriangle',
            [City(0),City(0),Field(1),Field(1)],
            None, None,
            [("city2b", 0)])
Declare_Tile('basic.citytriangle.bonus',
            [City(0),City(0),Field(1),Field(1)],
            ['s'], None,
            [("city2b", 0)])

# Row 2
Declare_Tile('basic.cityspan',
            [Field(0),City(1),Field(2),City(1)],
            None, None,
            [("hfield",0), ("city2c", 0)])
Declare_Tile('basic.cityspan.bonus',
            [Field(0),City(1),Field(2),City(1)],
            ['s'], None,
            [("hfield",0), ("city2c", 0)])
Declare_Tile('basic.squarecity',
            [City(0),City(0),City(0),City(0)],
            ['s'], None,
            [("city4", 0)])
Declare_Tile('basic.bigcity',
            [City(0),City(0),Field(1),City(0)],
            None, None,
            [("city3", 0)])
Declare_Tile('basic.bigcity.bonus',
            [City(0),City(0),Field(1),City(0)],
            ['s'], None,
            [("city3", 0)])

# Row 3
Declare_Tile('basic.city.straightroad',
            [City(0),Road(1,2,3),Field(3),Road(3,2,1)],
            None, None, # start tile
            [("hfield",0), ("road", 0), ("city1",0)])
Declare_Tile('basic.city.curveroad1',
            [City(0),Field(1),Road(1,2,3),Road(3,2,1)],
            None, None,
            [("cfield",0), ("roadcurve", 0), ("city1",0)])
Declare_Tile('basic.city.curveroad2',
            [City(0),Road(1,2,3),Road(3,2,1),Field(1)],
            None, None,
            [("cfield",3), ("roadcurve", 3), ("city1",0)])
Declare_Tile('basic.2citiescorner.curveroad1',
            [City(0),City(0),Road(1,2,3),Road(3,2,1)],
            None, None,
            [("cfield",0), ("roadcurve", 0), ("city2b",0)])
Declare_Tile('basic.2citiescorner.curveroad1.bonus',
            [City(0),City(0),Road(1,2,3),Road(3,2,1)],
            ['s'], None,
            [("cfield",0), ("roadcurve", 0), ("city2b",0)])

# Row 4
Declare_Tile('basic.bigcity.road',
            [City(0),City(0),Road(1,2,3),City(0)],
            None, None,
            [("qfield",0), ("road", 1), ("city3",0)])
Declare_Tile('basic.bigcity.road.bonus',
            [City(0),City(0),Road(1,2,3),City(0)],
            ['s'], None,
            [("qfield",0), ("road", 1), ("city3",0)])
Declare_Tile('basic.city.tjunction',
            [City(0),Road(1,2,3),Road(3,4,5),Road(5,6,1)],
            None, None,
            [("hfield", 0), ("qfield", 0)] +
            [("roadend", x) for x in [0,2,3] ] + 
            [("roaddiv", 0), ("city1",0)])
Declare_Tile('basic.monastery',
            [Field(0), Field(0), Field(0), Field(0)],
            ['m'], [Monastery(1,[0])],
            [("monastery", 0)])
Declare_Tile('basic.monastery.road',
            [Field(0), Field(0), Road(0,1,0), Field(0)],
            ['m'], [Monastery(2,[1,0])],
            [("roadend", 3), ("monastery", 0)])

# Row 5
Declare_Tile('basic.straightroad',
            [Field(0), Road(0,1,2), Field(2), Road(2,1,0)],
            None, None,
            [("hfield",0), ("road", 0)])
Declare_Tile('basic.curveroad',
            [Field(0), Field(0), Road(0,1,2), Road(2,1,0)],
            None, None,
            [("cfield",0), ("roadcurve", 0)])
Declare_Tile('basic.tjunction',
            [Field(0), Road(0,1,2), Road(2,3,4), Road(4,5,0)],
            None, None,
            [("hfield", 0), ("qfield", 0)] +
            [("roadend", x) for x in [0,2,3] ] + [("roaddiv", 0)])
Declare_Tile('basic.crossroads',
            [Road(0,1,2), Road(2,3,4), Road(4,5,6), Road(6,7,0)],
            None, None,
            [("hfield", 0), ("qfield", 0), ("qfield", 2)] +
            [("roadend", x) for x in xrange(4) ] + [("roaddiv", 0)])


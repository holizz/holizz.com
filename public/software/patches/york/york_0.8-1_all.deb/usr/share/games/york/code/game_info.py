#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: game_info.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# 
# 

import time
import library


class Game_Info:
    # Information about either:
    # - A recently played game
    # - An Internet game
    def __init__(self):
        self.timestamp = int(time.time())
        self.time = time.asctime()
        self.name = ""
        self.mod_name = ""
        self.icon = None # Use mod icon if you have the mod
        self.address = ""
        self.port = library.DEFAULT_PORT

    def Is_Valid(self):
        c = [ self.time, self.name, self.mod_name, self.address ]
        for (i, x) in enumerate(c):
            if (( x == None )
            or ( type(x) != str )
            or ( len(x) == 0 )):
                print 'not valid as',i,'is',x
                return False

        return True


#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: thread_mgr.py,v 1.1 2006/08/09 19:59:13 jack Exp $
# 
# 
# 

import threading, sys

__threads = []
__mutex = threading.Semaphore()

def Shutdown():
    # Britain has made emergency plans for war...
    # This procedure ensures that the threads have stopped.
    global __threads, __mutex

    __mutex.acquire()
    tlist = [ t for t in __threads ]
    __mutex.release()

    for tobj in tlist:
        Stop_Thread(tobj)
    #print 'Stopped all managed threads'


def Add_Thread(tobj):
    global __threads, __mutex
    if ( tobj != None ):
        # Ensure it's the right type of object
        assert isinstance(tobj, threading.Thread)

        __mutex.acquire()
        __threads.append(tobj)
        __mutex.release()
    

def Stop_Thread(tobj):
    global __threads, __mutex
    if ( tobj != None ):
        #print 'Attempting to stop thread',tobj.getName(),repr(tobj),
        if ( tobj != threading.currentThread() ):
            # If it's the current thread, then it'll stop anyway.
            tobj.Stop()
        #print 'Ok'
        __mutex.acquire()
        __threads = [ t for t in __threads if ( t != tobj ) ]
        __mutex.release()



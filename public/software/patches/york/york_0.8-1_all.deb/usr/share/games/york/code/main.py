#
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: main.py,v 1.2 2006/08/09 20:08:26 jack Exp jack $
# 
# 
# 


import pygame , sys , time , random , threading , os
import lobby , server , client , library , message_queue , support
import rules , tile_cache , resources , demo_mq , options_gui
import game_screen , config , lobby_gui , lobby_setup , extra , constants
import test_program

from pygame.locals import *

from lobby_gui import Lobby_Slave_Screen, Main_Menu_Screen
from lobby_gui import Lobby_Master_Screen
from library import MENU_RESOLUTION
from thread_mgr import Stop_Thread

__menu_back = None
screen = None




def __Init():
    global __menu_back
    global screen

    # Initialisation
    config.Initialise()
    pygame.init()
    pygame.font.init()
    clock = pygame.time.Clock()

    try:
        screen = extra.Menu_Video_Mode()
    except Exception, r:
        print ''
        print 'Startup error:'
        print 'Your computer must support a graphics resolution of'
        print 'at least %u by %u to run York.' % MENU_RESOLUTION
        print ''
        return None

    sys.stdout = extra.Make_Debug_Hook(sys.stdout)
    sys.stderr = extra.Make_Debug_Hook(sys.stderr)

    # Loading of base resources...
    resources.Initialise()

    #loading_image = resources.Get_Resource_Image("ui/bg.jpg")
    #if ( not config.cfg.seen_before ):
    #    waiting = 4000
    #else:
    #    waiting = 1400
    config.cfg.seen_before = True


    #r = loading_image.get_rect()
    #r.center = screen.get_rect().center
    #screen.blit(loading_image, r)

    pygame.display.set_caption("York")
    pygame.display.set_icon(resources.Get_Resource_Image("icon.png"))
    pygame.display.flip()

    resources.Reset() 
    __menu_back = resources.Get_Resource_Image("ui/minster.jpg")

    return clock

def Main():
    # Initialise game
    clock = __Init()
    if ( clock == None ):
        pygame.quit()
        return

    if ( '--test' in sys.argv ):
        test_program.Test_Program(clock)
        pygame.quit()
        return

    # Start game loop
    looping = True
    while looping:
        looping = __Game_Loop(clock)
        config.Save()

    pygame.quit()

def Draw_Menu_Back(surf, flip=True):
    global __menu_back
    surf.blit(__menu_back, (0,0))
    if ( flip ):
        pygame.display.flip()

def __Game_Loop(clock):
    # Further loading of resolution-specific resources...
    global __menu_back

    # Remove mods
    resources.Reset() 

    # Change to menu resolution
    global screen
    screen = extra.Menu_Video_Mode()

    main_menu = Main_Menu_Screen()


    keep_playing = looping = True
    while looping:
        sys.stdout.Attach(None)
        sys.stderr.Attach(None)
        exit_message = []
        demo_record_stream = None
        demo_playback_stream = None
        resume_from_demo = False
        lobby_ui = None
        lobby_net = None
        host_object = None
        rules_obj = None

        sel = main_menu.Run(screen, clock)
        Draw_Menu_Back(screen)

        def Open_Options():
            global screen
            Draw_Menu_Back(screen)
            og = options_gui.Options_Screen()
            while ( True ):
                rc = og.Run(screen, clock)
                if ( rc == og.SEL_MODE_TEST ):
                    res = og.Get_Mode_To_Test()
                    t_screen = extra.Game_Video_Mode(res)
                    if ( t_screen == None ):
                        screen = extra.Menu_Video_Mode()
                        ms = lobby_gui.Message_Screen()
                        ms.Show_Message_Dialog(
                                ["Unable to switch to selected mode."])
                        sel = ms.Run(screen, clock)
                    else:
                        library.Test_Mode_Draw(t_screen, clock)
                        screen = extra.Menu_Video_Mode()

                else:
                    break

            if ( rc == og.SEL_CTM ):
                Draw_Menu_Back(screen)

                # Choose tile modification
                ctm = lobby_gui.Tile_Mod_Selection_List_Screen()
                rc = ctm.Run(screen, clock)

                if ( rc == ctm.SEL_OK ):
                    Draw_Menu_Back(screen)
                    config.cfg.tile_mod = ctm.Get_Mod_File_Name()


        if ( sel == main_menu.SEL_QUIT ):
            keep_playing = looping = False

        elif ( sel == main_menu.SEL_OPTIONS ):
            Open_Options()

        elif ( sel == main_menu.SEL_HOTSEAT_GAME ):
            # XXX Permit rules to be chosen at this point.

            assert False

            rules_obj = resources.Get_Rules()
            lobby_ui = lobby_gui.Hotseat_Lobby_Screen(rules_obj)
            #lobby_net = lobby_setup.Hotseat_Game(rules_obj)

            assert ( lobby_net != None )

        elif ( sel == main_menu.SEL_PLAY_DEMO ):

            demo_sel = lobby_gui.Demo_Selection_List_Screen()
            rc = demo_sel.Run(screen, clock)

            if ( rc == main_menu.SEL_OK ):
                Draw_Menu_Back(screen)

                (demo_playback_stream, mod_name) = demo_mq.Open_Demo(
                            demo_sel.Get_Demo_File_Name())
                assert mod_name == demo_sel.Get_Mod_Name()
                resources.Add_Mod(demo_sel.Get_Mod_File_Name(), False)
                rules_obj = resources.Get_Rules()
                lobby_ui = lobby_gui.Lobby_Slave_Screen(rules_obj)
                client_mq = demo_mq.Demo_MQ(None)

                try:
                    lobby_net = lobby.Lobby(rules_obj, client_mq, None)
                except lobby_setup.Game_Exception, r:
                    exit_message = ['Error while playing recording:', 
                                    str(r) ]

        elif ( sel in [ main_menu.SEL_HOST_INTERNET_GAME,
                        main_menu.SEL_HOST_LAN_GAME ]):

            rc = None

            while ( rc == None ):
                name_entry = lobby_gui.Enter_Name_Screen("Host Game")
                rc = name_entry.Run(screen, clock)

                if ( rc == main_menu.SEL_OPTIONS ):
                    Open_Options()
                    rc = None



            if ( rc == main_menu.SEL_OK ):
                mod_sel = lobby_gui.Host_Setup_Screen(
                        sel == main_menu.SEL_HOST_INTERNET_GAME,
                        "%s's game" % name_entry.Get_Name())
                rc = mod_sel.Run(screen, clock)

                if ( rc == mod_sel.SEL_RESUME ):
                    Draw_Menu_Back(screen)
                    resume_from_demo = True

                    mod_sel = lobby_gui.Demo_Selection_List_Screen()
                    rc = mod_sel.Run(screen, clock)

                    if ( rc == main_menu.SEL_OK ):
                        (demo_playback_stream, mod_name) = demo_mq.Open_Demo(
                            mod_sel.Get_Demo_File_Name())
                        assert mod_name == mod_sel.Get_Mod_Name()

            if ( rc == main_menu.SEL_OK ):
                Draw_Menu_Back(screen)

                resources.Add_Mod(mod_sel.Get_Mod_File_Name(), False)
                rules_obj = resources.Get_Rules()

            if ( rc == main_menu.SEL_OK ):
                Draw_Menu_Back(screen)

                demo_record_stream = demo_mq.New_Demo_File()
                lobby_ui = lobby_gui.Lobby_Master_Screen(rules_obj)
                lobby_net = host_object = None
                try:
                    host_object = lobby_setup.TCP_Host_Game(rules_obj,
                        mod_sel.Get_Mod_Name(),
                        name_entry.Get_Name(),
                        config.cfg.game_password,
                        demo_record_stream)
                    assert host_object.Is_Ok()
                    lobby_net = host_object.Get_Lobby()

                except lobby_setup.Game_Exception, r:
                    exit_message = ['Error while attempting to host game:', 
                                    str(r) ]


        elif ( sel in [ main_menu.SEL_JOIN_INTERNET_GAME,
                        main_menu.SEL_JOIN_LAN_GAME ]):

            name_entry = lobby_gui.Enter_Name_Screen("Join Game")
            rc = name_entry.Run(screen, clock)

            if ( rc == main_menu.SEL_OK ):
                if ( sel == main_menu.SEL_JOIN_LAN_GAME ):
                    game_sel = lobby_gui.Join_Game_Screen()
                else:
                    # TO BE DONE.
                    assert False

                rc = game_sel.Run(screen, clock)
            
            if ( rc == main_menu.SEL_OK ):
                ginfo = game_sel.Get_Game_Info()

                demo_record_stream = demo_mq.New_Demo_File()
                client_mq = demo_mq.Demo_MQ(demo_record_stream)

                inter_screen = lobby_gui.Inter_Screen()
                rc = inter_screen.Run(screen, clock, 
                        name_entry.Get_Name(),
                        client_mq, ginfo)

                if ( rc == main_menu.SEL_OK ):
                    Draw_Menu_Back(screen)

                    ginfo.mod_name = inter_screen.Get_Mod_Name()
                    resources.Add_Mod(inter_screen.Get_Mod_File_Name(), False)
                    inter_screen = None

                    rules_obj = resources.Get_Rules()
                    lobby_net = lobby.Lobby(rules_obj, client_mq, None)
                    lobby_ui = lobby_gui.Lobby_Slave_Screen(rules_obj)

                    config.Add_Game_To_History(ginfo)

                else:
                    client_mq.Stop()
                    client_mq = None

                game_sel = None




        if ( lobby_net != None ):
            # Tile mod loaded.
            if ( config.cfg.tile_mod != None ):
                resources.Add_Mod(config.cfg.tile_mod, True)

            # Enter game lobby!
            assert lobby_ui != None
            assert rules_obj != None

            client_mq = lobby_net.Get_Client_MQ()
            if ( demo_record_stream != None ):
                # Hook stdout/stderr now
                sys.stdout.Attach(client_mq.Debug_Message)
                sys.stderr.Attach(client_mq.Debug_Message)

            if ( demo_playback_stream != None ):
                if ( lobby_net.Play_Lobby_Demo(demo_playback_stream, 
                                resume_from_demo) ):
                    if ( resume_from_demo ):
                        rc = lobby_ui.Run(screen, clock, lobby_net)
                    else:
                        rc = lobby_ui.SEL_START_GAME
                else:
                    rc = lobby_ui.SEL_QUIT
            else:
                rc = lobby_ui.Run(screen, clock, lobby_net)

            if ( rc != lobby_ui.SEL_START_GAME ):
                # Why did we leave the game?
                if ( lobby_net.Client_Kicked() ):
                    msg = "You were kicked from the game."
                else:
                    msg = "Disconnected from game."

                exit_message = ['Connection closed:', msg ]
            else:
                # Game starts. 
                # Change video mode.
                screen = extra.Game_Video_Mode()

                g = game_screen.Game_Screen(screen.get_rect().size)
                looping = False

                keep_playing = g.Run(screen,clock,(rules_obj,
                    lobby_net.Get_Game_Information(),
                    lobby_net.Get_Client_MQ(),
                    lobby_net.Get_Server_MQ()),
                    demo_playback_stream, resume_from_demo)

            if ( host_object != None ):
                host_object.Stop()


            Stop_Thread(client_mq)
            Stop_Thread(lobby_net.Get_Server_MQ())

            if ( demo_playback_stream != None ):
                demo_playback_stream.close()

        if ( len(exit_message) != 0 ):
            ms = lobby_gui.Message_Screen()
            ms.Show_Message_Dialog(exit_message)
            sel = ms.Run(screen, clock)

    return keep_playing


def Exception_Display(error_msg):
    global screen

    screen = extra.Menu_Video_Mode()
    screen.fill((0, 0, 0))

    font = resources.Get_Font(14)
    x = y = 30

    (w, line_height) = font.size('TEST')
    all_text = error_msg.split('\n')

    max_lines = ( screen.get_rect().height - ( y * 2 )) / line_height
    if ( len(all_text) > max_lines ):
        chop = ( max_lines / 2 ) - 2
        all_text = all_text[ : chop ] + [ "..." ] + all_text[ -chop : ]

    for line in all_text:
        s = font.render(line, True, (192, 255, 192))
        screen.blit(s, (x, y))
        y += line_height

    pygame.display.flip()

    library.Wait(2000) # display for at least this long, eat events.
    while ( not library.Wait_Key_Mouse() ):
        pygame.time.wait(50)




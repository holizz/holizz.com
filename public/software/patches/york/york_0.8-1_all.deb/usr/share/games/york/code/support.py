# 
# York
# This game is licensed under GPL v2, and copyright (C) Jack Whitham 2006.
# $Id: support.py,v 1.1 2006/08/09 19:59:13 jack Exp $
#
# GUI support functions.
# If anything here replicates something in PGU, it is because I
# have an incomplete understanding of PGU.
#

import pygame

from pgu import gui
from pygame.locals import *

import resources, library


def Buttons2Table(table, buttons):
    out = []
    table.td(gui.Spacer(10,1))
    for (name, operation) in buttons:
        if ( name == None ):
            table.td(gui.Spacer(80,1))
        else:
            b = gui.Button(name)
            if ( operation != None ):
                b.connect(gui.CLICK, operation, None)
            table.td(b)
            out.append(b)
            table.td(gui.Spacer(10,1))

    return out

def Picture_Buttons2Table(table, buttons):
    def Icon(rc_name):
        surf1 = resources.Get_Resource_Image(rc_name)
        (w, h) = surf1.get_rect().size
        surf2 = pygame.Surface((w, h + 6))
        white = (255, 255, 255)
        surf2.fill(white)
        surf2.set_colorkey(white)
        surf2.blit(surf1, (0, 3))
        return gui.Image(surf2)

    return Buttons2Table(table, [ 
            (Icon(rc_name), fn) for (rc_name, fn) in buttons ])

def Make_Simple_Dialog(title, text_list, proceed_fn, cancel_fn=None):

    dlg_t = gui.Table()
    for l in text_list:
        dlg_t.tr()
        dlg_t.td(gui.Label(l))
    dlg_t.tr()
    dialog_buttons_t = gui.Table(align=1)
    dialog_buttons_t.tr()

    blist = [ ("Ok", proceed_fn), ("Cancel", cancel_fn) ]
    if ( proceed_fn == None ):
        blist = [ blist[ 1 ] ] # Remove Ok option

    buttons = Buttons2Table(dialog_buttons_t, blist)

    dlg_t.td(dialog_buttons_t)
    dlg_c = gui.Container()
    dlg_c.add(dlg_t, 0, 0)

    dlg = gui.Dialog(gui.Label(title), dlg_c)

    # Undefined buttons are connected to close
    if ( proceed_fn == None ):
        if ( cancel_fn == None ):
            buttons[ 0 ].connect(gui.CLICK, dlg.close, None)

    elif ( cancel_fn == None ):
        buttons[ 1 ].connect(gui.CLICK, dlg.close, None)

    return dlg

def Shorten(mod_name):
    if ( len(mod_name) > 16 ):
        mod_name = mod_name[ :16 ].strip() + "..."
    return mod_name

def Make_Warning_Dialog(title, mod_name, proceed_fn, cancel_fn=None):
    mod_name = Shorten(mod_name)    
    warning_text = [
        "Warning: '" + mod_name + "' is a newly-installed mod.",
        "As mods include software, you should be sure that the mod does",
        "not contain any malicious code. To avoid the risk of malware and",
        "virus infection, you should only download software from websites",
        "that you trust. Are you sure you wish to load this mod?"]
    return Make_Simple_Dialog(title, warning_text, proceed_fn, cancel_fn)

def Make_Input_Dialog(title, input_box_names,
            ok_label, ok_fn, cancel_fn=None):

    class Input_Widget(gui.Input):
        # Adds a feature: pressing RETURN is equivalent to clicking OK.
        def event(self, e):
            gui.Input.event(self, e)
            if (( e.type == KEYDOWN ) and ( e.key == K_RETURN )):
                ok_fn(None)

    class Input_Dialog(gui.Dialog):
        # Adds another feature: the first input is in focus.
        def __init__(self, title, dialog_c, primary_input):
            self.__pi = primary_input
            gui.Dialog.__init__(self, gui.Label(title), dialog_c)

        def open(self, *params):
            gui.Dialog.open(self, *params)
            self.__pi.focus()
            

    assert ok_fn != None
    dialog_t = gui.Table()
    input_areas = []

    for name in input_box_names:
        dialog_t.tr()
        dialog_t.td(gui.Label(name))
        dialog_t.tr()
        w = Input_Widget(ok_fn, size=30)
        dialog_t.td(w)
        input_areas.append(w)
    dialog_t.tr()
    dialog_buttons_t = gui.Table(align=1)
    dialog_buttons_t.tr()

    buttons = Buttons2Table(dialog_buttons_t,
        [ (ok_label, ok_fn),
            ("Cancel", cancel_fn) ])

    dialog_t.td(dialog_buttons_t)
    dialog_c = gui.Container()
    dialog_c.add(dialog_t, 0, 0)

    dialog = Input_Dialog(title, dialog_c, input_areas[ 0 ])

    if ( cancel_fn == None ):
        buttons[ 1 ].connect(gui.CLICK, dialog.close, None)

    return (input_areas, dialog)


def Make_Multiline_Widget(num_lines, width):
    handle = []
    
    t = gui.Table()
    for x in xrange(num_lines):
  
        class MLW_Line:
            pass

        dl = MLW_Line()
        dl.c = gui.Container(align=-1, 
                width=width)
        dl.w = gui.Label(value="")
        dl.c.add(dl.w, 0, 0)
        t.tr()
        t.td(dl.c)
        handle.append(dl)

    return (handle, t)

def Change_Multiline_Widget(handle, new_text, colour):
    sz = len(handle)
    if ( len(new_text) > sz ):
        new_text = new_text[ 0:sz ]
    else:
        while ( len(new_text) < sz ):
            new_text = new_text + [ "" ]

    for (dl, d) in zip(handle, new_text):
        dl.c.remove(dl.w)
        d = "  " + d + "  "
        dl.w = gui.Label(value=d, align=-1, color=colour)
        dl.c.add(dl.w, 0, 0)
        dl.c.repaint()

def Get_Progress_Bar_Rect(r1):
    r2 = Rect(0, 0, 200, 100)
    r2.center = r1.center
    return r2

def Init_Progress_Bar(surf, text):
    r1 = Get_Progress_Bar_Rect(surf.get_rect())
    library.Edge_Bevel_Effect(surf.subsurface(r1),
            library.colours.progress_bar_bg, 20)
    (x, y) = r1.center
    ts = resources.Get_Font(20).render(
        text, True, library.colours.progress_bar_fg)
    r2 = ts.get_rect()
    r2.center = (x, y) = r1.center
    r2.bottom = y - 5
    surf.blit(ts, r2.topleft)
    Draw_Progress_Bar(surf, 0, 1)

def Draw_Progress_Bar(surf, pos, maxpos):
    if ( pos < 0 ): pos = 0
    if ( pos > maxpos ): pos = maxpos
    r1 = Get_Progress_Bar_Rect(surf.get_rect())
    (x, y) = r1.center
    sz = ( r1.width * 7 ) / 8
    y += 5
    x -= sz / 2
    r2 = Rect(x, y, sz, 10)
    pygame.draw.rect(surf, (10, 10, 100), r2)
    r3 = Rect(x, y, ( sz * pos ) / maxpos, 10)
    pygame.draw.rect(surf, (0, 0, 255), r3)
    pygame.display.flip()

def Render_Copyrights(surf, (x, y), colour):    
    f = resources.Get_Font(12)
    for text in library.COPYRIGHTS:
        s = f.render(text, True, colour)
        surf.blit(s, (x - s.get_rect().width, y))
        y += s.get_rect().height





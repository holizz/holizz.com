#!/usr/bin/env ruby

#
# = lmci.rb: a Little Man Computer interpreter
#
# Author:: Tom Adams
# Version:: $Version: 0.1$
# Date:: $Date: 2005/10/19 17:06:45 $
#
# lmci.rb: a Little Man Computer interpreter
# Copyright (C) 2005 Tom Adams
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA

require 'log4r'
require 'getoptlong'

# 
# LittleManCompileError.
#
class LittleManCompileError < Exception
end

# 
# LittleManInterpretError.
#
class LittleManInterpretError < Exception
end

# 
# The LittleMan class provides fun and entertainment.
#
# Here are the commands:
# Code Shorthand (Explanation)
# 000  STOP      (ends execution)
# 1xx  ADD xx    (add the contents of mailbox xx to accumulator)
# 2xx  SUB xx    (subtract)
# 3xx  STO xx    (store contents of accumulator to mailbox xx)
# 4xx  STA xx    (store address part (latter two digits) of accumulator to mailbox xx)
# 5xx  LOAD xx   (load contents of mailbox xx to accumulator)
# 6xx  B xx      (branch to instruction)
# 7xx  BZ xx     (branch to xx if accumualtor is 0)
# 8xx  BP xx     (branch if accumulator is >= 0)
# 901  INPUT     (to accumulator)
# 902  OUTPUT    (from accumulator)
#
#
class LittleMan

  # 
  # Regular expressions for compiling from shorthand LMC to strict LMC.
  # 
  REGEXPS =
    [/STOP/i, '000'],
    [/ADD/i, '1'],
    [/SUB/i, '2'],
    [/STO/i, '3'],
    [/STA/i, '4'],
    [/LOAD/i, '5'],
    [/B(\W)/i, '\16'],
    [/BZ/i, '7'],
    [/BP/i, '8'],
    [/INPUT/i, '901'],
    [/OUTPUT/i, '902'],
    [/\D/i, ''],
    [/(\d{2})(\d{3})/i, '\1 \2']

  #
  # Options: literate quiet verbose
  # 
  # Compiles a string ready for execution.
  # 
  #   LittleMan.new("00 STOP", :verbose => true)   # verbosely compile a very simple program
  # 
  def initialize(string,options={})
    # Set up logging
    Log4r::Logger.root.level = Log4r::WARN
    Log4r::Logger.root.level = Log4r::DEBUG if options[:verbose]
    @log = Log4r::Logger.new("lm")
    Log4r::StderrOutputter.new 'console'
    @log.add('console')

    # Set up variables
    @accu = 0
    @file = []
    @data = {}
    @f = string
    @literate = options[:literate]
    @quiet = options[:quiet]

    # Do it!
    readfile
    unshorthand
    tokenize
    check
  end
  
  #
  # Options: (none)
  # 
  # Output the code as it currently stands.
  # 
  def code
    f = ""
    mbox = '00'
    while mbox <= '99'
      if inst = @data[mbox]
        set = [mbox, inst]
        f<<"#{mbox} #{inst}\n"
      end
      mbox.succ!
    end
    f
  end

  #
  # Options: (none)
  # 
  # Private. Extracts the code from documention.
  #
  def readfile
    lit = '>'
    @f.each("\n") do |l|
      if @literate
        if @literate.class == "".class
          lit = @literate
        end
        re = Regexp.new("^#{lit} *(.*)$")
        @file<< $1 if l.match(re)
      else
        @file<< l
      end
    end
  end

  #
  # Options: (none)
  # 
  # Private. Compiles shorthand LMC (@file) to strict LMC (@file).
  # 
  def unshorthand
    for l in @file
      for re in REGEXPS
        l.gsub!(re.first, re.last)
      end
    end
  end

  #
  # Options: (none)
  # 
  # Private. Tokenizes LMC (@file) to an internal representation in @data.
  # 
  def tokenize
    for l in @file
      if l.match(/^(\d{2}) *(\d{3})$/)
        ma, mb = $1, $2
        a = []
        ma.scan(/(.)/) {|c| a<<c.first.to_i}
        b = []
        mb.scan(/(.)/) {|c| b<<c.first.to_i}
        @data[ma]=mb
      end
    end
  end

  #
  # Options: (none)
  # 
  # Checks that the tokenized data in @data is valid.
  # 
  def check
    for mbox, inst in @data
      raise LittleManCompileError.new('Tokenized data is invalid!') unless mbox.match(/^\d{2}$/) and inst.match(/^\d{3}$/)
    end
  end

  #
  # Options: (none)
  # 
  # Executes the LMC in @data.
  # 
  def run(mbox='00')
    while mbox<='99'
      succ = nil
      if inst = @data[mbox]
        @log.debug "##{mbox}:\t#{inst}\t(=#{@accu})"
        case inst
        when /^000/ # STOP
          @log.debug "\tSTOP"
          return
        when /^1(\d{2})/ # ADD
          @log.debug "\tADD #{$1}"
          @accu += @data[$1].to_i
        when /^2(\d{2})/ # SUB
          @log.debug "\tSUB #{$1}"
          @accu -= @data[$1].to_i
        when /^3(\d{2})/ # STO
          @log.debug "\tSTO #{$1}"
          @data[$1] = sprintf('%0.3i', @accu)
        when /^4(\d{2})/ # STA
          @log.debug "\tSTA #{$1}"
          @data[$1] = @accu[1..-1].to_s
        when /^5(\d{2})/ # LOAD
          @log.debug "\tLOAD #{$1}"
          @accu = @data[$1].to_i
        when /^6(\d{2})/ # B
          @log.debug "\tB #{$1}"
          succ = $1
        when /^7(\d{2})/ # BZ
          @log.debug "\tBZ #{$1}"
          succ = $1 if @accu == 0
        when /^8(\d{2})/ # BP
          @log.debug "\tBP #{$1}"
          succ = $1 if @accu >= 0
        when /^901/ # INPUT
          @log.debug "\tINPUT"
          print 'IN> ' unless @quiet
          v=STDIN.gets
          @accu = v.to_i if v.match(/\d{1,3}/)
        when /^902/ # OUTPUT
          @log.debug "\tOUTPUT"
          out=sprintf("#{'--> ' unless @quiet}%03i", @accu)
          puts out
          @log.debug out
        else
          raise LittleManInterpretError.new('Unrecognised instruction')
        end
      end

      if succ
        mbox = succ
      else
        mbox = mbox.succ
      end
    end
  end

  private :readfile, :unshorthand, :tokenize, :check

end



if __FILE__ == $0

  options =
    ['--compile', '-c', GetoptLong::NO_ARGUMENT, 'Output the state of the program before and after execution.'],
    ['--help', '-h', GetoptLong::NO_ARGUMENT, 'Print this help and exit.'],
    ['--literate', '-l', GetoptLong::OPTIONAL_ARGUMENT, 'The source code is embedded in documentation, where argument _arg_ is the characters on the line before the source (defaults to ">").'],
    ['--quiet', '-q', GetoptLong::NO_ARGUMENT, 'No prompts for input or output.'],
    ['--verbose', '-v', GetoptLong::NO_ARGUMENT, 'Prints debugging information.'],
    ['--noex', '-x', GetoptLong::NO_ARGUMENT, 'Don\'t execute.']
  opts = []
  options.each { |o| opts<<o[0..2] }
  gopts = GetoptLong.new(*opts)

  compile=nil
  literate=nil
  quiet=nil
  verbose=nil
  noex=nil

  gopts.each do |opt,arg|
    case opt
    when '--compile'
      compile = true
    when '--data'
      data = true
    when '--help'
      $0.match(/\/([^\/]*)$/)
      puts "#{$1}: Little Man Computer Interpreter"
      for long, short, arg, doc in options
        puts "#{long}, #{short}#{' arg' if arg>0}"
        puts "\t#{doc}"
      end
      exit
    when '--literate'
      if arg.class == "".class and arg.length > 0
        literate = arg
      else
        literate = true
      end
    when '--quiet' then quiet = true
    when '--verbose' then verbose = true
    when '--noex' then noex = true
    end
  end

  file = ""
  file+=$_ while gets

  lm = LittleMan.new(file,:verbose => verbose, :literate => literate, :quiet => quiet)

  puts lm.code if compile
  unless noex
    lm.run
    puts lm.code if compile
  end

end

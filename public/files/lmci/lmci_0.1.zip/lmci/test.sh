#!/bin/sh

echo "All the examples are the same code."

echo "Input three numbers with three or fewer digits, seperated by returns."
ruby lmci.rb example2

echo "Input three numbers with three or fewer digits, seperated by returns."
ruby lmci.rb -l\> example1

echo "Input three numbers with three or fewer digits, seperated by returns."
ruby lmci.rb example3

echo "It should have printed the smallest number every time."

echo "Input two numbers and it will add them."
ruby lmci.rb example4

